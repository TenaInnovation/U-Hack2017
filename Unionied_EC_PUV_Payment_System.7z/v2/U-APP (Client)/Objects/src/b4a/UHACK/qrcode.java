package b4a.UHACK;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class qrcode {
private static qrcode mostCurrent = new qrcode();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper _rect1 = null;
public static adr.stringfunctions.stringfunctions _sf = null;
public static int _gf = 0;
public static int _pp = 0;
public static int[] _logg = null;
public static int[] _alogg = null;
public static int _gf_mul_result = 0;
public static int[] _s4c4 = null;
public static String[] _s4c24 = null;
public static String[] _s4c1 = null;
public static String[] _z = null;
public static int[] _message_coeff = null;
public static int[][] _s5cij = null;
public static int _version_no = 0;
public static int _max_mod = 0;
public static int _qr_size = 0;
public static String _error_level = "";
public static String _a = "";
public static String _b = "";
public static String _q = "";
public static int _tel2 = 0;
public static String _anew = "";
public static String _ecc_woord = "";
public static int _no_of_error_words = 0;
public static int _mess_coef_teller = 0;
public static int _block1 = 0;
public static int _block2 = 0;
public static int _dw1 = 0;
public static int _dw2 = 0;
public static int _ew1 = 0;
public static int _ew2 = 0;
public static int _max_data_bits = 0;
public static int _maxlen = 0;
public static String _tipe = "";
public static int _maskp = 0;
public static String _dat = "";
public static int[] _ver1 = null;
public static int[] _ver2 = null;
public static int[] _ver3 = null;
public static int[] _ver4 = null;
public static int[] _ver5 = null;
public static int[] _ver6 = null;
public static int[] _ver7 = null;
public static int[] _ver8 = null;
public static int[] _ver9 = null;
public static int[] _ver10 = null;
public static int[] _ver11 = null;
public static int[] _ver12 = null;
public static int[] _ver13 = null;
public static int[] _ver14 = null;
public static int[] _ver15 = null;
public static int[] _ver16 = null;
public static int[] _ver17 = null;
public static int[] _ver18 = null;
public static int[] _ver19 = null;
public static int[] _ver20 = null;
public static int[] _ver21 = null;
public static int[] _ver22 = null;
public static int[] _ver23 = null;
public static int[] _ver24 = null;
public static int[] _ver25 = null;
public static int[] _ver26 = null;
public static int[] _ver27 = null;
public static int[] _ver28 = null;
public static int[] _ver29 = null;
public static int[] _ver30 = null;
public static int[] _ver31 = null;
public static int[] _ver32 = null;
public static int[] _ver33 = null;
public static int[] _ver34 = null;
public static int[] _ver35 = null;
public static int[] _ver36 = null;
public static int[] _ver37 = null;
public static int[] _ver38 = null;
public static int[] _ver39 = null;
public static int[] _ver40 = null;
public static int _bcolor = 0;
public static int _fcolor = 0;
public static String _shp = "";
public b4a.UHACK.main _main = null;
public b4a.UHACK.starter _starter = null;
public b4a.UHACK.global_declaration _global_declaration = null;
public b4a.UHACK.frmmain _frmmain = null;
public b4a.UHACK.frmdrivermenu _frmdrivermenu = null;
public b4a.UHACK.frmpaybyqr _frmpaybyqr = null;
public b4a.UHACK.frmviewbalance _frmviewbalance = null;
public b4a.UHACK.frmtransactions _frmtransactions = null;
public b4a.UHACK.frmpayment _frmpayment = null;
public b4a.UHACK.frmfindpuv _frmfindpuv = null;
public b4a.UHACK.frmpuvlocation _frmpuvlocation = null;
public b4a.UHACK.editbox _editbox = null;
public static int  _anconv(anywheresoftware.b4a.BA _ba,String _char1) throws Exception{
int _agetal = 0;
 //BA.debugLineNum = 1014;BA.debugLine="Private Sub anconv(char1 As String) As Int";
 //BA.debugLineNum = 1016;BA.debugLine="Dim agetal As Int";
_agetal = 0;
 //BA.debugLineNum = 1018;BA.debugLine="Select Case char1";
switch (BA.switchObjectToInt(_char1,"0","1","2","3","4","5","6","7","8","9","A","a","B","b","C","c","D","d","E","e","F","f","G","g","H","h","I","i","J","j","K","k","L","l","M","m","N","n","O","o","P","p","Q","q","R","r","S","s","T","t","U","u","V","v","W","w","X","x","Y","y","Z","z"," ","$","%","*","+","-",".","/",":")) {
case 0: {
 //BA.debugLineNum = 1020;BA.debugLine="agetal = 0";
_agetal = (int) (0);
 break; }
case 1: {
 //BA.debugLineNum = 1022;BA.debugLine="agetal = 1";
_agetal = (int) (1);
 break; }
case 2: {
 //BA.debugLineNum = 1024;BA.debugLine="agetal = 2";
_agetal = (int) (2);
 break; }
case 3: {
 //BA.debugLineNum = 1026;BA.debugLine="agetal = 3";
_agetal = (int) (3);
 break; }
case 4: {
 //BA.debugLineNum = 1028;BA.debugLine="agetal = 4";
_agetal = (int) (4);
 break; }
case 5: {
 //BA.debugLineNum = 1030;BA.debugLine="agetal = 5";
_agetal = (int) (5);
 break; }
case 6: {
 //BA.debugLineNum = 1032;BA.debugLine="agetal = 6";
_agetal = (int) (6);
 break; }
case 7: {
 //BA.debugLineNum = 1034;BA.debugLine="agetal = 7";
_agetal = (int) (7);
 break; }
case 8: {
 //BA.debugLineNum = 1036;BA.debugLine="agetal = 8";
_agetal = (int) (8);
 break; }
case 9: {
 //BA.debugLineNum = 1038;BA.debugLine="agetal = 9";
_agetal = (int) (9);
 break; }
case 10: {
 //BA.debugLineNum = 1040;BA.debugLine="agetal = 10";
_agetal = (int) (10);
 break; }
case 11: {
 //BA.debugLineNum = 1042;BA.debugLine="agetal = 10";
_agetal = (int) (10);
 break; }
case 12: {
 //BA.debugLineNum = 1044;BA.debugLine="agetal = 11";
_agetal = (int) (11);
 break; }
case 13: {
 //BA.debugLineNum = 1046;BA.debugLine="agetal = 11";
_agetal = (int) (11);
 break; }
case 14: {
 //BA.debugLineNum = 1048;BA.debugLine="agetal = 12";
_agetal = (int) (12);
 break; }
case 15: {
 //BA.debugLineNum = 1050;BA.debugLine="agetal = 12";
_agetal = (int) (12);
 break; }
case 16: {
 //BA.debugLineNum = 1052;BA.debugLine="agetal = 13";
_agetal = (int) (13);
 break; }
case 17: {
 //BA.debugLineNum = 1054;BA.debugLine="agetal = 13";
_agetal = (int) (13);
 break; }
case 18: {
 //BA.debugLineNum = 1056;BA.debugLine="agetal = 14";
_agetal = (int) (14);
 break; }
case 19: {
 //BA.debugLineNum = 1058;BA.debugLine="agetal = 14";
_agetal = (int) (14);
 break; }
case 20: {
 //BA.debugLineNum = 1060;BA.debugLine="agetal = 15";
_agetal = (int) (15);
 break; }
case 21: {
 //BA.debugLineNum = 1062;BA.debugLine="agetal = 15";
_agetal = (int) (15);
 break; }
case 22: {
 //BA.debugLineNum = 1064;BA.debugLine="agetal = 16";
_agetal = (int) (16);
 break; }
case 23: {
 //BA.debugLineNum = 1066;BA.debugLine="agetal = 16";
_agetal = (int) (16);
 break; }
case 24: {
 //BA.debugLineNum = 1068;BA.debugLine="agetal = 17";
_agetal = (int) (17);
 break; }
case 25: {
 //BA.debugLineNum = 1070;BA.debugLine="agetal = 17";
_agetal = (int) (17);
 break; }
case 26: {
 //BA.debugLineNum = 1072;BA.debugLine="agetal = 18";
_agetal = (int) (18);
 break; }
case 27: {
 //BA.debugLineNum = 1074;BA.debugLine="agetal = 18";
_agetal = (int) (18);
 break; }
case 28: {
 //BA.debugLineNum = 1076;BA.debugLine="agetal = 19";
_agetal = (int) (19);
 break; }
case 29: {
 //BA.debugLineNum = 1078;BA.debugLine="agetal = 19";
_agetal = (int) (19);
 break; }
case 30: {
 //BA.debugLineNum = 1080;BA.debugLine="agetal = 20";
_agetal = (int) (20);
 break; }
case 31: {
 //BA.debugLineNum = 1082;BA.debugLine="agetal = 20";
_agetal = (int) (20);
 break; }
case 32: {
 //BA.debugLineNum = 1084;BA.debugLine="agetal = 21";
_agetal = (int) (21);
 break; }
case 33: {
 //BA.debugLineNum = 1086;BA.debugLine="agetal = 21";
_agetal = (int) (21);
 break; }
case 34: {
 //BA.debugLineNum = 1088;BA.debugLine="agetal = 22";
_agetal = (int) (22);
 break; }
case 35: {
 //BA.debugLineNum = 1090;BA.debugLine="agetal = 22";
_agetal = (int) (22);
 break; }
case 36: {
 //BA.debugLineNum = 1092;BA.debugLine="agetal = 23";
_agetal = (int) (23);
 break; }
case 37: {
 //BA.debugLineNum = 1094;BA.debugLine="agetal = 23";
_agetal = (int) (23);
 break; }
case 38: {
 //BA.debugLineNum = 1096;BA.debugLine="agetal = 24";
_agetal = (int) (24);
 break; }
case 39: {
 //BA.debugLineNum = 1098;BA.debugLine="agetal = 24";
_agetal = (int) (24);
 break; }
case 40: {
 //BA.debugLineNum = 1100;BA.debugLine="agetal = 25";
_agetal = (int) (25);
 break; }
case 41: {
 //BA.debugLineNum = 1102;BA.debugLine="agetal = 25";
_agetal = (int) (25);
 break; }
case 42: {
 //BA.debugLineNum = 1104;BA.debugLine="agetal = 26";
_agetal = (int) (26);
 break; }
case 43: {
 //BA.debugLineNum = 1106;BA.debugLine="agetal = 26";
_agetal = (int) (26);
 break; }
case 44: {
 //BA.debugLineNum = 1108;BA.debugLine="agetal = 27";
_agetal = (int) (27);
 break; }
case 45: {
 //BA.debugLineNum = 1110;BA.debugLine="agetal = 27";
_agetal = (int) (27);
 break; }
case 46: {
 //BA.debugLineNum = 1112;BA.debugLine="agetal = 28";
_agetal = (int) (28);
 break; }
case 47: {
 //BA.debugLineNum = 1114;BA.debugLine="agetal = 28";
_agetal = (int) (28);
 break; }
case 48: {
 //BA.debugLineNum = 1116;BA.debugLine="agetal = 29";
_agetal = (int) (29);
 break; }
case 49: {
 //BA.debugLineNum = 1118;BA.debugLine="agetal = 29";
_agetal = (int) (29);
 break; }
case 50: {
 //BA.debugLineNum = 1120;BA.debugLine="agetal = 30";
_agetal = (int) (30);
 break; }
case 51: {
 //BA.debugLineNum = 1122;BA.debugLine="agetal = 30";
_agetal = (int) (30);
 break; }
case 52: {
 //BA.debugLineNum = 1124;BA.debugLine="agetal = 31";
_agetal = (int) (31);
 break; }
case 53: {
 //BA.debugLineNum = 1126;BA.debugLine="agetal = 31";
_agetal = (int) (31);
 break; }
case 54: {
 //BA.debugLineNum = 1128;BA.debugLine="agetal = 32";
_agetal = (int) (32);
 break; }
case 55: {
 //BA.debugLineNum = 1130;BA.debugLine="agetal = 32";
_agetal = (int) (32);
 break; }
case 56: {
 //BA.debugLineNum = 1132;BA.debugLine="agetal = 33";
_agetal = (int) (33);
 break; }
case 57: {
 //BA.debugLineNum = 1134;BA.debugLine="agetal = 33";
_agetal = (int) (33);
 break; }
case 58: {
 //BA.debugLineNum = 1136;BA.debugLine="agetal = 34";
_agetal = (int) (34);
 break; }
case 59: {
 //BA.debugLineNum = 1138;BA.debugLine="agetal = 34";
_agetal = (int) (34);
 break; }
case 60: {
 //BA.debugLineNum = 1140;BA.debugLine="agetal = 35";
_agetal = (int) (35);
 break; }
case 61: {
 //BA.debugLineNum = 1142;BA.debugLine="agetal = 35";
_agetal = (int) (35);
 break; }
case 62: {
 //BA.debugLineNum = 1144;BA.debugLine="agetal = 36 '(space)";
_agetal = (int) (36);
 break; }
case 63: {
 //BA.debugLineNum = 1146;BA.debugLine="agetal = 37";
_agetal = (int) (37);
 break; }
case 64: {
 //BA.debugLineNum = 1148;BA.debugLine="agetal = 38";
_agetal = (int) (38);
 break; }
case 65: {
 //BA.debugLineNum = 1150;BA.debugLine="agetal = 39";
_agetal = (int) (39);
 break; }
case 66: {
 //BA.debugLineNum = 1152;BA.debugLine="agetal = 40";
_agetal = (int) (40);
 break; }
case 67: {
 //BA.debugLineNum = 1154;BA.debugLine="agetal = 41";
_agetal = (int) (41);
 break; }
case 68: {
 //BA.debugLineNum = 1156;BA.debugLine="agetal = 42";
_agetal = (int) (42);
 break; }
case 69: {
 //BA.debugLineNum = 1158;BA.debugLine="agetal = 43";
_agetal = (int) (43);
 break; }
case 70: {
 //BA.debugLineNum = 1160;BA.debugLine="agetal = 44";
_agetal = (int) (44);
 break; }
}
;
 //BA.debugLineNum = 1163;BA.debugLine="Return agetal";
if (true) return _agetal;
 //BA.debugLineNum = 1165;BA.debugLine="End Sub";
return 0;
}
public static int  _conv(anywheresoftware.b4a.BA _ba,String _karak) throws Exception{
int _char1 = 0;
 //BA.debugLineNum = 547;BA.debugLine="Private Sub conv (karak As String) As Int";
 //BA.debugLineNum = 549;BA.debugLine="Dim char1 As Int";
_char1 = 0;
 //BA.debugLineNum = 552;BA.debugLine="Select Case karak     'decimal values for ASCII ch";
switch (BA.switchObjectToInt(_karak,BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (13))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (10)))," ","!","\"","#","$","%","&","'","(",")","*","+",",","-",".","/","0","1","2","3","4","5","6","7","8","9",":",";","<","=",">","?","@","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","[","]","^","_","`","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","{","|","}",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (126))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (160))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (161))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (162))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (163))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (164))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (165))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (166))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (167))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (168))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (169))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (170))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (171))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (172))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (173))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (174))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (175))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (176))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (177))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (178))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (179))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (180))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (181))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (182))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (183))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (184))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (185))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (186))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (187))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (188))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (189))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (190))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (191))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (192))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (193))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (194))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (195))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (196))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (197))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (198))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (199))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (200))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (201))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (202))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (203))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (204))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (205))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (206))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (207))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (208))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (209))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (210))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (211))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (212))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (213))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (214))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (215))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (216))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (217))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (218))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (219))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (220))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (221))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (222))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (223))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (224))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (225))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (226))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (227))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (228))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (229))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (230))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (231))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (232))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (233))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (234))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (235))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (236))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (237))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (238))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (239))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (240))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (241))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (242))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (243))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (244))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (245))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (246))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (247))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (248))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (249))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (250))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (251))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (252))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (253))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (254))),BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (255))))) {
case 0: {
 //BA.debugLineNum = 554;BA.debugLine="char1 = 13";
_char1 = (int) (13);
 break; }
case 1: {
 //BA.debugLineNum = 556;BA.debugLine="char1 = 10";
_char1 = (int) (10);
 break; }
case 2: {
 //BA.debugLineNum = 558;BA.debugLine="char1 = 32";
_char1 = (int) (32);
 break; }
case 3: {
 //BA.debugLineNum = 560;BA.debugLine="char1 = 33";
_char1 = (int) (33);
 break; }
case 4: {
 //BA.debugLineNum = 562;BA.debugLine="char1 = 34";
_char1 = (int) (34);
 break; }
case 5: {
 //BA.debugLineNum = 564;BA.debugLine="char1 = 35";
_char1 = (int) (35);
 break; }
case 6: {
 //BA.debugLineNum = 566;BA.debugLine="char1 = 36";
_char1 = (int) (36);
 break; }
case 7: {
 //BA.debugLineNum = 568;BA.debugLine="char1 = 37";
_char1 = (int) (37);
 break; }
case 8: {
 //BA.debugLineNum = 570;BA.debugLine="char1 = 38";
_char1 = (int) (38);
 break; }
case 9: {
 //BA.debugLineNum = 572;BA.debugLine="char1 = 39";
_char1 = (int) (39);
 break; }
case 10: {
 //BA.debugLineNum = 574;BA.debugLine="char1 = 40";
_char1 = (int) (40);
 break; }
case 11: {
 //BA.debugLineNum = 576;BA.debugLine="char1 = 41";
_char1 = (int) (41);
 break; }
case 12: {
 //BA.debugLineNum = 578;BA.debugLine="char1 = 42";
_char1 = (int) (42);
 break; }
case 13: {
 //BA.debugLineNum = 580;BA.debugLine="char1 = 43";
_char1 = (int) (43);
 break; }
case 14: {
 //BA.debugLineNum = 582;BA.debugLine="char1 = 44";
_char1 = (int) (44);
 break; }
case 15: {
 //BA.debugLineNum = 584;BA.debugLine="char1 = 45";
_char1 = (int) (45);
 break; }
case 16: {
 //BA.debugLineNum = 586;BA.debugLine="char1 = 46";
_char1 = (int) (46);
 break; }
case 17: {
 //BA.debugLineNum = 588;BA.debugLine="char1 = 47";
_char1 = (int) (47);
 break; }
case 18: {
 //BA.debugLineNum = 590;BA.debugLine="char1 = 48";
_char1 = (int) (48);
 break; }
case 19: {
 //BA.debugLineNum = 592;BA.debugLine="char1 = 49";
_char1 = (int) (49);
 break; }
case 20: {
 //BA.debugLineNum = 594;BA.debugLine="char1 = 50";
_char1 = (int) (50);
 break; }
case 21: {
 //BA.debugLineNum = 596;BA.debugLine="char1 = 51";
_char1 = (int) (51);
 break; }
case 22: {
 //BA.debugLineNum = 598;BA.debugLine="char1 = 52";
_char1 = (int) (52);
 break; }
case 23: {
 //BA.debugLineNum = 600;BA.debugLine="char1 = 53";
_char1 = (int) (53);
 break; }
case 24: {
 //BA.debugLineNum = 602;BA.debugLine="char1 = 54";
_char1 = (int) (54);
 break; }
case 25: {
 //BA.debugLineNum = 604;BA.debugLine="char1 = 55";
_char1 = (int) (55);
 break; }
case 26: {
 //BA.debugLineNum = 606;BA.debugLine="char1 = 56";
_char1 = (int) (56);
 break; }
case 27: {
 //BA.debugLineNum = 608;BA.debugLine="char1 = 57";
_char1 = (int) (57);
 break; }
case 28: {
 //BA.debugLineNum = 610;BA.debugLine="char1 = 58";
_char1 = (int) (58);
 break; }
case 29: {
 //BA.debugLineNum = 612;BA.debugLine="char1 = 59";
_char1 = (int) (59);
 break; }
case 30: {
 //BA.debugLineNum = 614;BA.debugLine="char1 = 60";
_char1 = (int) (60);
 break; }
case 31: {
 //BA.debugLineNum = 616;BA.debugLine="char1 = 61";
_char1 = (int) (61);
 break; }
case 32: {
 //BA.debugLineNum = 618;BA.debugLine="char1 = 62";
_char1 = (int) (62);
 break; }
case 33: {
 //BA.debugLineNum = 620;BA.debugLine="char1 = 63";
_char1 = (int) (63);
 break; }
case 34: {
 //BA.debugLineNum = 622;BA.debugLine="char1 = 64";
_char1 = (int) (64);
 break; }
case 35: {
 //BA.debugLineNum = 624;BA.debugLine="char1 = 65";
_char1 = (int) (65);
 break; }
case 36: {
 //BA.debugLineNum = 626;BA.debugLine="char1 = 66";
_char1 = (int) (66);
 break; }
case 37: {
 //BA.debugLineNum = 628;BA.debugLine="char1 = 67";
_char1 = (int) (67);
 break; }
case 38: {
 //BA.debugLineNum = 630;BA.debugLine="char1 = 68";
_char1 = (int) (68);
 break; }
case 39: {
 //BA.debugLineNum = 632;BA.debugLine="char1 = 69";
_char1 = (int) (69);
 break; }
case 40: {
 //BA.debugLineNum = 634;BA.debugLine="char1 = 70";
_char1 = (int) (70);
 break; }
case 41: {
 //BA.debugLineNum = 636;BA.debugLine="char1 = 71";
_char1 = (int) (71);
 break; }
case 42: {
 //BA.debugLineNum = 638;BA.debugLine="char1 = 72";
_char1 = (int) (72);
 break; }
case 43: {
 //BA.debugLineNum = 640;BA.debugLine="char1 = 73";
_char1 = (int) (73);
 break; }
case 44: {
 //BA.debugLineNum = 642;BA.debugLine="char1 = 74";
_char1 = (int) (74);
 break; }
case 45: {
 //BA.debugLineNum = 644;BA.debugLine="char1 = 75";
_char1 = (int) (75);
 break; }
case 46: {
 //BA.debugLineNum = 646;BA.debugLine="char1 = 76";
_char1 = (int) (76);
 break; }
case 47: {
 //BA.debugLineNum = 648;BA.debugLine="char1 = 77";
_char1 = (int) (77);
 break; }
case 48: {
 //BA.debugLineNum = 650;BA.debugLine="char1 = 78";
_char1 = (int) (78);
 break; }
case 49: {
 //BA.debugLineNum = 652;BA.debugLine="char1 = 79";
_char1 = (int) (79);
 break; }
case 50: {
 //BA.debugLineNum = 654;BA.debugLine="char1 = 80";
_char1 = (int) (80);
 break; }
case 51: {
 //BA.debugLineNum = 656;BA.debugLine="char1 = 81";
_char1 = (int) (81);
 break; }
case 52: {
 //BA.debugLineNum = 658;BA.debugLine="char1 = 82";
_char1 = (int) (82);
 break; }
case 53: {
 //BA.debugLineNum = 660;BA.debugLine="char1 = 83";
_char1 = (int) (83);
 break; }
case 54: {
 //BA.debugLineNum = 662;BA.debugLine="char1 = 84";
_char1 = (int) (84);
 break; }
case 55: {
 //BA.debugLineNum = 664;BA.debugLine="char1 = 85";
_char1 = (int) (85);
 break; }
case 56: {
 //BA.debugLineNum = 666;BA.debugLine="char1 = 86";
_char1 = (int) (86);
 break; }
case 57: {
 //BA.debugLineNum = 668;BA.debugLine="char1 = 87";
_char1 = (int) (87);
 break; }
case 58: {
 //BA.debugLineNum = 670;BA.debugLine="char1 = 88";
_char1 = (int) (88);
 break; }
case 59: {
 //BA.debugLineNum = 672;BA.debugLine="char1 = 89";
_char1 = (int) (89);
 break; }
case 60: {
 //BA.debugLineNum = 674;BA.debugLine="char1 = 90";
_char1 = (int) (90);
 break; }
case 61: {
 //BA.debugLineNum = 676;BA.debugLine="char1 = 91";
_char1 = (int) (91);
 break; }
case 62: {
 //BA.debugLineNum = 678;BA.debugLine="char1 = 93";
_char1 = (int) (93);
 break; }
case 63: {
 //BA.debugLineNum = 680;BA.debugLine="char1 = 94";
_char1 = (int) (94);
 break; }
case 64: {
 //BA.debugLineNum = 682;BA.debugLine="char1 = 95";
_char1 = (int) (95);
 break; }
case 65: {
 //BA.debugLineNum = 684;BA.debugLine="char1 = 96";
_char1 = (int) (96);
 break; }
case 66: {
 //BA.debugLineNum = 686;BA.debugLine="char1 = 97";
_char1 = (int) (97);
 break; }
case 67: {
 //BA.debugLineNum = 688;BA.debugLine="char1 = 98";
_char1 = (int) (98);
 break; }
case 68: {
 //BA.debugLineNum = 690;BA.debugLine="char1 = 99";
_char1 = (int) (99);
 break; }
case 69: {
 //BA.debugLineNum = 692;BA.debugLine="char1 = 100";
_char1 = (int) (100);
 break; }
case 70: {
 //BA.debugLineNum = 694;BA.debugLine="char1 = 101";
_char1 = (int) (101);
 break; }
case 71: {
 //BA.debugLineNum = 696;BA.debugLine="char1 = 102";
_char1 = (int) (102);
 break; }
case 72: {
 //BA.debugLineNum = 698;BA.debugLine="char1 = 103";
_char1 = (int) (103);
 break; }
case 73: {
 //BA.debugLineNum = 700;BA.debugLine="char1 = 104";
_char1 = (int) (104);
 break; }
case 74: {
 //BA.debugLineNum = 702;BA.debugLine="char1 = 105";
_char1 = (int) (105);
 break; }
case 75: {
 //BA.debugLineNum = 704;BA.debugLine="char1 = 106";
_char1 = (int) (106);
 break; }
case 76: {
 //BA.debugLineNum = 706;BA.debugLine="char1 = 107";
_char1 = (int) (107);
 break; }
case 77: {
 //BA.debugLineNum = 708;BA.debugLine="char1 = 108";
_char1 = (int) (108);
 break; }
case 78: {
 //BA.debugLineNum = 710;BA.debugLine="char1 = 109";
_char1 = (int) (109);
 break; }
case 79: {
 //BA.debugLineNum = 712;BA.debugLine="char1 = 110";
_char1 = (int) (110);
 break; }
case 80: {
 //BA.debugLineNum = 714;BA.debugLine="char1 = 111";
_char1 = (int) (111);
 break; }
case 81: {
 //BA.debugLineNum = 716;BA.debugLine="char1 = 112";
_char1 = (int) (112);
 break; }
case 82: {
 //BA.debugLineNum = 718;BA.debugLine="char1 = 113";
_char1 = (int) (113);
 break; }
case 83: {
 //BA.debugLineNum = 720;BA.debugLine="char1 = 114";
_char1 = (int) (114);
 break; }
case 84: {
 //BA.debugLineNum = 722;BA.debugLine="char1 = 115";
_char1 = (int) (115);
 break; }
case 85: {
 //BA.debugLineNum = 724;BA.debugLine="char1 = 116";
_char1 = (int) (116);
 break; }
case 86: {
 //BA.debugLineNum = 726;BA.debugLine="char1 = 117";
_char1 = (int) (117);
 break; }
case 87: {
 //BA.debugLineNum = 728;BA.debugLine="char1 = 118";
_char1 = (int) (118);
 break; }
case 88: {
 //BA.debugLineNum = 730;BA.debugLine="char1 = 119";
_char1 = (int) (119);
 break; }
case 89: {
 //BA.debugLineNum = 732;BA.debugLine="char1 = 120";
_char1 = (int) (120);
 break; }
case 90: {
 //BA.debugLineNum = 734;BA.debugLine="char1 = 121";
_char1 = (int) (121);
 break; }
case 91: {
 //BA.debugLineNum = 736;BA.debugLine="char1 = 122";
_char1 = (int) (122);
 break; }
case 92: {
 //BA.debugLineNum = 738;BA.debugLine="char1 = 123";
_char1 = (int) (123);
 break; }
case 93: {
 //BA.debugLineNum = 740;BA.debugLine="char1 = 124";
_char1 = (int) (124);
 break; }
case 94: {
 //BA.debugLineNum = 742;BA.debugLine="char1 = 125";
_char1 = (int) (125);
 break; }
case 95: {
 //BA.debugLineNum = 744;BA.debugLine="char1 = 126";
_char1 = (int) (126);
 break; }
case 96: {
 //BA.debugLineNum = 746;BA.debugLine="char1 = 160";
_char1 = (int) (160);
 break; }
case 97: {
 //BA.debugLineNum = 748;BA.debugLine="char1 = 161";
_char1 = (int) (161);
 break; }
case 98: {
 //BA.debugLineNum = 750;BA.debugLine="char1 = 162";
_char1 = (int) (162);
 break; }
case 99: {
 //BA.debugLineNum = 752;BA.debugLine="char1 = 163";
_char1 = (int) (163);
 break; }
case 100: {
 //BA.debugLineNum = 754;BA.debugLine="char1 = 164";
_char1 = (int) (164);
 break; }
case 101: {
 //BA.debugLineNum = 756;BA.debugLine="char1 = 165";
_char1 = (int) (165);
 break; }
case 102: {
 //BA.debugLineNum = 758;BA.debugLine="char1 = 166";
_char1 = (int) (166);
 break; }
case 103: {
 //BA.debugLineNum = 760;BA.debugLine="char1 = 167";
_char1 = (int) (167);
 break; }
case 104: {
 //BA.debugLineNum = 762;BA.debugLine="char1 = 168";
_char1 = (int) (168);
 break; }
case 105: {
 //BA.debugLineNum = 764;BA.debugLine="char1 = 169";
_char1 = (int) (169);
 break; }
case 106: {
 //BA.debugLineNum = 766;BA.debugLine="char1 = 170";
_char1 = (int) (170);
 break; }
case 107: {
 //BA.debugLineNum = 768;BA.debugLine="char1 = 171";
_char1 = (int) (171);
 break; }
case 108: {
 //BA.debugLineNum = 770;BA.debugLine="char1 = 172";
_char1 = (int) (172);
 break; }
case 109: {
 //BA.debugLineNum = 772;BA.debugLine="char1 = 173";
_char1 = (int) (173);
 break; }
case 110: {
 //BA.debugLineNum = 774;BA.debugLine="char1 = 174";
_char1 = (int) (174);
 break; }
case 111: {
 //BA.debugLineNum = 776;BA.debugLine="char1 = 175";
_char1 = (int) (175);
 break; }
case 112: {
 //BA.debugLineNum = 778;BA.debugLine="char1 = 176";
_char1 = (int) (176);
 break; }
case 113: {
 //BA.debugLineNum = 780;BA.debugLine="char1 = 177";
_char1 = (int) (177);
 break; }
case 114: {
 //BA.debugLineNum = 782;BA.debugLine="char1 = 178";
_char1 = (int) (178);
 break; }
case 115: {
 //BA.debugLineNum = 784;BA.debugLine="char1 = 179";
_char1 = (int) (179);
 break; }
case 116: {
 //BA.debugLineNum = 786;BA.debugLine="char1 = 180";
_char1 = (int) (180);
 break; }
case 117: {
 //BA.debugLineNum = 788;BA.debugLine="char1 = 181";
_char1 = (int) (181);
 break; }
case 118: {
 //BA.debugLineNum = 790;BA.debugLine="char1 = 182";
_char1 = (int) (182);
 break; }
case 119: {
 //BA.debugLineNum = 792;BA.debugLine="char1 = 183";
_char1 = (int) (183);
 break; }
case 120: {
 //BA.debugLineNum = 794;BA.debugLine="char1 = 184";
_char1 = (int) (184);
 break; }
case 121: {
 //BA.debugLineNum = 796;BA.debugLine="char1 = 185";
_char1 = (int) (185);
 break; }
case 122: {
 //BA.debugLineNum = 798;BA.debugLine="char1 = 186";
_char1 = (int) (186);
 break; }
case 123: {
 //BA.debugLineNum = 800;BA.debugLine="char1 = 187";
_char1 = (int) (187);
 break; }
case 124: {
 //BA.debugLineNum = 802;BA.debugLine="char1 = 188";
_char1 = (int) (188);
 break; }
case 125: {
 //BA.debugLineNum = 804;BA.debugLine="char1 = 189";
_char1 = (int) (189);
 break; }
case 126: {
 //BA.debugLineNum = 806;BA.debugLine="char1 = 190";
_char1 = (int) (190);
 break; }
case 127: {
 //BA.debugLineNum = 808;BA.debugLine="char1 = 191";
_char1 = (int) (191);
 break; }
case 128: {
 //BA.debugLineNum = 810;BA.debugLine="char1 = 192";
_char1 = (int) (192);
 break; }
case 129: {
 //BA.debugLineNum = 812;BA.debugLine="char1 = 193";
_char1 = (int) (193);
 break; }
case 130: {
 //BA.debugLineNum = 814;BA.debugLine="char1 = 194";
_char1 = (int) (194);
 break; }
case 131: {
 //BA.debugLineNum = 816;BA.debugLine="char1 = 195";
_char1 = (int) (195);
 break; }
case 132: {
 //BA.debugLineNum = 818;BA.debugLine="char1 = 196";
_char1 = (int) (196);
 break; }
case 133: {
 //BA.debugLineNum = 820;BA.debugLine="char1 = 197";
_char1 = (int) (197);
 break; }
case 134: {
 //BA.debugLineNum = 822;BA.debugLine="char1 = 198";
_char1 = (int) (198);
 break; }
case 135: {
 //BA.debugLineNum = 824;BA.debugLine="char1 = 199";
_char1 = (int) (199);
 break; }
case 136: {
 //BA.debugLineNum = 826;BA.debugLine="char1 = 200";
_char1 = (int) (200);
 break; }
case 137: {
 //BA.debugLineNum = 828;BA.debugLine="char1 = 201";
_char1 = (int) (201);
 break; }
case 138: {
 //BA.debugLineNum = 830;BA.debugLine="char1 = 202";
_char1 = (int) (202);
 break; }
case 139: {
 //BA.debugLineNum = 832;BA.debugLine="char1 = 203";
_char1 = (int) (203);
 break; }
case 140: {
 //BA.debugLineNum = 834;BA.debugLine="char1 = 204";
_char1 = (int) (204);
 break; }
case 141: {
 //BA.debugLineNum = 836;BA.debugLine="char1 = 205";
_char1 = (int) (205);
 break; }
case 142: {
 //BA.debugLineNum = 838;BA.debugLine="char1 = 206";
_char1 = (int) (206);
 break; }
case 143: {
 //BA.debugLineNum = 840;BA.debugLine="char1 = 207";
_char1 = (int) (207);
 break; }
case 144: {
 //BA.debugLineNum = 842;BA.debugLine="char1 = 208";
_char1 = (int) (208);
 break; }
case 145: {
 //BA.debugLineNum = 844;BA.debugLine="char1 = 209";
_char1 = (int) (209);
 break; }
case 146: {
 //BA.debugLineNum = 846;BA.debugLine="char1 = 210";
_char1 = (int) (210);
 break; }
case 147: {
 //BA.debugLineNum = 848;BA.debugLine="char1 = 211";
_char1 = (int) (211);
 break; }
case 148: {
 //BA.debugLineNum = 850;BA.debugLine="char1 = 212";
_char1 = (int) (212);
 break; }
case 149: {
 //BA.debugLineNum = 852;BA.debugLine="char1 = 213";
_char1 = (int) (213);
 break; }
case 150: {
 //BA.debugLineNum = 854;BA.debugLine="char1 = 214";
_char1 = (int) (214);
 break; }
case 151: {
 //BA.debugLineNum = 856;BA.debugLine="char1 = 215";
_char1 = (int) (215);
 break; }
case 152: {
 //BA.debugLineNum = 858;BA.debugLine="char1 = 216";
_char1 = (int) (216);
 break; }
case 153: {
 //BA.debugLineNum = 860;BA.debugLine="char1 = 217";
_char1 = (int) (217);
 break; }
case 154: {
 //BA.debugLineNum = 862;BA.debugLine="char1 = 218";
_char1 = (int) (218);
 break; }
case 155: {
 //BA.debugLineNum = 864;BA.debugLine="char1 = 219";
_char1 = (int) (219);
 break; }
case 156: {
 //BA.debugLineNum = 866;BA.debugLine="char1 = 220";
_char1 = (int) (220);
 break; }
case 157: {
 //BA.debugLineNum = 868;BA.debugLine="char1 = 221";
_char1 = (int) (221);
 break; }
case 158: {
 //BA.debugLineNum = 870;BA.debugLine="char1 = 222";
_char1 = (int) (222);
 break; }
case 159: {
 //BA.debugLineNum = 872;BA.debugLine="char1 = 223";
_char1 = (int) (223);
 break; }
case 160: {
 //BA.debugLineNum = 874;BA.debugLine="char1 = 224";
_char1 = (int) (224);
 break; }
case 161: {
 //BA.debugLineNum = 876;BA.debugLine="char1 = 225";
_char1 = (int) (225);
 break; }
case 162: {
 //BA.debugLineNum = 878;BA.debugLine="char1 = 226";
_char1 = (int) (226);
 break; }
case 163: {
 //BA.debugLineNum = 880;BA.debugLine="char1 = 227";
_char1 = (int) (227);
 break; }
case 164: {
 //BA.debugLineNum = 882;BA.debugLine="char1 = 228";
_char1 = (int) (228);
 break; }
case 165: {
 //BA.debugLineNum = 884;BA.debugLine="char1 = 229";
_char1 = (int) (229);
 break; }
case 166: {
 //BA.debugLineNum = 886;BA.debugLine="char1 = 230";
_char1 = (int) (230);
 break; }
case 167: {
 //BA.debugLineNum = 888;BA.debugLine="char1 = 231";
_char1 = (int) (231);
 break; }
case 168: {
 //BA.debugLineNum = 890;BA.debugLine="char1 = 232";
_char1 = (int) (232);
 break; }
case 169: {
 //BA.debugLineNum = 892;BA.debugLine="char1 = 233";
_char1 = (int) (233);
 break; }
case 170: {
 //BA.debugLineNum = 894;BA.debugLine="char1 = 234";
_char1 = (int) (234);
 break; }
case 171: {
 //BA.debugLineNum = 896;BA.debugLine="char1 = 235";
_char1 = (int) (235);
 break; }
case 172: {
 //BA.debugLineNum = 898;BA.debugLine="char1 = 236";
_char1 = (int) (236);
 break; }
case 173: {
 //BA.debugLineNum = 900;BA.debugLine="char1 = 237";
_char1 = (int) (237);
 break; }
case 174: {
 //BA.debugLineNum = 902;BA.debugLine="char1 = 238";
_char1 = (int) (238);
 break; }
case 175: {
 //BA.debugLineNum = 904;BA.debugLine="char1 = 239";
_char1 = (int) (239);
 break; }
case 176: {
 //BA.debugLineNum = 906;BA.debugLine="char1 = 240";
_char1 = (int) (240);
 break; }
case 177: {
 //BA.debugLineNum = 908;BA.debugLine="char1 = 241";
_char1 = (int) (241);
 break; }
case 178: {
 //BA.debugLineNum = 910;BA.debugLine="char1 = 242";
_char1 = (int) (242);
 break; }
case 179: {
 //BA.debugLineNum = 912;BA.debugLine="char1 = 243";
_char1 = (int) (243);
 break; }
case 180: {
 //BA.debugLineNum = 914;BA.debugLine="char1 = 244";
_char1 = (int) (244);
 break; }
case 181: {
 //BA.debugLineNum = 916;BA.debugLine="char1 = 245";
_char1 = (int) (245);
 break; }
case 182: {
 //BA.debugLineNum = 918;BA.debugLine="char1 = 246";
_char1 = (int) (246);
 break; }
case 183: {
 //BA.debugLineNum = 920;BA.debugLine="char1 = 247";
_char1 = (int) (247);
 break; }
case 184: {
 //BA.debugLineNum = 922;BA.debugLine="char1 = 248";
_char1 = (int) (248);
 break; }
case 185: {
 //BA.debugLineNum = 924;BA.debugLine="char1 = 249";
_char1 = (int) (249);
 break; }
case 186: {
 //BA.debugLineNum = 926;BA.debugLine="char1 = 250";
_char1 = (int) (250);
 break; }
case 187: {
 //BA.debugLineNum = 928;BA.debugLine="char1 = 251";
_char1 = (int) (251);
 break; }
case 188: {
 //BA.debugLineNum = 930;BA.debugLine="char1 = 252";
_char1 = (int) (252);
 break; }
case 189: {
 //BA.debugLineNum = 932;BA.debugLine="char1 = 253";
_char1 = (int) (253);
 break; }
case 190: {
 //BA.debugLineNum = 934;BA.debugLine="char1 = 254";
_char1 = (int) (254);
 break; }
case 191: {
 //BA.debugLineNum = 936;BA.debugLine="char1 = 255";
_char1 = (int) (255);
 break; }
}
;
 //BA.debugLineNum = 939;BA.debugLine="Return char1";
if (true) return _char1;
 //BA.debugLineNum = 941;BA.debugLine="End Sub";
return 0;
}
public static String  _convert_to_binary(anywheresoftware.b4a.BA _ba,String _getal1) throws Exception{
String _rev_len_dat_bin = "";
String _len_dat_bin = "";
int _e = 0;
int _f = 0;
int _g = 0;
int _x = 0;
 //BA.debugLineNum = 980;BA.debugLine="Private Sub convert_to_binary(getal1 As String) As";
 //BA.debugLineNum = 982;BA.debugLine="Dim rev_len_dat_bin, len_dat_bin As String";
_rev_len_dat_bin = "";
_len_dat_bin = "";
 //BA.debugLineNum = 983;BA.debugLine="Dim e,f,g As Int";
_e = 0;
_f = 0;
_g = 0;
 //BA.debugLineNum = 985;BA.debugLine="rev_len_dat_bin = \"\"";
_rev_len_dat_bin = "";
 //BA.debugLineNum = 986;BA.debugLine="e = sf.Val(getal1)";
_e = (int) (_sf._vvvvvvv6(_getal1));
 //BA.debugLineNum = 987;BA.debugLine="If e <> 0 Then";
if (_e!=0) { 
 //BA.debugLineNum = 988;BA.debugLine="Do While e <> 0";
while (_e!=0) {
 //BA.debugLineNum = 989;BA.debugLine="f = Floor(e / 2)";
_f = (int) (anywheresoftware.b4a.keywords.Common.Floor(_e/(double)2));
 //BA.debugLineNum = 990;BA.debugLine="g = e - (f * 2)";
_g = (int) (_e-(_f*2));
 //BA.debugLineNum = 991;BA.debugLine="If g = 1 Then rev_len_dat_bin = rev_len_dat_bin";
if (_g==1) { 
_rev_len_dat_bin = _rev_len_dat_bin+"1";};
 //BA.debugLineNum = 992;BA.debugLine="If g = 0 Then rev_len_dat_bin = rev_len_dat_bin";
if (_g==0) { 
_rev_len_dat_bin = _rev_len_dat_bin+"0";};
 //BA.debugLineNum = 993;BA.debugLine="e = f";
_e = _f;
 }
;
 //BA.debugLineNum = 996;BA.debugLine="len_dat_bin = \"\"";
_len_dat_bin = "";
 //BA.debugLineNum = 997;BA.debugLine="For x = 1 To sf.len(rev_len_dat_bin)";
{
final int step14 = 1;
final int limit14 = (int) (_sf._vvv7(_rev_len_dat_bin));
for (_x = (int) (1) ; (step14 > 0 && _x <= limit14) || (step14 < 0 && _x >= limit14); _x = ((int)(0 + _x + step14)) ) {
 //BA.debugLineNum = 998;BA.debugLine="len_dat_bin = sf.Mid(rev_len_dat_bin, x, 1) & l";
_len_dat_bin = _sf._vvvv5(_rev_len_dat_bin,_x,(int) (1))+_len_dat_bin;
 }
};
 //BA.debugLineNum = 1001;BA.debugLine="rev_len_dat_bin = sf.Trim(rev_len_dat_bin)";
_rev_len_dat_bin = _sf._vvvvvvv4(_rev_len_dat_bin);
 //BA.debugLineNum = 1002;BA.debugLine="len_dat_bin = sf.Trim(len_dat_bin)";
_len_dat_bin = _sf._vvvvvvv4(_len_dat_bin);
 //BA.debugLineNum = 1004;BA.debugLine="getal1 = len_dat_bin";
_getal1 = _len_dat_bin;
 //BA.debugLineNum = 1006;BA.debugLine="Return getal1";
if (true) return _getal1;
 }else {
 //BA.debugLineNum = 1008;BA.debugLine="getal1 = \"00000000\"";
_getal1 = "00000000";
 //BA.debugLineNum = 1009;BA.debugLine="Return getal1";
if (true) return _getal1;
 };
 //BA.debugLineNum = 1012;BA.debugLine="End Sub";
return "";
}
public static int  _convert_to_decimal(anywheresoftware.b4a.BA _ba,String _bb) throws Exception{
int _waarde = 0;
int _i = 0;
 //BA.debugLineNum = 943;BA.debugLine="Private Sub convert_to_decimal(bb As String) As In";
 //BA.debugLineNum = 945;BA.debugLine="Dim waarde As Int";
_waarde = 0;
 //BA.debugLineNum = 946;BA.debugLine="waarde = 0    'convert binary to decimal";
_waarde = (int) (0);
 //BA.debugLineNum = 947;BA.debugLine="For i = 1 To 8";
{
final int step3 = 1;
final int limit3 = (int) (8);
for (_i = (int) (1) ; (step3 > 0 && _i <= limit3) || (step3 < 0 && _i >= limit3); _i = ((int)(0 + _i + step3)) ) {
 //BA.debugLineNum = 948;BA.debugLine="If sf.Mid(bb, i, 1) = 1 Then";
if ((_sf._vvvv5(_bb,_i,(int) (1))).equals(BA.NumberToString(1))) { 
 //BA.debugLineNum = 949;BA.debugLine="waarde = waarde + Power(2,(8 - i))";
_waarde = (int) (_waarde+anywheresoftware.b4a.keywords.Common.Power(2,(8-_i)));
 };
 }
};
 //BA.debugLineNum = 953;BA.debugLine="Return waarde";
if (true) return _waarde;
 //BA.debugLineNum = 955;BA.debugLine="End Sub";
return 0;
}
public static String  _determine_max_len(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 4001;BA.debugLine="Private Sub determine_max_len";
 //BA.debugLineNum = 4003;BA.debugLine="If error_level = \"L\" AND sf.len(dat) >= 0 Then ver";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>=0) { 
_version_no = (int) (1);};
 //BA.debugLineNum = 4004;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver1(64) Th";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver1[(int) (64)]) { 
_version_no = (int) (2);};
 //BA.debugLineNum = 4005;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver2(64) Th";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver2[(int) (64)]) { 
_version_no = (int) (3);};
 //BA.debugLineNum = 4006;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver3(64) Th";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver3[(int) (64)]) { 
_version_no = (int) (4);};
 //BA.debugLineNum = 4007;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver4(64) Th";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver4[(int) (64)]) { 
_version_no = (int) (5);};
 //BA.debugLineNum = 4008;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver5(64) Th";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver5[(int) (64)]) { 
_version_no = (int) (6);};
 //BA.debugLineNum = 4009;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver6(64) Th";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver6[(int) (64)]) { 
_version_no = (int) (7);};
 //BA.debugLineNum = 4010;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver7(64) Th";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver7[(int) (64)]) { 
_version_no = (int) (8);};
 //BA.debugLineNum = 4011;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver8(64) Th";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver8[(int) (64)]) { 
_version_no = (int) (9);};
 //BA.debugLineNum = 4012;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver9(64) Th";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver9[(int) (64)]) { 
_version_no = (int) (10);};
 //BA.debugLineNum = 4013;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver10(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver10[(int) (64)]) { 
_version_no = (int) (11);};
 //BA.debugLineNum = 4014;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver11(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver11[(int) (64)]) { 
_version_no = (int) (12);};
 //BA.debugLineNum = 4015;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver12(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver12[(int) (64)]) { 
_version_no = (int) (13);};
 //BA.debugLineNum = 4016;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver13(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver13[(int) (64)]) { 
_version_no = (int) (14);};
 //BA.debugLineNum = 4017;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver14(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver14[(int) (64)]) { 
_version_no = (int) (15);};
 //BA.debugLineNum = 4018;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver15(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver15[(int) (64)]) { 
_version_no = (int) (16);};
 //BA.debugLineNum = 4019;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver16(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver16[(int) (64)]) { 
_version_no = (int) (17);};
 //BA.debugLineNum = 4020;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver17(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver17[(int) (64)]) { 
_version_no = (int) (18);};
 //BA.debugLineNum = 4021;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver18(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver18[(int) (64)]) { 
_version_no = (int) (19);};
 //BA.debugLineNum = 4022;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver19(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver19[(int) (64)]) { 
_version_no = (int) (20);};
 //BA.debugLineNum = 4023;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver20(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver20[(int) (64)]) { 
_version_no = (int) (21);};
 //BA.debugLineNum = 4024;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver21(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver21[(int) (64)]) { 
_version_no = (int) (22);};
 //BA.debugLineNum = 4025;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver22(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver22[(int) (64)]) { 
_version_no = (int) (23);};
 //BA.debugLineNum = 4026;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver23(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver23[(int) (64)]) { 
_version_no = (int) (24);};
 //BA.debugLineNum = 4027;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver24(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver24[(int) (64)]) { 
_version_no = (int) (25);};
 //BA.debugLineNum = 4028;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver25(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver25[(int) (64)]) { 
_version_no = (int) (26);};
 //BA.debugLineNum = 4029;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver26(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver26[(int) (64)]) { 
_version_no = (int) (27);};
 //BA.debugLineNum = 4030;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver27(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver27[(int) (64)]) { 
_version_no = (int) (28);};
 //BA.debugLineNum = 4031;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver28(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver28[(int) (64)]) { 
_version_no = (int) (29);};
 //BA.debugLineNum = 4032;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver29(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver29[(int) (64)]) { 
_version_no = (int) (30);};
 //BA.debugLineNum = 4033;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver30(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver30[(int) (64)]) { 
_version_no = (int) (31);};
 //BA.debugLineNum = 4034;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver31(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver31[(int) (64)]) { 
_version_no = (int) (32);};
 //BA.debugLineNum = 4035;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver32(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver32[(int) (64)]) { 
_version_no = (int) (33);};
 //BA.debugLineNum = 4036;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver33(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver33[(int) (64)]) { 
_version_no = (int) (34);};
 //BA.debugLineNum = 4037;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver34(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver34[(int) (64)]) { 
_version_no = (int) (35);};
 //BA.debugLineNum = 4038;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver35(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver35[(int) (64)]) { 
_version_no = (int) (36);};
 //BA.debugLineNum = 4039;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver36(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver36[(int) (64)]) { 
_version_no = (int) (37);};
 //BA.debugLineNum = 4040;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver37(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver37[(int) (64)]) { 
_version_no = (int) (38);};
 //BA.debugLineNum = 4041;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver38(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver38[(int) (64)]) { 
_version_no = (int) (39);};
 //BA.debugLineNum = 4042;BA.debugLine="If error_level = \"L\" AND sf.len(dat) > ver39(64) T";
if ((_error_level).equals("L") && _sf._vvv7(_dat)>_ver39[(int) (64)]) { 
_version_no = (int) (40);};
 //BA.debugLineNum = 4044;BA.debugLine="If error_level = \"M\" AND sf.len(dat) >= 0 Then ver";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>=0) { 
_version_no = (int) (1);};
 //BA.debugLineNum = 4045;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver1(65) Th";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver1[(int) (65)]) { 
_version_no = (int) (2);};
 //BA.debugLineNum = 4046;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver2(65) Th";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver2[(int) (65)]) { 
_version_no = (int) (3);};
 //BA.debugLineNum = 4047;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver3(65) Th";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver3[(int) (65)]) { 
_version_no = (int) (4);};
 //BA.debugLineNum = 4048;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver4(65) Th";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver4[(int) (65)]) { 
_version_no = (int) (5);};
 //BA.debugLineNum = 4049;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver5(65) Th";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver5[(int) (65)]) { 
_version_no = (int) (6);};
 //BA.debugLineNum = 4050;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver6(65) Th";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver6[(int) (65)]) { 
_version_no = (int) (7);};
 //BA.debugLineNum = 4051;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver7(65) Th";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver7[(int) (65)]) { 
_version_no = (int) (8);};
 //BA.debugLineNum = 4052;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver8(65) Th";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver8[(int) (65)]) { 
_version_no = (int) (9);};
 //BA.debugLineNum = 4053;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver9(65) Th";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver9[(int) (65)]) { 
_version_no = (int) (10);};
 //BA.debugLineNum = 4054;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver10(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver10[(int) (65)]) { 
_version_no = (int) (11);};
 //BA.debugLineNum = 4055;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver11(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver11[(int) (65)]) { 
_version_no = (int) (12);};
 //BA.debugLineNum = 4056;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver12(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver12[(int) (65)]) { 
_version_no = (int) (13);};
 //BA.debugLineNum = 4057;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver13(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver13[(int) (65)]) { 
_version_no = (int) (14);};
 //BA.debugLineNum = 4058;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver14(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver14[(int) (65)]) { 
_version_no = (int) (15);};
 //BA.debugLineNum = 4059;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver15(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver15[(int) (65)]) { 
_version_no = (int) (16);};
 //BA.debugLineNum = 4060;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver16(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver16[(int) (65)]) { 
_version_no = (int) (17);};
 //BA.debugLineNum = 4061;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver17(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver17[(int) (65)]) { 
_version_no = (int) (18);};
 //BA.debugLineNum = 4062;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver18(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver18[(int) (65)]) { 
_version_no = (int) (19);};
 //BA.debugLineNum = 4063;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver19(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver19[(int) (65)]) { 
_version_no = (int) (20);};
 //BA.debugLineNum = 4064;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver20(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver20[(int) (65)]) { 
_version_no = (int) (21);};
 //BA.debugLineNum = 4065;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver21(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver21[(int) (65)]) { 
_version_no = (int) (22);};
 //BA.debugLineNum = 4066;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver22(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver22[(int) (65)]) { 
_version_no = (int) (23);};
 //BA.debugLineNum = 4067;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver23(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver23[(int) (65)]) { 
_version_no = (int) (24);};
 //BA.debugLineNum = 4068;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver24(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver24[(int) (65)]) { 
_version_no = (int) (25);};
 //BA.debugLineNum = 4069;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver25(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver25[(int) (65)]) { 
_version_no = (int) (26);};
 //BA.debugLineNum = 4070;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver26(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver26[(int) (65)]) { 
_version_no = (int) (27);};
 //BA.debugLineNum = 4071;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver27(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver27[(int) (65)]) { 
_version_no = (int) (28);};
 //BA.debugLineNum = 4072;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver28(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver28[(int) (65)]) { 
_version_no = (int) (29);};
 //BA.debugLineNum = 4073;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver29(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver29[(int) (65)]) { 
_version_no = (int) (30);};
 //BA.debugLineNum = 4074;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver30(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver30[(int) (65)]) { 
_version_no = (int) (31);};
 //BA.debugLineNum = 4075;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver31(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver31[(int) (65)]) { 
_version_no = (int) (32);};
 //BA.debugLineNum = 4076;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver32(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver32[(int) (65)]) { 
_version_no = (int) (33);};
 //BA.debugLineNum = 4077;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver33(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver33[(int) (65)]) { 
_version_no = (int) (34);};
 //BA.debugLineNum = 4078;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver34(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver34[(int) (65)]) { 
_version_no = (int) (35);};
 //BA.debugLineNum = 4079;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver35(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver35[(int) (65)]) { 
_version_no = (int) (36);};
 //BA.debugLineNum = 4080;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver36(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver36[(int) (65)]) { 
_version_no = (int) (37);};
 //BA.debugLineNum = 4081;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver37(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver37[(int) (65)]) { 
_version_no = (int) (38);};
 //BA.debugLineNum = 4082;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver38(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver38[(int) (65)]) { 
_version_no = (int) (39);};
 //BA.debugLineNum = 4083;BA.debugLine="If error_level = \"M\" AND sf.len(dat) > ver39(65) T";
if ((_error_level).equals("M") && _sf._vvv7(_dat)>_ver39[(int) (65)]) { 
_version_no = (int) (40);};
 //BA.debugLineNum = 4085;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) >= 0 Then ver";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>=0) { 
_version_no = (int) (1);};
 //BA.debugLineNum = 4086;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver1(66) Th";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver1[(int) (66)]) { 
_version_no = (int) (2);};
 //BA.debugLineNum = 4087;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver2(66) Th";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver2[(int) (66)]) { 
_version_no = (int) (3);};
 //BA.debugLineNum = 4088;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver3(66) Th";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver3[(int) (66)]) { 
_version_no = (int) (4);};
 //BA.debugLineNum = 4089;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver4(66) Th";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver4[(int) (66)]) { 
_version_no = (int) (5);};
 //BA.debugLineNum = 4090;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver5(66) Th";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver5[(int) (66)]) { 
_version_no = (int) (6);};
 //BA.debugLineNum = 4091;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver6(66) Th";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver6[(int) (66)]) { 
_version_no = (int) (7);};
 //BA.debugLineNum = 4092;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver7(66) Th";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver7[(int) (66)]) { 
_version_no = (int) (8);};
 //BA.debugLineNum = 4093;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver8(66) Th";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver8[(int) (66)]) { 
_version_no = (int) (9);};
 //BA.debugLineNum = 4094;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver9(66) Th";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver9[(int) (66)]) { 
_version_no = (int) (10);};
 //BA.debugLineNum = 4095;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver10(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver10[(int) (66)]) { 
_version_no = (int) (11);};
 //BA.debugLineNum = 4096;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver11(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver11[(int) (66)]) { 
_version_no = (int) (12);};
 //BA.debugLineNum = 4097;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver12(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver12[(int) (66)]) { 
_version_no = (int) (13);};
 //BA.debugLineNum = 4098;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver13(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver13[(int) (66)]) { 
_version_no = (int) (14);};
 //BA.debugLineNum = 4099;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver14(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver14[(int) (66)]) { 
_version_no = (int) (15);};
 //BA.debugLineNum = 4100;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver15(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver15[(int) (66)]) { 
_version_no = (int) (16);};
 //BA.debugLineNum = 4101;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver16(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver16[(int) (66)]) { 
_version_no = (int) (17);};
 //BA.debugLineNum = 4102;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver17(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver17[(int) (66)]) { 
_version_no = (int) (18);};
 //BA.debugLineNum = 4103;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver18(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver18[(int) (66)]) { 
_version_no = (int) (19);};
 //BA.debugLineNum = 4104;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver19(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver19[(int) (66)]) { 
_version_no = (int) (20);};
 //BA.debugLineNum = 4105;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver20(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver20[(int) (66)]) { 
_version_no = (int) (21);};
 //BA.debugLineNum = 4106;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver21(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver21[(int) (66)]) { 
_version_no = (int) (22);};
 //BA.debugLineNum = 4107;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver22(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver22[(int) (66)]) { 
_version_no = (int) (23);};
 //BA.debugLineNum = 4108;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver23(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver23[(int) (66)]) { 
_version_no = (int) (24);};
 //BA.debugLineNum = 4109;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver24(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver24[(int) (66)]) { 
_version_no = (int) (25);};
 //BA.debugLineNum = 4110;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver25(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver25[(int) (66)]) { 
_version_no = (int) (26);};
 //BA.debugLineNum = 4111;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver26(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver26[(int) (66)]) { 
_version_no = (int) (27);};
 //BA.debugLineNum = 4112;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver27(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver27[(int) (66)]) { 
_version_no = (int) (28);};
 //BA.debugLineNum = 4113;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver28(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver28[(int) (66)]) { 
_version_no = (int) (29);};
 //BA.debugLineNum = 4114;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver29(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver29[(int) (66)]) { 
_version_no = (int) (30);};
 //BA.debugLineNum = 4115;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver30(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver30[(int) (66)]) { 
_version_no = (int) (31);};
 //BA.debugLineNum = 4116;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver31(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver31[(int) (66)]) { 
_version_no = (int) (32);};
 //BA.debugLineNum = 4117;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver32(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver32[(int) (66)]) { 
_version_no = (int) (33);};
 //BA.debugLineNum = 4118;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver33(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver33[(int) (66)]) { 
_version_no = (int) (34);};
 //BA.debugLineNum = 4119;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver34(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver34[(int) (66)]) { 
_version_no = (int) (35);};
 //BA.debugLineNum = 4120;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver35(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver35[(int) (66)]) { 
_version_no = (int) (36);};
 //BA.debugLineNum = 4121;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver36(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver36[(int) (66)]) { 
_version_no = (int) (37);};
 //BA.debugLineNum = 4122;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver37(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver37[(int) (66)]) { 
_version_no = (int) (38);};
 //BA.debugLineNum = 4123;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver38(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver38[(int) (66)]) { 
_version_no = (int) (39);};
 //BA.debugLineNum = 4124;BA.debugLine="If error_level = \"Q\" AND sf.len(dat) > ver39(66) T";
if ((_error_level).equals("Q") && _sf._vvv7(_dat)>_ver39[(int) (66)]) { 
_version_no = (int) (40);};
 //BA.debugLineNum = 4126;BA.debugLine="If error_level = \"H\" AND sf.len(dat) >= 0 Then ver";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>=0) { 
_version_no = (int) (1);};
 //BA.debugLineNum = 4127;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver1(67) Th";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver1[(int) (67)]) { 
_version_no = (int) (2);};
 //BA.debugLineNum = 4128;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver2(67) Th";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver2[(int) (67)]) { 
_version_no = (int) (3);};
 //BA.debugLineNum = 4129;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver3(67) Th";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver3[(int) (67)]) { 
_version_no = (int) (4);};
 //BA.debugLineNum = 4130;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver4(67) Th";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver4[(int) (67)]) { 
_version_no = (int) (5);};
 //BA.debugLineNum = 4131;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver5(67) Th";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver5[(int) (67)]) { 
_version_no = (int) (6);};
 //BA.debugLineNum = 4132;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver6(67) Th";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver6[(int) (67)]) { 
_version_no = (int) (7);};
 //BA.debugLineNum = 4133;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver7(67) Th";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver7[(int) (67)]) { 
_version_no = (int) (8);};
 //BA.debugLineNum = 4134;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver8(67) Th";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver8[(int) (67)]) { 
_version_no = (int) (9);};
 //BA.debugLineNum = 4135;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver9(67) Th";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver9[(int) (67)]) { 
_version_no = (int) (10);};
 //BA.debugLineNum = 4136;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver10(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver10[(int) (67)]) { 
_version_no = (int) (11);};
 //BA.debugLineNum = 4137;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver11(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver11[(int) (67)]) { 
_version_no = (int) (12);};
 //BA.debugLineNum = 4138;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver12(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver12[(int) (67)]) { 
_version_no = (int) (13);};
 //BA.debugLineNum = 4139;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver13(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver13[(int) (67)]) { 
_version_no = (int) (14);};
 //BA.debugLineNum = 4140;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver14(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver14[(int) (67)]) { 
_version_no = (int) (15);};
 //BA.debugLineNum = 4141;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver15(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver15[(int) (67)]) { 
_version_no = (int) (16);};
 //BA.debugLineNum = 4142;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver16(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver16[(int) (67)]) { 
_version_no = (int) (17);};
 //BA.debugLineNum = 4143;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver17(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver17[(int) (67)]) { 
_version_no = (int) (18);};
 //BA.debugLineNum = 4144;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver18(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver18[(int) (67)]) { 
_version_no = (int) (19);};
 //BA.debugLineNum = 4145;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver19(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver19[(int) (67)]) { 
_version_no = (int) (20);};
 //BA.debugLineNum = 4146;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver20(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver20[(int) (67)]) { 
_version_no = (int) (21);};
 //BA.debugLineNum = 4147;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver21(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver21[(int) (67)]) { 
_version_no = (int) (22);};
 //BA.debugLineNum = 4148;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver22(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver22[(int) (67)]) { 
_version_no = (int) (23);};
 //BA.debugLineNum = 4149;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver23(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver23[(int) (67)]) { 
_version_no = (int) (24);};
 //BA.debugLineNum = 4150;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver24(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver24[(int) (67)]) { 
_version_no = (int) (25);};
 //BA.debugLineNum = 4151;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver25(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver25[(int) (67)]) { 
_version_no = (int) (26);};
 //BA.debugLineNum = 4152;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver26(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver26[(int) (67)]) { 
_version_no = (int) (27);};
 //BA.debugLineNum = 4153;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver27(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver27[(int) (67)]) { 
_version_no = (int) (28);};
 //BA.debugLineNum = 4154;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver28(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver28[(int) (67)]) { 
_version_no = (int) (29);};
 //BA.debugLineNum = 4155;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver29(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver29[(int) (67)]) { 
_version_no = (int) (30);};
 //BA.debugLineNum = 4156;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver30(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver30[(int) (67)]) { 
_version_no = (int) (31);};
 //BA.debugLineNum = 4157;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver31(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver31[(int) (67)]) { 
_version_no = (int) (32);};
 //BA.debugLineNum = 4158;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver32(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver32[(int) (67)]) { 
_version_no = (int) (33);};
 //BA.debugLineNum = 4159;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver33(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver33[(int) (67)]) { 
_version_no = (int) (34);};
 //BA.debugLineNum = 4160;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver34(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver34[(int) (67)]) { 
_version_no = (int) (35);};
 //BA.debugLineNum = 4161;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver35(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver35[(int) (67)]) { 
_version_no = (int) (36);};
 //BA.debugLineNum = 4162;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver36(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver36[(int) (67)]) { 
_version_no = (int) (37);};
 //BA.debugLineNum = 4163;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver37(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver37[(int) (67)]) { 
_version_no = (int) (38);};
 //BA.debugLineNum = 4164;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver38(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver38[(int) (67)]) { 
_version_no = (int) (39);};
 //BA.debugLineNum = 4165;BA.debugLine="If error_level = \"H\" AND sf.len(dat) > ver39(67) T";
if ((_error_level).equals("H") && _sf._vvv7(_dat)>_ver39[(int) (67)]) { 
_version_no = (int) (40);};
 //BA.debugLineNum = 4167;BA.debugLine="If version_no = 1 AND error_level = \"L\" AND tipe";
if (_version_no==1 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver1[(int) (64)];};
 //BA.debugLineNum = 4168;BA.debugLine="If version_no = 1 AND error_level = \"M\" AND tipe";
if (_version_no==1 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver1[(int) (65)];};
 //BA.debugLineNum = 4169;BA.debugLine="If version_no = 1 AND error_level = \"Q\" AND tipe";
if (_version_no==1 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver1[(int) (66)];};
 //BA.debugLineNum = 4170;BA.debugLine="If version_no = 1 AND error_level = \"H\" AND tipe";
if (_version_no==1 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver1[(int) (67)];};
 //BA.debugLineNum = 4171;BA.debugLine="If version_no = 1 AND error_level = \"L\" AND tipe";
if (_version_no==1 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver1[(int) (68)];};
 //BA.debugLineNum = 4172;BA.debugLine="If version_no = 1 AND error_level = \"M\" AND tipe";
if (_version_no==1 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver1[(int) (69)];};
 //BA.debugLineNum = 4173;BA.debugLine="If version_no = 1 AND error_level = \"Q\" AND tipe";
if (_version_no==1 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver1[(int) (70)];};
 //BA.debugLineNum = 4174;BA.debugLine="If version_no = 1 AND error_level = \"H\" AND tipe";
if (_version_no==1 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver1[(int) (71)];};
 //BA.debugLineNum = 4175;BA.debugLine="If version_no = 1 AND error_level = \"L\" AND tipe";
if (_version_no==1 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver1[(int) (72)];};
 //BA.debugLineNum = 4176;BA.debugLine="If version_no = 1 AND error_level = \"M\" AND tipe";
if (_version_no==1 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver1[(int) (73)];};
 //BA.debugLineNum = 4177;BA.debugLine="If version_no = 1 AND error_level = \"Q\" AND tipe";
if (_version_no==1 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver1[(int) (74)];};
 //BA.debugLineNum = 4178;BA.debugLine="If version_no = 1 AND error_level = \"H\" AND tipe";
if (_version_no==1 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver1[(int) (75)];};
 //BA.debugLineNum = 4180;BA.debugLine="If version_no = 2 AND error_level = \"L\" AND tipe";
if (_version_no==2 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver2[(int) (64)];};
 //BA.debugLineNum = 4181;BA.debugLine="If version_no = 2 AND error_level = \"M\" AND tipe";
if (_version_no==2 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver2[(int) (65)];};
 //BA.debugLineNum = 4182;BA.debugLine="If version_no = 2 AND error_level = \"Q\" AND tipe";
if (_version_no==2 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver2[(int) (66)];};
 //BA.debugLineNum = 4183;BA.debugLine="If version_no = 2 AND error_level = \"H\" AND tipe";
if (_version_no==2 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver2[(int) (67)];};
 //BA.debugLineNum = 4184;BA.debugLine="If version_no = 2 AND error_level = \"L\" AND tipe";
if (_version_no==2 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver2[(int) (68)];};
 //BA.debugLineNum = 4185;BA.debugLine="If version_no = 2 AND error_level = \"M\" AND tipe";
if (_version_no==2 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver2[(int) (69)];};
 //BA.debugLineNum = 4186;BA.debugLine="If version_no = 2 AND error_level = \"Q\" AND tipe";
if (_version_no==2 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver2[(int) (70)];};
 //BA.debugLineNum = 4187;BA.debugLine="If version_no = 2 AND error_level = \"H\" AND tipe";
if (_version_no==2 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver2[(int) (71)];};
 //BA.debugLineNum = 4188;BA.debugLine="If version_no = 2 AND error_level = \"L\" AND tipe";
if (_version_no==2 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver2[(int) (72)];};
 //BA.debugLineNum = 4189;BA.debugLine="If version_no = 2 AND error_level = \"M\" AND tipe";
if (_version_no==2 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver2[(int) (73)];};
 //BA.debugLineNum = 4190;BA.debugLine="If version_no = 2 AND error_level = \"Q\" AND tipe";
if (_version_no==2 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver2[(int) (74)];};
 //BA.debugLineNum = 4191;BA.debugLine="If version_no = 2 AND error_level = \"H\" AND tipe";
if (_version_no==2 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver2[(int) (75)];};
 //BA.debugLineNum = 4193;BA.debugLine="If version_no = 3 AND error_level = \"L\" AND tipe";
if (_version_no==3 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver3[(int) (64)];};
 //BA.debugLineNum = 4194;BA.debugLine="If version_no = 3 AND error_level = \"M\" AND tipe";
if (_version_no==3 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver3[(int) (65)];};
 //BA.debugLineNum = 4195;BA.debugLine="If version_no = 3 AND error_level = \"Q\" AND tipe";
if (_version_no==3 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver3[(int) (66)];};
 //BA.debugLineNum = 4196;BA.debugLine="If version_no = 3 AND error_level = \"H\" AND tipe";
if (_version_no==3 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver3[(int) (67)];};
 //BA.debugLineNum = 4197;BA.debugLine="If version_no = 3 AND error_level = \"L\" AND tipe";
if (_version_no==3 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver3[(int) (68)];};
 //BA.debugLineNum = 4198;BA.debugLine="If version_no = 3 AND error_level = \"M\" AND tipe";
if (_version_no==3 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver3[(int) (69)];};
 //BA.debugLineNum = 4199;BA.debugLine="If version_no = 3 AND error_level = \"Q\" AND tipe";
if (_version_no==3 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver3[(int) (70)];};
 //BA.debugLineNum = 4200;BA.debugLine="If version_no = 3 AND error_level = \"H\" AND tipe";
if (_version_no==3 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver3[(int) (71)];};
 //BA.debugLineNum = 4201;BA.debugLine="If version_no = 3 AND error_level = \"L\" AND tipe";
if (_version_no==3 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver3[(int) (72)];};
 //BA.debugLineNum = 4202;BA.debugLine="If version_no = 3 AND error_level = \"M\" AND tipe";
if (_version_no==3 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver3[(int) (73)];};
 //BA.debugLineNum = 4203;BA.debugLine="If version_no = 3 AND error_level = \"Q\" AND tipe";
if (_version_no==3 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver3[(int) (74)];};
 //BA.debugLineNum = 4204;BA.debugLine="If version_no = 3 AND error_level = \"H\" AND tipe";
if (_version_no==3 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver3[(int) (75)];};
 //BA.debugLineNum = 4206;BA.debugLine="If version_no = 4 AND error_level = \"L\" AND tipe";
if (_version_no==4 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver4[(int) (64)];};
 //BA.debugLineNum = 4207;BA.debugLine="If version_no = 4 AND error_level = \"M\" AND tipe";
if (_version_no==4 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver4[(int) (65)];};
 //BA.debugLineNum = 4208;BA.debugLine="If version_no = 4 AND error_level = \"Q\" AND tipe";
if (_version_no==4 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver4[(int) (66)];};
 //BA.debugLineNum = 4209;BA.debugLine="If version_no = 4 AND error_level = \"H\" AND tipe";
if (_version_no==4 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver4[(int) (67)];};
 //BA.debugLineNum = 4210;BA.debugLine="If version_no = 4 AND error_level = \"L\" AND tipe";
if (_version_no==4 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver4[(int) (68)];};
 //BA.debugLineNum = 4211;BA.debugLine="If version_no = 4 AND error_level = \"M\" AND tipe";
if (_version_no==4 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver4[(int) (69)];};
 //BA.debugLineNum = 4212;BA.debugLine="If version_no = 4 AND error_level = \"Q\" AND tipe";
if (_version_no==4 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver4[(int) (70)];};
 //BA.debugLineNum = 4213;BA.debugLine="If version_no = 4 AND error_level = \"H\" AND tipe";
if (_version_no==4 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver4[(int) (71)];};
 //BA.debugLineNum = 4214;BA.debugLine="If version_no = 4 AND error_level = \"L\" AND tipe";
if (_version_no==4 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver4[(int) (72)];};
 //BA.debugLineNum = 4215;BA.debugLine="If version_no = 4 AND error_level = \"M\" AND tipe";
if (_version_no==4 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver4[(int) (73)];};
 //BA.debugLineNum = 4216;BA.debugLine="If version_no = 4 AND error_level = \"Q\" AND tipe";
if (_version_no==4 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver4[(int) (74)];};
 //BA.debugLineNum = 4217;BA.debugLine="If version_no = 4 AND error_level = \"H\" AND tipe";
if (_version_no==4 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver4[(int) (75)];};
 //BA.debugLineNum = 4219;BA.debugLine="If version_no = 5 AND error_level = \"L\" AND tipe";
if (_version_no==5 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver5[(int) (64)];};
 //BA.debugLineNum = 4220;BA.debugLine="If version_no = 5 AND error_level = \"M\" AND tipe";
if (_version_no==5 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver5[(int) (65)];};
 //BA.debugLineNum = 4221;BA.debugLine="If version_no = 5 AND error_level = \"Q\" AND tipe";
if (_version_no==5 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver5[(int) (66)];};
 //BA.debugLineNum = 4222;BA.debugLine="If version_no = 5 AND error_level = \"H\" AND tipe";
if (_version_no==5 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver5[(int) (67)];};
 //BA.debugLineNum = 4223;BA.debugLine="If version_no = 5 AND error_level = \"L\" AND tipe";
if (_version_no==5 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver5[(int) (68)];};
 //BA.debugLineNum = 4224;BA.debugLine="If version_no = 5 AND error_level = \"M\" AND tipe";
if (_version_no==5 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver5[(int) (69)];};
 //BA.debugLineNum = 4225;BA.debugLine="If version_no = 5 AND error_level = \"Q\" AND tipe";
if (_version_no==5 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver5[(int) (70)];};
 //BA.debugLineNum = 4226;BA.debugLine="If version_no = 5 AND error_level = \"H\" AND tipe";
if (_version_no==5 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver5[(int) (71)];};
 //BA.debugLineNum = 4227;BA.debugLine="If version_no = 5 AND error_level = \"L\" AND tipe";
if (_version_no==5 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver5[(int) (72)];};
 //BA.debugLineNum = 4228;BA.debugLine="If version_no = 5 AND error_level = \"M\" AND tipe";
if (_version_no==5 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver5[(int) (73)];};
 //BA.debugLineNum = 4229;BA.debugLine="If version_no = 5 AND error_level = \"Q\" AND tipe";
if (_version_no==5 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver5[(int) (74)];};
 //BA.debugLineNum = 4230;BA.debugLine="If version_no = 5 AND error_level = \"H\" AND tipe";
if (_version_no==5 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver5[(int) (75)];};
 //BA.debugLineNum = 4232;BA.debugLine="If version_no = 6 AND error_level = \"L\" AND tipe";
if (_version_no==6 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver6[(int) (64)];};
 //BA.debugLineNum = 4233;BA.debugLine="If version_no = 6 AND error_level = \"M\" AND tipe";
if (_version_no==6 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver6[(int) (65)];};
 //BA.debugLineNum = 4234;BA.debugLine="If version_no = 6 AND error_level = \"Q\" AND tipe";
if (_version_no==6 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver6[(int) (66)];};
 //BA.debugLineNum = 4235;BA.debugLine="If version_no = 6 AND error_level = \"H\" AND tipe";
if (_version_no==6 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver6[(int) (67)];};
 //BA.debugLineNum = 4236;BA.debugLine="If version_no = 6 AND error_level = \"L\" AND tipe";
if (_version_no==6 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver6[(int) (68)];};
 //BA.debugLineNum = 4237;BA.debugLine="If version_no = 6 AND error_level = \"M\" AND tipe";
if (_version_no==6 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver6[(int) (69)];};
 //BA.debugLineNum = 4238;BA.debugLine="If version_no = 6 AND error_level = \"Q\" AND tipe";
if (_version_no==6 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver6[(int) (70)];};
 //BA.debugLineNum = 4239;BA.debugLine="If version_no = 6 AND error_level = \"H\" AND tipe";
if (_version_no==6 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver6[(int) (71)];};
 //BA.debugLineNum = 4240;BA.debugLine="If version_no = 6 AND error_level = \"L\" AND tipe";
if (_version_no==6 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver6[(int) (72)];};
 //BA.debugLineNum = 4241;BA.debugLine="If version_no = 6 AND error_level = \"M\" AND tipe";
if (_version_no==6 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver6[(int) (73)];};
 //BA.debugLineNum = 4242;BA.debugLine="If version_no = 6 AND error_level = \"Q\" AND tipe";
if (_version_no==6 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver6[(int) (74)];};
 //BA.debugLineNum = 4243;BA.debugLine="If version_no = 6 AND error_level = \"H\" AND tipe";
if (_version_no==6 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver6[(int) (75)];};
 //BA.debugLineNum = 4245;BA.debugLine="If version_no = 7 AND error_level = \"L\" AND tipe";
if (_version_no==7 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver7[(int) (64)];};
 //BA.debugLineNum = 4246;BA.debugLine="If version_no = 7 AND error_level = \"M\" AND tipe";
if (_version_no==7 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver7[(int) (65)];};
 //BA.debugLineNum = 4247;BA.debugLine="If version_no = 7 AND error_level = \"Q\" AND tipe";
if (_version_no==7 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver7[(int) (66)];};
 //BA.debugLineNum = 4248;BA.debugLine="If version_no = 7 AND error_level = \"H\" AND tipe";
if (_version_no==7 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver7[(int) (67)];};
 //BA.debugLineNum = 4249;BA.debugLine="If version_no = 7 AND error_level = \"L\" AND tipe";
if (_version_no==7 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver7[(int) (68)];};
 //BA.debugLineNum = 4250;BA.debugLine="If version_no = 7 AND error_level = \"M\" AND tipe";
if (_version_no==7 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver7[(int) (69)];};
 //BA.debugLineNum = 4251;BA.debugLine="If version_no = 7 AND error_level = \"Q\" AND tipe";
if (_version_no==7 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver7[(int) (70)];};
 //BA.debugLineNum = 4252;BA.debugLine="If version_no = 7 AND error_level = \"H\" AND tipe";
if (_version_no==7 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver7[(int) (71)];};
 //BA.debugLineNum = 4253;BA.debugLine="If version_no = 7 AND error_level = \"L\" AND tipe";
if (_version_no==7 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver7[(int) (72)];};
 //BA.debugLineNum = 4254;BA.debugLine="If version_no = 7 AND error_level = \"M\" AND tipe";
if (_version_no==7 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver7[(int) (73)];};
 //BA.debugLineNum = 4255;BA.debugLine="If version_no = 7 AND error_level = \"Q\" AND tipe";
if (_version_no==7 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver7[(int) (74)];};
 //BA.debugLineNum = 4256;BA.debugLine="If version_no = 7 AND error_level = \"H\" AND tipe";
if (_version_no==7 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver7[(int) (75)];};
 //BA.debugLineNum = 4258;BA.debugLine="If version_no = 8 AND error_level = \"L\" AND tipe";
if (_version_no==8 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver8[(int) (64)];};
 //BA.debugLineNum = 4259;BA.debugLine="If version_no = 8 AND error_level = \"M\" AND tipe";
if (_version_no==8 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver8[(int) (65)];};
 //BA.debugLineNum = 4260;BA.debugLine="If version_no = 8 AND error_level = \"Q\" AND tipe";
if (_version_no==8 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver8[(int) (66)];};
 //BA.debugLineNum = 4261;BA.debugLine="If version_no = 8 AND error_level = \"H\" AND tipe";
if (_version_no==8 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver8[(int) (67)];};
 //BA.debugLineNum = 4262;BA.debugLine="If version_no = 8 AND error_level = \"L\" AND tipe";
if (_version_no==8 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver8[(int) (68)];};
 //BA.debugLineNum = 4263;BA.debugLine="If version_no = 8 AND error_level = \"M\" AND tipe";
if (_version_no==8 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver8[(int) (69)];};
 //BA.debugLineNum = 4264;BA.debugLine="If version_no = 8 AND error_level = \"Q\" AND tipe";
if (_version_no==8 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver8[(int) (70)];};
 //BA.debugLineNum = 4265;BA.debugLine="If version_no = 8 AND error_level = \"H\" AND tipe";
if (_version_no==8 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver8[(int) (71)];};
 //BA.debugLineNum = 4266;BA.debugLine="If version_no = 8 AND error_level = \"L\" AND tipe";
if (_version_no==8 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver8[(int) (72)];};
 //BA.debugLineNum = 4267;BA.debugLine="If version_no = 8 AND error_level = \"M\" AND tipe";
if (_version_no==8 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver8[(int) (73)];};
 //BA.debugLineNum = 4268;BA.debugLine="If version_no = 8 AND error_level = \"Q\" AND tipe";
if (_version_no==8 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver8[(int) (74)];};
 //BA.debugLineNum = 4269;BA.debugLine="If version_no = 8 AND error_level = \"H\" AND tipe";
if (_version_no==8 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver8[(int) (75)];};
 //BA.debugLineNum = 4271;BA.debugLine="If version_no = 9 AND error_level = \"L\" AND tipe";
if (_version_no==9 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver9[(int) (64)];};
 //BA.debugLineNum = 4272;BA.debugLine="If version_no = 9 AND error_level = \"M\" AND tipe";
if (_version_no==9 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver9[(int) (65)];};
 //BA.debugLineNum = 4273;BA.debugLine="If version_no = 9 AND error_level = \"Q\" AND tipe";
if (_version_no==9 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver9[(int) (66)];};
 //BA.debugLineNum = 4274;BA.debugLine="If version_no = 9 AND error_level = \"H\" AND tipe";
if (_version_no==9 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver9[(int) (67)];};
 //BA.debugLineNum = 4275;BA.debugLine="If version_no = 9 AND error_level = \"L\" AND tipe";
if (_version_no==9 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver9[(int) (68)];};
 //BA.debugLineNum = 4276;BA.debugLine="If version_no = 9 AND error_level = \"M\" AND tipe";
if (_version_no==9 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver9[(int) (69)];};
 //BA.debugLineNum = 4277;BA.debugLine="If version_no = 9 AND error_level = \"Q\" AND tipe";
if (_version_no==9 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver9[(int) (70)];};
 //BA.debugLineNum = 4278;BA.debugLine="If version_no = 9 AND error_level = \"H\" AND tipe";
if (_version_no==9 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver9[(int) (71)];};
 //BA.debugLineNum = 4279;BA.debugLine="If version_no = 9 AND error_level = \"L\" AND tipe";
if (_version_no==9 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver9[(int) (72)];};
 //BA.debugLineNum = 4280;BA.debugLine="If version_no = 9 AND error_level = \"M\" AND tipe";
if (_version_no==9 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver9[(int) (73)];};
 //BA.debugLineNum = 4281;BA.debugLine="If version_no = 9 AND error_level = \"Q\" AND tipe";
if (_version_no==9 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver9[(int) (74)];};
 //BA.debugLineNum = 4282;BA.debugLine="If version_no = 9 AND error_level = \"H\" AND tipe";
if (_version_no==9 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver9[(int) (75)];};
 //BA.debugLineNum = 4284;BA.debugLine="If version_no = 10 AND error_level = \"L\" AND tipe";
if (_version_no==10 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver10[(int) (64)];};
 //BA.debugLineNum = 4285;BA.debugLine="If version_no = 10 AND error_level = \"M\" AND tipe";
if (_version_no==10 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver10[(int) (65)];};
 //BA.debugLineNum = 4286;BA.debugLine="If version_no = 10 AND error_level = \"Q\" AND tipe";
if (_version_no==10 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver10[(int) (66)];};
 //BA.debugLineNum = 4287;BA.debugLine="If version_no = 10 AND error_level = \"H\" AND tipe";
if (_version_no==10 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver10[(int) (67)];};
 //BA.debugLineNum = 4288;BA.debugLine="If version_no = 10 AND error_level = \"L\" AND tipe";
if (_version_no==10 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver10[(int) (68)];};
 //BA.debugLineNum = 4289;BA.debugLine="If version_no = 10 AND error_level = \"M\" AND tipe";
if (_version_no==10 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver10[(int) (69)];};
 //BA.debugLineNum = 4290;BA.debugLine="If version_no = 10 AND error_level = \"Q\" AND tipe";
if (_version_no==10 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver10[(int) (70)];};
 //BA.debugLineNum = 4291;BA.debugLine="If version_no = 10 AND error_level = \"H\" AND tipe";
if (_version_no==10 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver10[(int) (71)];};
 //BA.debugLineNum = 4292;BA.debugLine="If version_no = 10 AND error_level = \"L\" AND tipe";
if (_version_no==10 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver10[(int) (72)];};
 //BA.debugLineNum = 4293;BA.debugLine="If version_no = 10 AND error_level = \"M\" AND tipe";
if (_version_no==10 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver10[(int) (73)];};
 //BA.debugLineNum = 4294;BA.debugLine="If version_no = 10 AND error_level = \"Q\" AND tipe";
if (_version_no==10 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver10[(int) (74)];};
 //BA.debugLineNum = 4295;BA.debugLine="If version_no = 10 AND error_level = \"H\" AND tipe";
if (_version_no==10 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver10[(int) (75)];};
 //BA.debugLineNum = 4297;BA.debugLine="If version_no = 11 AND error_level = \"L\" AND tipe";
if (_version_no==11 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver11[(int) (64)];};
 //BA.debugLineNum = 4298;BA.debugLine="If version_no = 11 AND error_level = \"M\" AND tipe";
if (_version_no==11 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver11[(int) (65)];};
 //BA.debugLineNum = 4299;BA.debugLine="If version_no = 11 AND error_level = \"Q\" AND tipe";
if (_version_no==11 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver11[(int) (66)];};
 //BA.debugLineNum = 4300;BA.debugLine="If version_no = 11 AND error_level = \"H\" AND tipe";
if (_version_no==11 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver11[(int) (67)];};
 //BA.debugLineNum = 4301;BA.debugLine="If version_no = 11 AND error_level = \"L\" AND tipe";
if (_version_no==11 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver11[(int) (68)];};
 //BA.debugLineNum = 4302;BA.debugLine="If version_no = 11 AND error_level = \"M\" AND tipe";
if (_version_no==11 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver11[(int) (69)];};
 //BA.debugLineNum = 4303;BA.debugLine="If version_no = 11 AND error_level = \"Q\" AND tipe";
if (_version_no==11 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver11[(int) (70)];};
 //BA.debugLineNum = 4304;BA.debugLine="If version_no = 11 AND error_level = \"H\" AND tipe";
if (_version_no==11 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver11[(int) (71)];};
 //BA.debugLineNum = 4305;BA.debugLine="If version_no = 11 AND error_level = \"L\" AND tipe";
if (_version_no==11 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver11[(int) (72)];};
 //BA.debugLineNum = 4306;BA.debugLine="If version_no = 11 AND error_level = \"M\" AND tipe";
if (_version_no==11 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver11[(int) (73)];};
 //BA.debugLineNum = 4307;BA.debugLine="If version_no = 11 AND error_level = \"Q\" AND tipe";
if (_version_no==11 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver11[(int) (74)];};
 //BA.debugLineNum = 4308;BA.debugLine="If version_no = 11 AND error_level = \"H\" AND tipe";
if (_version_no==11 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver11[(int) (75)];};
 //BA.debugLineNum = 4310;BA.debugLine="If version_no = 12 AND error_level = \"L\" AND tipe";
if (_version_no==12 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver12[(int) (64)];};
 //BA.debugLineNum = 4311;BA.debugLine="If version_no = 12 AND error_level = \"M\" AND tipe";
if (_version_no==12 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver12[(int) (65)];};
 //BA.debugLineNum = 4312;BA.debugLine="If version_no = 12 AND error_level = \"Q\" AND tipe";
if (_version_no==12 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver12[(int) (66)];};
 //BA.debugLineNum = 4313;BA.debugLine="If version_no = 12 AND error_level = \"H\" AND tipe";
if (_version_no==12 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver12[(int) (67)];};
 //BA.debugLineNum = 4314;BA.debugLine="If version_no = 12 AND error_level = \"L\" AND tipe";
if (_version_no==12 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver12[(int) (68)];};
 //BA.debugLineNum = 4315;BA.debugLine="If version_no = 12 AND error_level = \"M\" AND tipe";
if (_version_no==12 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver12[(int) (69)];};
 //BA.debugLineNum = 4316;BA.debugLine="If version_no = 12 AND error_level = \"Q\" AND tipe";
if (_version_no==12 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver12[(int) (70)];};
 //BA.debugLineNum = 4317;BA.debugLine="If version_no = 12 AND error_level = \"H\" AND tipe";
if (_version_no==12 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver12[(int) (71)];};
 //BA.debugLineNum = 4318;BA.debugLine="If version_no = 12 AND error_level = \"L\" AND tipe";
if (_version_no==12 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver12[(int) (72)];};
 //BA.debugLineNum = 4319;BA.debugLine="If version_no = 12 AND error_level = \"M\" AND tipe";
if (_version_no==12 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver12[(int) (73)];};
 //BA.debugLineNum = 4320;BA.debugLine="If version_no = 12 AND error_level = \"Q\" AND tipe";
if (_version_no==12 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver12[(int) (74)];};
 //BA.debugLineNum = 4321;BA.debugLine="If version_no = 12 AND error_level = \"H\" AND tipe";
if (_version_no==12 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver12[(int) (75)];};
 //BA.debugLineNum = 4323;BA.debugLine="If version_no = 13 AND error_level = \"L\" AND tipe";
if (_version_no==13 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver13[(int) (64)];};
 //BA.debugLineNum = 4324;BA.debugLine="If version_no = 13 AND error_level = \"M\" AND tipe";
if (_version_no==13 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver13[(int) (65)];};
 //BA.debugLineNum = 4325;BA.debugLine="If version_no = 13 AND error_level = \"Q\" AND tipe";
if (_version_no==13 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver13[(int) (66)];};
 //BA.debugLineNum = 4326;BA.debugLine="If version_no = 13 AND error_level = \"H\" AND tipe";
if (_version_no==13 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver13[(int) (67)];};
 //BA.debugLineNum = 4327;BA.debugLine="If version_no = 13 AND error_level = \"L\" AND tipe";
if (_version_no==13 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver13[(int) (68)];};
 //BA.debugLineNum = 4328;BA.debugLine="If version_no = 13 AND error_level = \"M\" AND tipe";
if (_version_no==13 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver13[(int) (69)];};
 //BA.debugLineNum = 4329;BA.debugLine="If version_no = 13 AND error_level = \"Q\" AND tipe";
if (_version_no==13 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver13[(int) (70)];};
 //BA.debugLineNum = 4330;BA.debugLine="If version_no = 13 AND error_level = \"H\" AND tipe";
if (_version_no==13 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver13[(int) (71)];};
 //BA.debugLineNum = 4331;BA.debugLine="If version_no = 13 AND error_level = \"L\" AND tipe";
if (_version_no==13 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver13[(int) (72)];};
 //BA.debugLineNum = 4332;BA.debugLine="If version_no = 13 AND error_level = \"M\" AND tipe";
if (_version_no==13 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver13[(int) (73)];};
 //BA.debugLineNum = 4333;BA.debugLine="If version_no = 13 AND error_level = \"Q\" AND tipe";
if (_version_no==13 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver13[(int) (74)];};
 //BA.debugLineNum = 4334;BA.debugLine="If version_no = 13 AND error_level = \"H\" AND tipe";
if (_version_no==13 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver13[(int) (75)];};
 //BA.debugLineNum = 4336;BA.debugLine="If version_no = 14 AND error_level = \"L\" AND tipe";
if (_version_no==14 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver14[(int) (64)];};
 //BA.debugLineNum = 4337;BA.debugLine="If version_no = 14 AND error_level = \"M\" AND tipe";
if (_version_no==14 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver14[(int) (65)];};
 //BA.debugLineNum = 4338;BA.debugLine="If version_no = 14 AND error_level = \"Q\" AND tipe";
if (_version_no==14 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver14[(int) (66)];};
 //BA.debugLineNum = 4339;BA.debugLine="If version_no = 14 AND error_level = \"H\" AND tipe";
if (_version_no==14 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver14[(int) (67)];};
 //BA.debugLineNum = 4340;BA.debugLine="If version_no = 14 AND error_level = \"L\" AND tipe";
if (_version_no==14 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver14[(int) (68)];};
 //BA.debugLineNum = 4341;BA.debugLine="If version_no = 14 AND error_level = \"M\" AND tipe";
if (_version_no==14 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver14[(int) (69)];};
 //BA.debugLineNum = 4342;BA.debugLine="If version_no = 14 AND error_level = \"Q\" AND tipe";
if (_version_no==14 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver14[(int) (70)];};
 //BA.debugLineNum = 4343;BA.debugLine="If version_no = 14 AND error_level = \"H\" AND tipe";
if (_version_no==14 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver14[(int) (71)];};
 //BA.debugLineNum = 4344;BA.debugLine="If version_no = 14 AND error_level = \"L\" AND tipe";
if (_version_no==14 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver14[(int) (72)];};
 //BA.debugLineNum = 4345;BA.debugLine="If version_no = 14 AND error_level = \"M\" AND tipe";
if (_version_no==14 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver14[(int) (73)];};
 //BA.debugLineNum = 4346;BA.debugLine="If version_no = 14 AND error_level = \"Q\" AND tipe";
if (_version_no==14 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver14[(int) (74)];};
 //BA.debugLineNum = 4347;BA.debugLine="If version_no = 14 AND error_level = \"H\" AND tipe";
if (_version_no==14 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver14[(int) (75)];};
 //BA.debugLineNum = 4349;BA.debugLine="If version_no = 15 AND error_level = \"L\" AND tipe";
if (_version_no==15 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver15[(int) (64)];};
 //BA.debugLineNum = 4350;BA.debugLine="If version_no = 15 AND error_level = \"M\" AND tipe";
if (_version_no==15 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver15[(int) (65)];};
 //BA.debugLineNum = 4351;BA.debugLine="If version_no = 15 AND error_level = \"Q\" AND tipe";
if (_version_no==15 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver15[(int) (66)];};
 //BA.debugLineNum = 4352;BA.debugLine="If version_no = 15 AND error_level = \"H\" AND tipe";
if (_version_no==15 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver15[(int) (67)];};
 //BA.debugLineNum = 4353;BA.debugLine="If version_no = 15 AND error_level = \"L\" AND tipe";
if (_version_no==15 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver15[(int) (68)];};
 //BA.debugLineNum = 4354;BA.debugLine="If version_no = 15 AND error_level = \"M\" AND tipe";
if (_version_no==15 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver15[(int) (69)];};
 //BA.debugLineNum = 4355;BA.debugLine="If version_no = 15 AND error_level = \"Q\" AND tipe";
if (_version_no==15 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver15[(int) (70)];};
 //BA.debugLineNum = 4356;BA.debugLine="If version_no = 15 AND error_level = \"H\" AND tipe";
if (_version_no==15 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver15[(int) (71)];};
 //BA.debugLineNum = 4357;BA.debugLine="If version_no = 15 AND error_level = \"L\" AND tipe";
if (_version_no==15 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver15[(int) (72)];};
 //BA.debugLineNum = 4358;BA.debugLine="If version_no = 15 AND error_level = \"M\" AND tipe";
if (_version_no==15 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver15[(int) (73)];};
 //BA.debugLineNum = 4359;BA.debugLine="If version_no = 15 AND error_level = \"Q\" AND tipe";
if (_version_no==15 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver15[(int) (74)];};
 //BA.debugLineNum = 4360;BA.debugLine="If version_no = 15 AND error_level = \"H\" AND tipe";
if (_version_no==15 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver15[(int) (75)];};
 //BA.debugLineNum = 4362;BA.debugLine="If version_no = 16 AND error_level = \"L\" AND tipe";
if (_version_no==16 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver16[(int) (64)];};
 //BA.debugLineNum = 4363;BA.debugLine="If version_no = 16 AND error_level = \"M\" AND tipe";
if (_version_no==16 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver16[(int) (65)];};
 //BA.debugLineNum = 4364;BA.debugLine="If version_no = 16 AND error_level = \"Q\" AND tipe";
if (_version_no==16 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver16[(int) (66)];};
 //BA.debugLineNum = 4365;BA.debugLine="If version_no = 16 AND error_level = \"H\" AND tipe";
if (_version_no==16 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver16[(int) (67)];};
 //BA.debugLineNum = 4366;BA.debugLine="If version_no = 16 AND error_level = \"L\" AND tipe";
if (_version_no==16 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver16[(int) (68)];};
 //BA.debugLineNum = 4367;BA.debugLine="If version_no = 16 AND error_level = \"M\" AND tipe";
if (_version_no==16 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver16[(int) (69)];};
 //BA.debugLineNum = 4368;BA.debugLine="If version_no = 16 AND error_level = \"Q\" AND tipe";
if (_version_no==16 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver16[(int) (70)];};
 //BA.debugLineNum = 4369;BA.debugLine="If version_no = 16 AND error_level = \"H\" AND tipe";
if (_version_no==16 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver16[(int) (71)];};
 //BA.debugLineNum = 4370;BA.debugLine="If version_no = 16 AND error_level = \"L\" AND tipe";
if (_version_no==16 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver16[(int) (72)];};
 //BA.debugLineNum = 4371;BA.debugLine="If version_no = 16 AND error_level = \"M\" AND tipe";
if (_version_no==16 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver16[(int) (73)];};
 //BA.debugLineNum = 4372;BA.debugLine="If version_no = 16 AND error_level = \"Q\" AND tipe";
if (_version_no==16 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver16[(int) (74)];};
 //BA.debugLineNum = 4373;BA.debugLine="If version_no = 16 AND error_level = \"H\" AND tipe";
if (_version_no==16 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver16[(int) (75)];};
 //BA.debugLineNum = 4375;BA.debugLine="If version_no = 17 AND error_level = \"L\" AND tipe";
if (_version_no==17 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver17[(int) (64)];};
 //BA.debugLineNum = 4376;BA.debugLine="If version_no = 17 AND error_level = \"M\" AND tipe";
if (_version_no==17 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver17[(int) (65)];};
 //BA.debugLineNum = 4377;BA.debugLine="If version_no = 17 AND error_level = \"Q\" AND tipe";
if (_version_no==17 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver17[(int) (66)];};
 //BA.debugLineNum = 4378;BA.debugLine="If version_no = 17 AND error_level = \"H\" AND tipe";
if (_version_no==17 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver17[(int) (67)];};
 //BA.debugLineNum = 4379;BA.debugLine="If version_no = 17 AND error_level = \"L\" AND tipe";
if (_version_no==17 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver17[(int) (68)];};
 //BA.debugLineNum = 4380;BA.debugLine="If version_no = 17 AND error_level = \"M\" AND tipe";
if (_version_no==17 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver17[(int) (69)];};
 //BA.debugLineNum = 4381;BA.debugLine="If version_no = 17 AND error_level = \"Q\" AND tipe";
if (_version_no==17 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver17[(int) (70)];};
 //BA.debugLineNum = 4382;BA.debugLine="If version_no = 17 AND error_level = \"H\" AND tipe";
if (_version_no==17 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver17[(int) (71)];};
 //BA.debugLineNum = 4383;BA.debugLine="If version_no = 17 AND error_level = \"L\" AND tipe";
if (_version_no==17 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver17[(int) (72)];};
 //BA.debugLineNum = 4384;BA.debugLine="If version_no = 17 AND error_level = \"M\" AND tipe";
if (_version_no==17 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver17[(int) (73)];};
 //BA.debugLineNum = 4385;BA.debugLine="If version_no = 17 AND error_level = \"Q\" AND tipe";
if (_version_no==17 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver17[(int) (74)];};
 //BA.debugLineNum = 4386;BA.debugLine="If version_no = 17 AND error_level = \"H\" AND tipe";
if (_version_no==17 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver17[(int) (75)];};
 //BA.debugLineNum = 4388;BA.debugLine="If version_no = 18 AND error_level = \"L\" AND tipe";
if (_version_no==18 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver18[(int) (64)];};
 //BA.debugLineNum = 4389;BA.debugLine="If version_no = 18 AND error_level = \"M\" AND tipe";
if (_version_no==18 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver18[(int) (65)];};
 //BA.debugLineNum = 4390;BA.debugLine="If version_no = 18 AND error_level = \"Q\" AND tipe";
if (_version_no==18 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver18[(int) (66)];};
 //BA.debugLineNum = 4391;BA.debugLine="If version_no = 18 AND error_level = \"H\" AND tipe";
if (_version_no==18 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver18[(int) (67)];};
 //BA.debugLineNum = 4392;BA.debugLine="If version_no = 18 AND error_level = \"L\" AND tipe";
if (_version_no==18 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver18[(int) (68)];};
 //BA.debugLineNum = 4393;BA.debugLine="If version_no = 18 AND error_level = \"M\" AND tipe";
if (_version_no==18 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver18[(int) (69)];};
 //BA.debugLineNum = 4394;BA.debugLine="If version_no = 18 AND error_level = \"Q\" AND tipe";
if (_version_no==18 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver18[(int) (70)];};
 //BA.debugLineNum = 4395;BA.debugLine="If version_no = 18 AND error_level = \"H\" AND tipe";
if (_version_no==18 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver18[(int) (71)];};
 //BA.debugLineNum = 4396;BA.debugLine="If version_no = 18 AND error_level = \"L\" AND tipe";
if (_version_no==18 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver18[(int) (72)];};
 //BA.debugLineNum = 4397;BA.debugLine="If version_no = 18 AND error_level = \"M\" AND tipe";
if (_version_no==18 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver18[(int) (73)];};
 //BA.debugLineNum = 4398;BA.debugLine="If version_no = 18 AND error_level = \"Q\" AND tipe";
if (_version_no==18 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver18[(int) (74)];};
 //BA.debugLineNum = 4399;BA.debugLine="If version_no = 18 AND error_level = \"H\" AND tipe";
if (_version_no==18 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver18[(int) (75)];};
 //BA.debugLineNum = 4401;BA.debugLine="If version_no = 19 AND error_level = \"L\" AND tipe";
if (_version_no==19 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver19[(int) (64)];};
 //BA.debugLineNum = 4402;BA.debugLine="If version_no = 19 AND error_level = \"M\" AND tipe";
if (_version_no==19 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver19[(int) (65)];};
 //BA.debugLineNum = 4403;BA.debugLine="If version_no = 19 AND error_level = \"Q\" AND tipe";
if (_version_no==19 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver19[(int) (66)];};
 //BA.debugLineNum = 4404;BA.debugLine="If version_no = 19 AND error_level = \"H\" AND tipe";
if (_version_no==19 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver19[(int) (67)];};
 //BA.debugLineNum = 4405;BA.debugLine="If version_no = 19 AND error_level = \"L\" AND tipe";
if (_version_no==19 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver19[(int) (68)];};
 //BA.debugLineNum = 4406;BA.debugLine="If version_no = 19 AND error_level = \"M\" AND tipe";
if (_version_no==19 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver19[(int) (69)];};
 //BA.debugLineNum = 4407;BA.debugLine="If version_no = 19 AND error_level = \"Q\" AND tipe";
if (_version_no==19 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver19[(int) (70)];};
 //BA.debugLineNum = 4408;BA.debugLine="If version_no = 19 AND error_level = \"H\" AND tipe";
if (_version_no==19 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver19[(int) (71)];};
 //BA.debugLineNum = 4409;BA.debugLine="If version_no = 19 AND error_level = \"L\" AND tipe";
if (_version_no==19 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver19[(int) (72)];};
 //BA.debugLineNum = 4410;BA.debugLine="If version_no = 19 AND error_level = \"M\" AND tipe";
if (_version_no==19 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver19[(int) (73)];};
 //BA.debugLineNum = 4411;BA.debugLine="If version_no = 19 AND error_level = \"Q\" AND tipe";
if (_version_no==19 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver19[(int) (74)];};
 //BA.debugLineNum = 4412;BA.debugLine="If version_no = 19 AND error_level = \"H\" AND tipe";
if (_version_no==19 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver19[(int) (75)];};
 //BA.debugLineNum = 4414;BA.debugLine="If version_no = 20 AND error_level = \"L\" AND tipe";
if (_version_no==20 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver20[(int) (64)];};
 //BA.debugLineNum = 4415;BA.debugLine="If version_no = 20 AND error_level = \"M\" AND tipe";
if (_version_no==20 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver20[(int) (65)];};
 //BA.debugLineNum = 4416;BA.debugLine="If version_no = 20 AND error_level = \"Q\" AND tipe";
if (_version_no==20 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver20[(int) (66)];};
 //BA.debugLineNum = 4417;BA.debugLine="If version_no = 20 AND error_level = \"H\" AND tipe";
if (_version_no==20 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver20[(int) (67)];};
 //BA.debugLineNum = 4418;BA.debugLine="If version_no = 20 AND error_level = \"L\" AND tipe";
if (_version_no==20 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver20[(int) (68)];};
 //BA.debugLineNum = 4419;BA.debugLine="If version_no = 20 AND error_level = \"M\" AND tipe";
if (_version_no==20 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver20[(int) (69)];};
 //BA.debugLineNum = 4420;BA.debugLine="If version_no = 20 AND error_level = \"Q\" AND tipe";
if (_version_no==20 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver20[(int) (70)];};
 //BA.debugLineNum = 4421;BA.debugLine="If version_no = 20 AND error_level = \"H\" AND tipe";
if (_version_no==20 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver20[(int) (71)];};
 //BA.debugLineNum = 4422;BA.debugLine="If version_no = 20 AND error_level = \"L\" AND tipe";
if (_version_no==20 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver20[(int) (72)];};
 //BA.debugLineNum = 4423;BA.debugLine="If version_no = 20 AND error_level = \"M\" AND tipe";
if (_version_no==20 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver20[(int) (73)];};
 //BA.debugLineNum = 4424;BA.debugLine="If version_no = 20 AND error_level = \"Q\" AND tipe";
if (_version_no==20 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver20[(int) (74)];};
 //BA.debugLineNum = 4425;BA.debugLine="If version_no = 20 AND error_level = \"H\" AND tipe";
if (_version_no==20 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver20[(int) (75)];};
 //BA.debugLineNum = 4427;BA.debugLine="If version_no = 21 AND error_level = \"L\" AND tipe";
if (_version_no==21 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver21[(int) (64)];};
 //BA.debugLineNum = 4428;BA.debugLine="If version_no = 21 AND error_level = \"M\" AND tipe";
if (_version_no==21 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver21[(int) (65)];};
 //BA.debugLineNum = 4429;BA.debugLine="If version_no = 21 AND error_level = \"Q\" AND tipe";
if (_version_no==21 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver21[(int) (66)];};
 //BA.debugLineNum = 4430;BA.debugLine="If version_no = 21 AND error_level = \"H\" AND tipe";
if (_version_no==21 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver21[(int) (67)];};
 //BA.debugLineNum = 4431;BA.debugLine="If version_no = 21 AND error_level = \"L\" AND tipe";
if (_version_no==21 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver21[(int) (68)];};
 //BA.debugLineNum = 4432;BA.debugLine="If version_no = 21 AND error_level = \"M\" AND tipe";
if (_version_no==21 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver21[(int) (69)];};
 //BA.debugLineNum = 4433;BA.debugLine="If version_no = 21 AND error_level = \"Q\" AND tipe";
if (_version_no==21 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver21[(int) (70)];};
 //BA.debugLineNum = 4434;BA.debugLine="If version_no = 21 AND error_level = \"H\" AND tipe";
if (_version_no==21 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver21[(int) (71)];};
 //BA.debugLineNum = 4435;BA.debugLine="If version_no = 21 AND error_level = \"L\" AND tipe";
if (_version_no==21 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver21[(int) (72)];};
 //BA.debugLineNum = 4436;BA.debugLine="If version_no = 21 AND error_level = \"M\" AND tipe";
if (_version_no==21 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver21[(int) (73)];};
 //BA.debugLineNum = 4437;BA.debugLine="If version_no = 21 AND error_level = \"Q\" AND tipe";
if (_version_no==21 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver21[(int) (74)];};
 //BA.debugLineNum = 4438;BA.debugLine="If version_no = 21 AND error_level = \"H\" AND tipe";
if (_version_no==21 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver21[(int) (75)];};
 //BA.debugLineNum = 4440;BA.debugLine="If version_no = 22 AND error_level = \"L\" AND tipe";
if (_version_no==22 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver22[(int) (64)];};
 //BA.debugLineNum = 4441;BA.debugLine="If version_no = 22 AND error_level = \"M\" AND tipe";
if (_version_no==22 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver22[(int) (65)];};
 //BA.debugLineNum = 4442;BA.debugLine="If version_no = 22 AND error_level = \"Q\" AND tipe";
if (_version_no==22 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver22[(int) (66)];};
 //BA.debugLineNum = 4443;BA.debugLine="If version_no = 22 AND error_level = \"H\" AND tipe";
if (_version_no==22 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver22[(int) (67)];};
 //BA.debugLineNum = 4444;BA.debugLine="If version_no = 22 AND error_level = \"L\" AND tipe";
if (_version_no==22 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver22[(int) (68)];};
 //BA.debugLineNum = 4445;BA.debugLine="If version_no = 22 AND error_level = \"M\" AND tipe";
if (_version_no==22 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver22[(int) (69)];};
 //BA.debugLineNum = 4446;BA.debugLine="If version_no = 22 AND error_level = \"Q\" AND tipe";
if (_version_no==22 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver22[(int) (70)];};
 //BA.debugLineNum = 4447;BA.debugLine="If version_no = 22 AND error_level = \"H\" AND tipe";
if (_version_no==22 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver22[(int) (71)];};
 //BA.debugLineNum = 4448;BA.debugLine="If version_no = 22 AND error_level = \"L\" AND tipe";
if (_version_no==22 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver22[(int) (72)];};
 //BA.debugLineNum = 4449;BA.debugLine="If version_no = 22 AND error_level = \"M\" AND tipe";
if (_version_no==22 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver22[(int) (73)];};
 //BA.debugLineNum = 4450;BA.debugLine="If version_no = 22 AND error_level = \"Q\" AND tipe";
if (_version_no==22 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver22[(int) (74)];};
 //BA.debugLineNum = 4451;BA.debugLine="If version_no = 22 AND error_level = \"H\" AND tipe";
if (_version_no==22 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver22[(int) (75)];};
 //BA.debugLineNum = 4453;BA.debugLine="If version_no = 23 AND error_level = \"L\" AND tipe";
if (_version_no==23 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver23[(int) (64)];};
 //BA.debugLineNum = 4454;BA.debugLine="If version_no = 23 AND error_level = \"M\" AND tipe";
if (_version_no==23 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver23[(int) (65)];};
 //BA.debugLineNum = 4455;BA.debugLine="If version_no = 23 AND error_level = \"Q\" AND tipe";
if (_version_no==23 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver23[(int) (66)];};
 //BA.debugLineNum = 4456;BA.debugLine="If version_no = 23 AND error_level = \"H\" AND tipe";
if (_version_no==23 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver23[(int) (67)];};
 //BA.debugLineNum = 4457;BA.debugLine="If version_no = 23 AND error_level = \"L\" AND tipe";
if (_version_no==23 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver23[(int) (68)];};
 //BA.debugLineNum = 4458;BA.debugLine="If version_no = 23 AND error_level = \"M\" AND tipe";
if (_version_no==23 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver23[(int) (69)];};
 //BA.debugLineNum = 4459;BA.debugLine="If version_no = 23 AND error_level = \"Q\" AND tipe";
if (_version_no==23 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver23[(int) (70)];};
 //BA.debugLineNum = 4460;BA.debugLine="If version_no = 23 AND error_level = \"H\" AND tipe";
if (_version_no==23 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver23[(int) (71)];};
 //BA.debugLineNum = 4461;BA.debugLine="If version_no = 23 AND error_level = \"L\" AND tipe";
if (_version_no==23 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver23[(int) (72)];};
 //BA.debugLineNum = 4462;BA.debugLine="If version_no = 23 AND error_level = \"M\" AND tipe";
if (_version_no==23 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver23[(int) (73)];};
 //BA.debugLineNum = 4463;BA.debugLine="If version_no = 23 AND error_level = \"Q\" AND tipe";
if (_version_no==23 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver23[(int) (74)];};
 //BA.debugLineNum = 4464;BA.debugLine="If version_no = 23 AND error_level = \"H\" AND tipe";
if (_version_no==23 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver23[(int) (75)];};
 //BA.debugLineNum = 4466;BA.debugLine="If version_no = 24 AND error_level = \"L\" AND tipe";
if (_version_no==24 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver24[(int) (64)];};
 //BA.debugLineNum = 4467;BA.debugLine="If version_no = 24 AND error_level = \"M\" AND tipe";
if (_version_no==24 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver24[(int) (65)];};
 //BA.debugLineNum = 4468;BA.debugLine="If version_no = 24 AND error_level = \"Q\" AND tipe";
if (_version_no==24 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver24[(int) (66)];};
 //BA.debugLineNum = 4469;BA.debugLine="If version_no = 24 AND error_level = \"H\" AND tipe";
if (_version_no==24 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver24[(int) (67)];};
 //BA.debugLineNum = 4470;BA.debugLine="If version_no = 24 AND error_level = \"L\" AND tipe";
if (_version_no==24 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver24[(int) (68)];};
 //BA.debugLineNum = 4471;BA.debugLine="If version_no = 24 AND error_level = \"M\" AND tipe";
if (_version_no==24 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver24[(int) (69)];};
 //BA.debugLineNum = 4472;BA.debugLine="If version_no = 24 AND error_level = \"Q\" AND tipe";
if (_version_no==24 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver24[(int) (70)];};
 //BA.debugLineNum = 4473;BA.debugLine="If version_no = 24 AND error_level = \"H\" AND tipe";
if (_version_no==24 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver24[(int) (71)];};
 //BA.debugLineNum = 4474;BA.debugLine="If version_no = 24 AND error_level = \"L\" AND tipe";
if (_version_no==24 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver24[(int) (72)];};
 //BA.debugLineNum = 4475;BA.debugLine="If version_no = 24 AND error_level = \"M\" AND tipe";
if (_version_no==24 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver24[(int) (73)];};
 //BA.debugLineNum = 4476;BA.debugLine="If version_no = 24 AND error_level = \"Q\" AND tipe";
if (_version_no==24 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver24[(int) (74)];};
 //BA.debugLineNum = 4477;BA.debugLine="If version_no = 24 AND error_level = \"H\" AND tipe";
if (_version_no==24 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver24[(int) (75)];};
 //BA.debugLineNum = 4479;BA.debugLine="If version_no = 25 AND error_level = \"L\" AND tipe";
if (_version_no==25 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver25[(int) (64)];};
 //BA.debugLineNum = 4480;BA.debugLine="If version_no = 25 AND error_level = \"M\" AND tipe";
if (_version_no==25 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver25[(int) (65)];};
 //BA.debugLineNum = 4481;BA.debugLine="If version_no = 25 AND error_level = \"Q\" AND tipe";
if (_version_no==25 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver25[(int) (66)];};
 //BA.debugLineNum = 4482;BA.debugLine="If version_no = 25 AND error_level = \"H\" AND tipe";
if (_version_no==25 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver25[(int) (67)];};
 //BA.debugLineNum = 4483;BA.debugLine="If version_no = 25 AND error_level = \"L\" AND tipe";
if (_version_no==25 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver25[(int) (68)];};
 //BA.debugLineNum = 4484;BA.debugLine="If version_no = 25 AND error_level = \"M\" AND tipe";
if (_version_no==25 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver25[(int) (69)];};
 //BA.debugLineNum = 4485;BA.debugLine="If version_no = 25 AND error_level = \"Q\" AND tipe";
if (_version_no==25 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver25[(int) (70)];};
 //BA.debugLineNum = 4486;BA.debugLine="If version_no = 25 AND error_level = \"H\" AND tipe";
if (_version_no==25 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver25[(int) (71)];};
 //BA.debugLineNum = 4487;BA.debugLine="If version_no = 25 AND error_level = \"L\" AND tipe";
if (_version_no==25 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver25[(int) (72)];};
 //BA.debugLineNum = 4488;BA.debugLine="If version_no = 25 AND error_level = \"M\" AND tipe";
if (_version_no==25 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver25[(int) (73)];};
 //BA.debugLineNum = 4489;BA.debugLine="If version_no = 25 AND error_level = \"Q\" AND tipe";
if (_version_no==25 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver25[(int) (74)];};
 //BA.debugLineNum = 4490;BA.debugLine="If version_no = 25 AND error_level = \"H\" AND tipe";
if (_version_no==25 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver25[(int) (75)];};
 //BA.debugLineNum = 4492;BA.debugLine="If version_no = 26 AND error_level = \"L\" AND tipe";
if (_version_no==26 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver26[(int) (64)];};
 //BA.debugLineNum = 4493;BA.debugLine="If version_no = 26 AND error_level = \"M\" AND tipe";
if (_version_no==26 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver26[(int) (65)];};
 //BA.debugLineNum = 4494;BA.debugLine="If version_no = 26 AND error_level = \"Q\" AND tipe";
if (_version_no==26 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver26[(int) (66)];};
 //BA.debugLineNum = 4495;BA.debugLine="If version_no = 26 AND error_level = \"H\" AND tipe";
if (_version_no==26 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver26[(int) (67)];};
 //BA.debugLineNum = 4496;BA.debugLine="If version_no = 26 AND error_level = \"L\" AND tipe";
if (_version_no==26 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver26[(int) (68)];};
 //BA.debugLineNum = 4497;BA.debugLine="If version_no = 26 AND error_level = \"M\" AND tipe";
if (_version_no==26 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver26[(int) (69)];};
 //BA.debugLineNum = 4498;BA.debugLine="If version_no = 26 AND error_level = \"Q\" AND tipe";
if (_version_no==26 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver26[(int) (70)];};
 //BA.debugLineNum = 4499;BA.debugLine="If version_no = 26 AND error_level = \"H\" AND tipe";
if (_version_no==26 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver26[(int) (71)];};
 //BA.debugLineNum = 4500;BA.debugLine="If version_no = 26 AND error_level = \"L\" AND tipe";
if (_version_no==26 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver26[(int) (72)];};
 //BA.debugLineNum = 4501;BA.debugLine="If version_no = 26 AND error_level = \"M\" AND tipe";
if (_version_no==26 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver26[(int) (73)];};
 //BA.debugLineNum = 4502;BA.debugLine="If version_no = 26 AND error_level = \"Q\" AND tipe";
if (_version_no==26 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver26[(int) (74)];};
 //BA.debugLineNum = 4503;BA.debugLine="If version_no = 26 AND error_level = \"H\" AND tipe";
if (_version_no==26 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver26[(int) (75)];};
 //BA.debugLineNum = 4505;BA.debugLine="If version_no = 27 AND error_level = \"L\" AND tipe";
if (_version_no==27 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver27[(int) (64)];};
 //BA.debugLineNum = 4506;BA.debugLine="If version_no = 27 AND error_level = \"M\" AND tipe";
if (_version_no==27 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver27[(int) (65)];};
 //BA.debugLineNum = 4507;BA.debugLine="If version_no = 27 AND error_level = \"Q\" AND tipe";
if (_version_no==27 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver27[(int) (66)];};
 //BA.debugLineNum = 4508;BA.debugLine="If version_no = 27 AND error_level = \"H\" AND tipe";
if (_version_no==27 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver27[(int) (67)];};
 //BA.debugLineNum = 4509;BA.debugLine="If version_no = 27 AND error_level = \"L\" AND tipe";
if (_version_no==27 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver27[(int) (68)];};
 //BA.debugLineNum = 4510;BA.debugLine="If version_no = 27 AND error_level = \"M\" AND tipe";
if (_version_no==27 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver27[(int) (69)];};
 //BA.debugLineNum = 4511;BA.debugLine="If version_no = 27 AND error_level = \"Q\" AND tipe";
if (_version_no==27 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver27[(int) (70)];};
 //BA.debugLineNum = 4512;BA.debugLine="If version_no = 27 AND error_level = \"H\" AND tipe";
if (_version_no==27 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver27[(int) (71)];};
 //BA.debugLineNum = 4513;BA.debugLine="If version_no = 27 AND error_level = \"L\" AND tipe";
if (_version_no==27 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver27[(int) (72)];};
 //BA.debugLineNum = 4514;BA.debugLine="If version_no = 27 AND error_level = \"M\" AND tipe";
if (_version_no==27 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver27[(int) (73)];};
 //BA.debugLineNum = 4515;BA.debugLine="If version_no = 27 AND error_level = \"Q\" AND tipe";
if (_version_no==27 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver27[(int) (74)];};
 //BA.debugLineNum = 4516;BA.debugLine="If version_no = 27 AND error_level = \"H\" AND tipe";
if (_version_no==27 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver27[(int) (75)];};
 //BA.debugLineNum = 4518;BA.debugLine="If version_no = 28 AND error_level = \"L\" AND tipe";
if (_version_no==28 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver28[(int) (64)];};
 //BA.debugLineNum = 4519;BA.debugLine="If version_no = 28 AND error_level = \"M\" AND tipe";
if (_version_no==28 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver28[(int) (65)];};
 //BA.debugLineNum = 4520;BA.debugLine="If version_no = 28 AND error_level = \"Q\" AND tipe";
if (_version_no==28 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver28[(int) (66)];};
 //BA.debugLineNum = 4521;BA.debugLine="If version_no = 28 AND error_level = \"H\" AND tipe";
if (_version_no==28 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver28[(int) (67)];};
 //BA.debugLineNum = 4522;BA.debugLine="If version_no = 28 AND error_level = \"L\" AND tipe";
if (_version_no==28 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver28[(int) (68)];};
 //BA.debugLineNum = 4523;BA.debugLine="If version_no = 28 AND error_level = \"M\" AND tipe";
if (_version_no==28 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver28[(int) (69)];};
 //BA.debugLineNum = 4524;BA.debugLine="If version_no = 28 AND error_level = \"Q\" AND tipe";
if (_version_no==28 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver28[(int) (70)];};
 //BA.debugLineNum = 4525;BA.debugLine="If version_no = 28 AND error_level = \"H\" AND tipe";
if (_version_no==28 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver28[(int) (71)];};
 //BA.debugLineNum = 4526;BA.debugLine="If version_no = 28 AND error_level = \"L\" AND tipe";
if (_version_no==28 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver28[(int) (72)];};
 //BA.debugLineNum = 4527;BA.debugLine="If version_no = 28 AND error_level = \"M\" AND tipe";
if (_version_no==28 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver28[(int) (73)];};
 //BA.debugLineNum = 4528;BA.debugLine="If version_no = 28 AND error_level = \"Q\" AND tipe";
if (_version_no==28 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver28[(int) (74)];};
 //BA.debugLineNum = 4529;BA.debugLine="If version_no = 28 AND error_level = \"H\" AND tipe";
if (_version_no==28 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver28[(int) (75)];};
 //BA.debugLineNum = 4531;BA.debugLine="If version_no = 29 AND error_level = \"L\" AND tipe";
if (_version_no==29 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver29[(int) (64)];};
 //BA.debugLineNum = 4532;BA.debugLine="If version_no = 29 AND error_level = \"M\" AND tipe";
if (_version_no==29 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver29[(int) (65)];};
 //BA.debugLineNum = 4533;BA.debugLine="If version_no = 29 AND error_level = \"Q\" AND tipe";
if (_version_no==29 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver29[(int) (66)];};
 //BA.debugLineNum = 4534;BA.debugLine="If version_no = 29 AND error_level = \"H\" AND tipe";
if (_version_no==29 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver29[(int) (67)];};
 //BA.debugLineNum = 4535;BA.debugLine="If version_no = 29 AND error_level = \"L\" AND tipe";
if (_version_no==29 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver29[(int) (68)];};
 //BA.debugLineNum = 4536;BA.debugLine="If version_no = 29 AND error_level = \"M\" AND tipe";
if (_version_no==29 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver29[(int) (69)];};
 //BA.debugLineNum = 4537;BA.debugLine="If version_no = 29 AND error_level = \"Q\" AND tipe";
if (_version_no==29 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver29[(int) (70)];};
 //BA.debugLineNum = 4538;BA.debugLine="If version_no = 29 AND error_level = \"H\" AND tipe";
if (_version_no==29 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver29[(int) (71)];};
 //BA.debugLineNum = 4539;BA.debugLine="If version_no = 29 AND error_level = \"L\" AND tipe";
if (_version_no==29 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver29[(int) (72)];};
 //BA.debugLineNum = 4540;BA.debugLine="If version_no = 29 AND error_level = \"M\" AND tipe";
if (_version_no==29 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver29[(int) (73)];};
 //BA.debugLineNum = 4541;BA.debugLine="If version_no = 29 AND error_level = \"Q\" AND tipe";
if (_version_no==29 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver29[(int) (74)];};
 //BA.debugLineNum = 4542;BA.debugLine="If version_no = 29 AND error_level = \"H\" AND tipe";
if (_version_no==29 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver29[(int) (75)];};
 //BA.debugLineNum = 4544;BA.debugLine="If version_no = 30 AND error_level = \"L\" AND tipe";
if (_version_no==30 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver30[(int) (64)];};
 //BA.debugLineNum = 4545;BA.debugLine="If version_no = 30 AND error_level = \"M\" AND tipe";
if (_version_no==30 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver30[(int) (65)];};
 //BA.debugLineNum = 4546;BA.debugLine="If version_no = 30 AND error_level = \"Q\" AND tipe";
if (_version_no==30 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver30[(int) (66)];};
 //BA.debugLineNum = 4547;BA.debugLine="If version_no = 30 AND error_level = \"H\" AND tipe";
if (_version_no==30 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver30[(int) (67)];};
 //BA.debugLineNum = 4548;BA.debugLine="If version_no = 30 AND error_level = \"L\" AND tipe";
if (_version_no==30 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver30[(int) (68)];};
 //BA.debugLineNum = 4549;BA.debugLine="If version_no = 30 AND error_level = \"M\" AND tipe";
if (_version_no==30 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver30[(int) (69)];};
 //BA.debugLineNum = 4550;BA.debugLine="If version_no = 30 AND error_level = \"Q\" AND tipe";
if (_version_no==30 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver30[(int) (70)];};
 //BA.debugLineNum = 4551;BA.debugLine="If version_no = 30 AND error_level = \"H\" AND tipe";
if (_version_no==30 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver30[(int) (71)];};
 //BA.debugLineNum = 4552;BA.debugLine="If version_no = 30 AND error_level = \"L\" AND tipe";
if (_version_no==30 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver30[(int) (72)];};
 //BA.debugLineNum = 4553;BA.debugLine="If version_no = 30 AND error_level = \"M\" AND tipe";
if (_version_no==30 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver30[(int) (73)];};
 //BA.debugLineNum = 4554;BA.debugLine="If version_no = 30 AND error_level = \"Q\" AND tipe";
if (_version_no==30 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver30[(int) (74)];};
 //BA.debugLineNum = 4555;BA.debugLine="If version_no = 30 AND error_level = \"H\" AND tipe";
if (_version_no==30 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver30[(int) (75)];};
 //BA.debugLineNum = 4557;BA.debugLine="If version_no = 31 AND error_level = \"L\" AND tipe";
if (_version_no==31 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver31[(int) (64)];};
 //BA.debugLineNum = 4558;BA.debugLine="If version_no = 31 AND error_level = \"M\" AND tipe";
if (_version_no==31 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver31[(int) (65)];};
 //BA.debugLineNum = 4559;BA.debugLine="If version_no = 31 AND error_level = \"Q\" AND tipe";
if (_version_no==31 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver31[(int) (66)];};
 //BA.debugLineNum = 4560;BA.debugLine="If version_no = 31 AND error_level = \"H\" AND tipe";
if (_version_no==31 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver31[(int) (67)];};
 //BA.debugLineNum = 4561;BA.debugLine="If version_no = 31 AND error_level = \"L\" AND tipe";
if (_version_no==31 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver31[(int) (68)];};
 //BA.debugLineNum = 4562;BA.debugLine="If version_no = 31 AND error_level = \"M\" AND tipe";
if (_version_no==31 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver31[(int) (69)];};
 //BA.debugLineNum = 4563;BA.debugLine="If version_no = 31 AND error_level = \"Q\" AND tipe";
if (_version_no==31 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver31[(int) (70)];};
 //BA.debugLineNum = 4564;BA.debugLine="If version_no = 31 AND error_level = \"H\" AND tipe";
if (_version_no==31 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver31[(int) (71)];};
 //BA.debugLineNum = 4565;BA.debugLine="If version_no = 31 AND error_level = \"L\" AND tipe";
if (_version_no==31 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver31[(int) (72)];};
 //BA.debugLineNum = 4566;BA.debugLine="If version_no = 31 AND error_level = \"M\" AND tipe";
if (_version_no==31 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver31[(int) (73)];};
 //BA.debugLineNum = 4567;BA.debugLine="If version_no = 31 AND error_level = \"Q\" AND tipe";
if (_version_no==31 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver31[(int) (74)];};
 //BA.debugLineNum = 4568;BA.debugLine="If version_no = 31 AND error_level = \"H\" AND tipe";
if (_version_no==31 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver31[(int) (75)];};
 //BA.debugLineNum = 4570;BA.debugLine="If version_no = 32 AND error_level = \"L\" AND tipe";
if (_version_no==32 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver32[(int) (64)];};
 //BA.debugLineNum = 4571;BA.debugLine="If version_no = 32 AND error_level = \"M\" AND tipe";
if (_version_no==32 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver32[(int) (65)];};
 //BA.debugLineNum = 4572;BA.debugLine="If version_no = 32 AND error_level = \"Q\" AND tipe";
if (_version_no==32 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver32[(int) (66)];};
 //BA.debugLineNum = 4573;BA.debugLine="If version_no = 32 AND error_level = \"H\" AND tipe";
if (_version_no==32 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver32[(int) (67)];};
 //BA.debugLineNum = 4574;BA.debugLine="If version_no = 32 AND error_level = \"L\" AND tipe";
if (_version_no==32 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver32[(int) (68)];};
 //BA.debugLineNum = 4575;BA.debugLine="If version_no = 32 AND error_level = \"M\" AND tipe";
if (_version_no==32 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver32[(int) (69)];};
 //BA.debugLineNum = 4576;BA.debugLine="If version_no = 32 AND error_level = \"Q\" AND tipe";
if (_version_no==32 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver32[(int) (70)];};
 //BA.debugLineNum = 4577;BA.debugLine="If version_no = 32 AND error_level = \"H\" AND tipe";
if (_version_no==32 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver32[(int) (71)];};
 //BA.debugLineNum = 4578;BA.debugLine="If version_no = 32 AND error_level = \"L\" AND tipe";
if (_version_no==32 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver32[(int) (72)];};
 //BA.debugLineNum = 4579;BA.debugLine="If version_no = 32 AND error_level = \"M\" AND tipe";
if (_version_no==32 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver32[(int) (73)];};
 //BA.debugLineNum = 4580;BA.debugLine="If version_no = 32 AND error_level = \"Q\" AND tipe";
if (_version_no==32 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver32[(int) (74)];};
 //BA.debugLineNum = 4581;BA.debugLine="If version_no = 32 AND error_level = \"H\" AND tipe";
if (_version_no==32 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver32[(int) (75)];};
 //BA.debugLineNum = 4583;BA.debugLine="If version_no = 33 AND error_level = \"L\" AND tipe";
if (_version_no==33 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver33[(int) (64)];};
 //BA.debugLineNum = 4584;BA.debugLine="If version_no = 33 AND error_level = \"M\" AND tipe";
if (_version_no==33 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver33[(int) (65)];};
 //BA.debugLineNum = 4585;BA.debugLine="If version_no = 33 AND error_level = \"Q\" AND tipe";
if (_version_no==33 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver33[(int) (66)];};
 //BA.debugLineNum = 4586;BA.debugLine="If version_no = 33 AND error_level = \"H\" AND tipe";
if (_version_no==33 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver33[(int) (67)];};
 //BA.debugLineNum = 4587;BA.debugLine="If version_no = 33 AND error_level = \"L\" AND tipe";
if (_version_no==33 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver33[(int) (68)];};
 //BA.debugLineNum = 4588;BA.debugLine="If version_no = 33 AND error_level = \"M\" AND tipe";
if (_version_no==33 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver33[(int) (69)];};
 //BA.debugLineNum = 4589;BA.debugLine="If version_no = 33 AND error_level = \"Q\" AND tipe";
if (_version_no==33 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver33[(int) (70)];};
 //BA.debugLineNum = 4590;BA.debugLine="If version_no = 33 AND error_level = \"H\" AND tipe";
if (_version_no==33 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver33[(int) (71)];};
 //BA.debugLineNum = 4591;BA.debugLine="If version_no = 33 AND error_level = \"L\" AND tipe";
if (_version_no==33 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver33[(int) (72)];};
 //BA.debugLineNum = 4592;BA.debugLine="If version_no = 33 AND error_level = \"M\" AND tipe";
if (_version_no==33 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver33[(int) (73)];};
 //BA.debugLineNum = 4593;BA.debugLine="If version_no = 33 AND error_level = \"Q\" AND tipe";
if (_version_no==33 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver33[(int) (74)];};
 //BA.debugLineNum = 4594;BA.debugLine="If version_no = 33 AND error_level = \"H\" AND tipe";
if (_version_no==33 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver33[(int) (75)];};
 //BA.debugLineNum = 4596;BA.debugLine="If version_no = 34 AND error_level = \"L\" AND tipe";
if (_version_no==34 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver34[(int) (64)];};
 //BA.debugLineNum = 4597;BA.debugLine="If version_no = 34 AND error_level = \"M\" AND tipe";
if (_version_no==34 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver34[(int) (65)];};
 //BA.debugLineNum = 4598;BA.debugLine="If version_no = 34 AND error_level = \"Q\" AND tipe";
if (_version_no==34 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver34[(int) (66)];};
 //BA.debugLineNum = 4599;BA.debugLine="If version_no = 34 AND error_level = \"H\" AND tipe";
if (_version_no==34 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver34[(int) (67)];};
 //BA.debugLineNum = 4600;BA.debugLine="If version_no = 34 AND error_level = \"L\" AND tipe";
if (_version_no==34 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver34[(int) (68)];};
 //BA.debugLineNum = 4601;BA.debugLine="If version_no = 34 AND error_level = \"M\" AND tipe";
if (_version_no==34 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver34[(int) (69)];};
 //BA.debugLineNum = 4602;BA.debugLine="If version_no = 34 AND error_level = \"Q\" AND tipe";
if (_version_no==34 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver34[(int) (70)];};
 //BA.debugLineNum = 4603;BA.debugLine="If version_no = 34 AND error_level = \"H\" AND tipe";
if (_version_no==34 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver34[(int) (71)];};
 //BA.debugLineNum = 4604;BA.debugLine="If version_no = 34 AND error_level = \"L\" AND tipe";
if (_version_no==34 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver34[(int) (72)];};
 //BA.debugLineNum = 4605;BA.debugLine="If version_no = 34 AND error_level = \"M\" AND tipe";
if (_version_no==34 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver34[(int) (73)];};
 //BA.debugLineNum = 4606;BA.debugLine="If version_no = 34 AND error_level = \"Q\" AND tipe";
if (_version_no==34 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver34[(int) (74)];};
 //BA.debugLineNum = 4607;BA.debugLine="If version_no = 34 AND error_level = \"H\" AND tipe";
if (_version_no==34 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver34[(int) (75)];};
 //BA.debugLineNum = 4609;BA.debugLine="If version_no = 35 AND error_level = \"L\" AND tipe";
if (_version_no==35 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver35[(int) (64)];};
 //BA.debugLineNum = 4610;BA.debugLine="If version_no = 35 AND error_level = \"M\" AND tipe";
if (_version_no==35 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver35[(int) (65)];};
 //BA.debugLineNum = 4611;BA.debugLine="If version_no = 35 AND error_level = \"Q\" AND tipe";
if (_version_no==35 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver35[(int) (66)];};
 //BA.debugLineNum = 4612;BA.debugLine="If version_no = 35 AND error_level = \"H\" AND tipe";
if (_version_no==35 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver35[(int) (67)];};
 //BA.debugLineNum = 4613;BA.debugLine="If version_no = 35 AND error_level = \"L\" AND tipe";
if (_version_no==35 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver35[(int) (68)];};
 //BA.debugLineNum = 4614;BA.debugLine="If version_no = 35 AND error_level = \"M\" AND tipe";
if (_version_no==35 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver35[(int) (69)];};
 //BA.debugLineNum = 4615;BA.debugLine="If version_no = 35 AND error_level = \"Q\" AND tipe";
if (_version_no==35 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver35[(int) (70)];};
 //BA.debugLineNum = 4616;BA.debugLine="If version_no = 35 AND error_level = \"H\" AND tipe";
if (_version_no==35 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver35[(int) (71)];};
 //BA.debugLineNum = 4617;BA.debugLine="If version_no = 35 AND error_level = \"L\" AND tipe";
if (_version_no==35 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver35[(int) (72)];};
 //BA.debugLineNum = 4618;BA.debugLine="If version_no = 35 AND error_level = \"M\" AND tipe";
if (_version_no==35 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver35[(int) (73)];};
 //BA.debugLineNum = 4619;BA.debugLine="If version_no = 35 AND error_level = \"Q\" AND tipe";
if (_version_no==35 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver35[(int) (74)];};
 //BA.debugLineNum = 4620;BA.debugLine="If version_no = 35 AND error_level = \"H\" AND tipe";
if (_version_no==35 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver35[(int) (75)];};
 //BA.debugLineNum = 4622;BA.debugLine="If version_no = 36 AND error_level = \"L\" AND tipe";
if (_version_no==36 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver36[(int) (64)];};
 //BA.debugLineNum = 4623;BA.debugLine="If version_no = 36 AND error_level = \"M\" AND tipe";
if (_version_no==36 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver36[(int) (65)];};
 //BA.debugLineNum = 4624;BA.debugLine="If version_no = 36 AND error_level = \"Q\" AND tipe";
if (_version_no==36 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver36[(int) (66)];};
 //BA.debugLineNum = 4625;BA.debugLine="If version_no = 36 AND error_level = \"H\" AND tipe";
if (_version_no==36 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver36[(int) (67)];};
 //BA.debugLineNum = 4626;BA.debugLine="If version_no = 36 AND error_level = \"L\" AND tipe";
if (_version_no==36 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver36[(int) (68)];};
 //BA.debugLineNum = 4627;BA.debugLine="If version_no = 36 AND error_level = \"M\" AND tipe";
if (_version_no==36 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver36[(int) (69)];};
 //BA.debugLineNum = 4628;BA.debugLine="If version_no = 36 AND error_level = \"Q\" AND tipe";
if (_version_no==36 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver36[(int) (70)];};
 //BA.debugLineNum = 4629;BA.debugLine="If version_no = 36 AND error_level = \"H\" AND tipe";
if (_version_no==36 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver36[(int) (71)];};
 //BA.debugLineNum = 4630;BA.debugLine="If version_no = 36 AND error_level = \"L\" AND tipe";
if (_version_no==36 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver36[(int) (72)];};
 //BA.debugLineNum = 4631;BA.debugLine="If version_no = 36 AND error_level = \"M\" AND tipe";
if (_version_no==36 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver36[(int) (73)];};
 //BA.debugLineNum = 4632;BA.debugLine="If version_no = 36 AND error_level = \"Q\" AND tipe";
if (_version_no==36 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver36[(int) (74)];};
 //BA.debugLineNum = 4633;BA.debugLine="If version_no = 36 AND error_level = \"H\" AND tipe";
if (_version_no==36 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver36[(int) (75)];};
 //BA.debugLineNum = 4635;BA.debugLine="If version_no = 37 AND error_level = \"L\" AND tipe";
if (_version_no==37 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver37[(int) (64)];};
 //BA.debugLineNum = 4636;BA.debugLine="If version_no = 37 AND error_level = \"M\" AND tipe";
if (_version_no==37 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver37[(int) (65)];};
 //BA.debugLineNum = 4637;BA.debugLine="If version_no = 37 AND error_level = \"Q\" AND tipe";
if (_version_no==37 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver37[(int) (66)];};
 //BA.debugLineNum = 4638;BA.debugLine="If version_no = 37 AND error_level = \"H\" AND tipe";
if (_version_no==37 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver37[(int) (67)];};
 //BA.debugLineNum = 4639;BA.debugLine="If version_no = 37 AND error_level = \"L\" AND tipe";
if (_version_no==37 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver37[(int) (68)];};
 //BA.debugLineNum = 4640;BA.debugLine="If version_no = 37 AND error_level = \"M\" AND tipe";
if (_version_no==37 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver37[(int) (69)];};
 //BA.debugLineNum = 4641;BA.debugLine="If version_no = 37 AND error_level = \"Q\" AND tipe";
if (_version_no==37 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver37[(int) (70)];};
 //BA.debugLineNum = 4642;BA.debugLine="If version_no = 37 AND error_level = \"H\" AND tipe";
if (_version_no==37 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver37[(int) (71)];};
 //BA.debugLineNum = 4643;BA.debugLine="If version_no = 37 AND error_level = \"L\" AND tipe";
if (_version_no==37 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver37[(int) (72)];};
 //BA.debugLineNum = 4644;BA.debugLine="If version_no = 37 AND error_level = \"M\" AND tipe";
if (_version_no==37 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver37[(int) (73)];};
 //BA.debugLineNum = 4645;BA.debugLine="If version_no = 37 AND error_level = \"Q\" AND tipe";
if (_version_no==37 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver37[(int) (74)];};
 //BA.debugLineNum = 4646;BA.debugLine="If version_no = 37 AND error_level = \"H\" AND tipe";
if (_version_no==37 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver37[(int) (75)];};
 //BA.debugLineNum = 4648;BA.debugLine="If version_no = 38 AND error_level = \"L\" AND tipe";
if (_version_no==38 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver38[(int) (64)];};
 //BA.debugLineNum = 4649;BA.debugLine="If version_no = 38 AND error_level = \"M\" AND tipe";
if (_version_no==38 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver38[(int) (65)];};
 //BA.debugLineNum = 4650;BA.debugLine="If version_no = 38 AND error_level = \"Q\" AND tipe";
if (_version_no==38 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver38[(int) (66)];};
 //BA.debugLineNum = 4651;BA.debugLine="If version_no = 38 AND error_level = \"H\" AND tipe";
if (_version_no==38 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver38[(int) (67)];};
 //BA.debugLineNum = 4652;BA.debugLine="If version_no = 38 AND error_level = \"L\" AND tipe";
if (_version_no==38 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver38[(int) (68)];};
 //BA.debugLineNum = 4653;BA.debugLine="If version_no = 38 AND error_level = \"M\" AND tipe";
if (_version_no==38 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver38[(int) (69)];};
 //BA.debugLineNum = 4654;BA.debugLine="If version_no = 38 AND error_level = \"Q\" AND tipe";
if (_version_no==38 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver38[(int) (70)];};
 //BA.debugLineNum = 4655;BA.debugLine="If version_no = 38 AND error_level = \"H\" AND tipe";
if (_version_no==38 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver38[(int) (71)];};
 //BA.debugLineNum = 4656;BA.debugLine="If version_no = 38 AND error_level = \"L\" AND tipe";
if (_version_no==38 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver38[(int) (72)];};
 //BA.debugLineNum = 4657;BA.debugLine="If version_no = 38 AND error_level = \"M\" AND tipe";
if (_version_no==38 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver38[(int) (73)];};
 //BA.debugLineNum = 4658;BA.debugLine="If version_no = 38 AND error_level = \"Q\" AND tipe";
if (_version_no==38 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver38[(int) (74)];};
 //BA.debugLineNum = 4659;BA.debugLine="If version_no = 38 AND error_level = \"H\" AND tipe";
if (_version_no==38 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver38[(int) (75)];};
 //BA.debugLineNum = 4661;BA.debugLine="If version_no = 39 AND error_level = \"L\" AND tipe";
if (_version_no==39 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver39[(int) (64)];};
 //BA.debugLineNum = 4662;BA.debugLine="If version_no = 39 AND error_level = \"M\" AND tipe";
if (_version_no==39 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver39[(int) (65)];};
 //BA.debugLineNum = 4663;BA.debugLine="If version_no = 39 AND error_level = \"Q\" AND tipe";
if (_version_no==39 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver39[(int) (66)];};
 //BA.debugLineNum = 4664;BA.debugLine="If version_no = 39 AND error_level = \"H\" AND tipe";
if (_version_no==39 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver39[(int) (67)];};
 //BA.debugLineNum = 4665;BA.debugLine="If version_no = 39 AND error_level = \"L\" AND tipe";
if (_version_no==39 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver39[(int) (68)];};
 //BA.debugLineNum = 4666;BA.debugLine="If version_no = 39 AND error_level = \"M\" AND tipe";
if (_version_no==39 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver39[(int) (69)];};
 //BA.debugLineNum = 4667;BA.debugLine="If version_no = 39 AND error_level = \"Q\" AND tipe";
if (_version_no==39 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver39[(int) (70)];};
 //BA.debugLineNum = 4668;BA.debugLine="If version_no = 39 AND error_level = \"H\" AND tipe";
if (_version_no==39 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver39[(int) (71)];};
 //BA.debugLineNum = 4669;BA.debugLine="If version_no = 39 AND error_level = \"L\" AND tipe";
if (_version_no==39 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver39[(int) (72)];};
 //BA.debugLineNum = 4670;BA.debugLine="If version_no = 39 AND error_level = \"M\" AND tipe";
if (_version_no==39 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver39[(int) (73)];};
 //BA.debugLineNum = 4671;BA.debugLine="If version_no = 39 AND error_level = \"Q\" AND tipe";
if (_version_no==39 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver39[(int) (74)];};
 //BA.debugLineNum = 4672;BA.debugLine="If version_no = 39 AND error_level = \"H\" AND tipe";
if (_version_no==39 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver39[(int) (75)];};
 //BA.debugLineNum = 4674;BA.debugLine="If version_no = 40 AND error_level = \"L\" AND tipe";
if (_version_no==40 && (_error_level).equals("L") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver40[(int) (64)];};
 //BA.debugLineNum = 4675;BA.debugLine="If version_no = 40 AND error_level = \"M\" AND tipe";
if (_version_no==40 && (_error_level).equals("M") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver40[(int) (65)];};
 //BA.debugLineNum = 4676;BA.debugLine="If version_no = 40 AND error_level = \"Q\" AND tipe";
if (_version_no==40 && (_error_level).equals("Q") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver40[(int) (66)];};
 //BA.debugLineNum = 4677;BA.debugLine="If version_no = 40 AND error_level = \"H\" AND tipe";
if (_version_no==40 && (_error_level).equals("H") && (_tipe).equals("8-bit-Byte")) { 
_maxlen = _ver40[(int) (67)];};
 //BA.debugLineNum = 4678;BA.debugLine="If version_no = 40 AND error_level = \"L\" AND tipe";
if (_version_no==40 && (_error_level).equals("L") && (_tipe).equals("Numeric")) { 
_maxlen = _ver40[(int) (68)];};
 //BA.debugLineNum = 4679;BA.debugLine="If version_no = 40 AND error_level = \"M\" AND tipe";
if (_version_no==40 && (_error_level).equals("M") && (_tipe).equals("Numeric")) { 
_maxlen = _ver40[(int) (69)];};
 //BA.debugLineNum = 4680;BA.debugLine="If version_no = 40 AND error_level = \"Q\" AND tipe";
if (_version_no==40 && (_error_level).equals("Q") && (_tipe).equals("Numeric")) { 
_maxlen = _ver40[(int) (70)];};
 //BA.debugLineNum = 4681;BA.debugLine="If version_no = 40 AND error_level = \"H\" AND tipe";
if (_version_no==40 && (_error_level).equals("H") && (_tipe).equals("Numeric")) { 
_maxlen = _ver40[(int) (71)];};
 //BA.debugLineNum = 4682;BA.debugLine="If version_no = 40 AND error_level = \"L\" AND tipe";
if (_version_no==40 && (_error_level).equals("L") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver40[(int) (72)];};
 //BA.debugLineNum = 4683;BA.debugLine="If version_no = 40 AND error_level = \"M\" AND tipe";
if (_version_no==40 && (_error_level).equals("M") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver40[(int) (73)];};
 //BA.debugLineNum = 4684;BA.debugLine="If version_no = 40 AND error_level = \"Q\" AND tipe";
if (_version_no==40 && (_error_level).equals("Q") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver40[(int) (74)];};
 //BA.debugLineNum = 4685;BA.debugLine="If version_no = 40 AND error_level = \"H\" AND tipe";
if (_version_no==40 && (_error_level).equals("H") && (_tipe).equals("Alphanumeric")) { 
_maxlen = _ver40[(int) (75)];};
 //BA.debugLineNum = 4687;BA.debugLine="End Sub";
return "";
}
public static String  _draw_qr(anywheresoftware.b4a.BA _ba) throws Exception{
int[] _fp = null;
int[] _ap = null;
String[] _apx = null;
String[] _apy = null;
String[] _co_x = null;
String[] _co_y = null;
int _i = 0;
int _j = 0;
int _teller = 0;
String _vi = "";
int _k = 0;
int _flag = 0;
int _last = 0;
int _first = 0;
int _l = 0;
 //BA.debugLineNum = 1392;BA.debugLine="Private Sub draw_qr";
 //BA.debugLineNum = 1395;BA.debugLine="Dim fp() As Int";
_fp = new int[(int) (0)];
;
 //BA.debugLineNum = 1396;BA.debugLine="fp = Array As Int(1, 1, 1, 1, 1, 1, 1, _";
_fp = new int[]{(int) (1),(int) (1),(int) (1),(int) (1),(int) (1),(int) (1),(int) (1),(int) (1),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (1),(int) (1),(int) (0),(int) (1),(int) (1),(int) (1),(int) (0),(int) (1),(int) (1),(int) (0),(int) (1),(int) (1),(int) (1),(int) (0),(int) (1),(int) (1),(int) (0),(int) (1),(int) (1),(int) (1),(int) (0),(int) (1),(int) (1),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (1),(int) (1),(int) (1),(int) (1),(int) (1),(int) (1),(int) (1),(int) (1)};
 //BA.debugLineNum = 1404;BA.debugLine="Dim ap() As Int";
_ap = new int[(int) (0)];
;
 //BA.debugLineNum = 1405;BA.debugLine="ap = Array As Int(1, 1, 1, 1, 1, _";
_ap = new int[]{(int) (1),(int) (1),(int) (1),(int) (1),(int) (1),(int) (1),(int) (0),(int) (0),(int) (0),(int) (1),(int) (1),(int) (0),(int) (1),(int) (0),(int) (1),(int) (1),(int) (0),(int) (0),(int) (0),(int) (1),(int) (1),(int) (1),(int) (1),(int) (1),(int) (1)};
 //BA.debugLineNum = 1411;BA.debugLine="Dim apx(50)   'store x coordinates of alignment pa";
_apx = new String[(int) (50)];
java.util.Arrays.fill(_apx,"");
 //BA.debugLineNum = 1412;BA.debugLine="Dim apy(50)   'store y coordinates of alignment pa";
_apy = new String[(int) (50)];
java.util.Arrays.fill(_apy,"");
 //BA.debugLineNum = 1413;BA.debugLine="Dim co_x(8)";
_co_x = new String[(int) (8)];
java.util.Arrays.fill(_co_x,"");
 //BA.debugLineNum = 1414;BA.debugLine="Dim co_y(8)";
_co_y = new String[(int) (8)];
java.util.Arrays.fill(_co_y,"");
 //BA.debugLineNum = 1418;BA.debugLine="If maskp = 0 Then";
if (_maskp==0) { 
 //BA.debugLineNum = 1419;BA.debugLine="For i = 1 To qr_size                  'load mask";
{
final int step10 = 1;
final int limit10 = _qr_size;
for (_i = (int) (1) ; (step10 > 0 && _i <= limit10) || (step10 < 0 && _i >= limit10); _i = ((int)(0 + _i + step10)) ) {
 //BA.debugLineNum = 1420;BA.debugLine="For j = 1 To qr_size                'we will n";
{
final int step11 = 1;
final int limit11 = _qr_size;
for (_j = (int) (1) ; (step11 > 0 && _j <= limit11) || (step11 < 0 && _j >= limit11); _j = ((int)(0 + _j + step11)) ) {
 //BA.debugLineNum = 1421;BA.debugLine="s5cij(i, j) = ((i - 1) + (j - 1)) Mod 2";
_s5cij[_i][_j] = (int) (((_i-1)+(_j-1))%2);
 }
};
 }
};
 };
 //BA.debugLineNum = 1426;BA.debugLine="If maskp = 1 Then";
if (_maskp==1) { 
 //BA.debugLineNum = 1427;BA.debugLine="For i = 1 To qr_size                  'load mask";
{
final int step17 = 1;
final int limit17 = _qr_size;
for (_i = (int) (1) ; (step17 > 0 && _i <= limit17) || (step17 < 0 && _i >= limit17); _i = ((int)(0 + _i + step17)) ) {
 //BA.debugLineNum = 1428;BA.debugLine="For j = 1 To qr_size                'we will n";
{
final int step18 = 1;
final int limit18 = _qr_size;
for (_j = (int) (1) ; (step18 > 0 && _j <= limit18) || (step18 < 0 && _j >= limit18); _j = ((int)(0 + _j + step18)) ) {
 //BA.debugLineNum = 1429;BA.debugLine="s5cij(i, j) = (i - 1) Mod 2";
_s5cij[_i][_j] = (int) ((_i-1)%2);
 }
};
 }
};
 };
 //BA.debugLineNum = 1434;BA.debugLine="If maskp = 2 Then";
if (_maskp==2) { 
 //BA.debugLineNum = 1435;BA.debugLine="For i = 1 To qr_size                  'load mask";
{
final int step24 = 1;
final int limit24 = _qr_size;
for (_i = (int) (1) ; (step24 > 0 && _i <= limit24) || (step24 < 0 && _i >= limit24); _i = ((int)(0 + _i + step24)) ) {
 //BA.debugLineNum = 1436;BA.debugLine="For j = 1 To qr_size                'we will n";
{
final int step25 = 1;
final int limit25 = _qr_size;
for (_j = (int) (1) ; (step25 > 0 && _j <= limit25) || (step25 < 0 && _j >= limit25); _j = ((int)(0 + _j + step25)) ) {
 //BA.debugLineNum = 1437;BA.debugLine="s5cij(i, j) = (j - 1) Mod 3";
_s5cij[_i][_j] = (int) ((_j-1)%3);
 //BA.debugLineNum = 1438;BA.debugLine="If s5cij(i, j) > 1 Then s5cij(i, j) = 1";
if (_s5cij[_i][_j]>1) { 
_s5cij[_i][_j] = (int) (1);};
 }
};
 }
};
 };
 //BA.debugLineNum = 1443;BA.debugLine="If maskp = 3 Then";
if (_maskp==3) { 
 //BA.debugLineNum = 1444;BA.debugLine="For i = 1 To qr_size                  'load mask";
{
final int step32 = 1;
final int limit32 = _qr_size;
for (_i = (int) (1) ; (step32 > 0 && _i <= limit32) || (step32 < 0 && _i >= limit32); _i = ((int)(0 + _i + step32)) ) {
 //BA.debugLineNum = 1445;BA.debugLine="For j = 1 To qr_size                'we will n";
{
final int step33 = 1;
final int limit33 = _qr_size;
for (_j = (int) (1) ; (step33 > 0 && _j <= limit33) || (step33 < 0 && _j >= limit33); _j = ((int)(0 + _j + step33)) ) {
 //BA.debugLineNum = 1446;BA.debugLine="s5cij(i, j) = ((i - 1) + (j - 1)) Mod 3";
_s5cij[_i][_j] = (int) (((_i-1)+(_j-1))%3);
 //BA.debugLineNum = 1447;BA.debugLine="If s5cij(i, j) > 1 Then s5cij(i, j) = 1";
if (_s5cij[_i][_j]>1) { 
_s5cij[_i][_j] = (int) (1);};
 }
};
 }
};
 };
 //BA.debugLineNum = 1452;BA.debugLine="If maskp = 4 Then";
if (_maskp==4) { 
 //BA.debugLineNum = 1453;BA.debugLine="For i = 1 To qr_size                  'load mask";
{
final int step40 = 1;
final int limit40 = _qr_size;
for (_i = (int) (1) ; (step40 > 0 && _i <= limit40) || (step40 < 0 && _i >= limit40); _i = ((int)(0 + _i + step40)) ) {
 //BA.debugLineNum = 1454;BA.debugLine="For j = 1 To qr_size                'we will n";
{
final int step41 = 1;
final int limit41 = _qr_size;
for (_j = (int) (1) ; (step41 > 0 && _j <= limit41) || (step41 < 0 && _j >= limit41); _j = ((int)(0 + _j + step41)) ) {
 //BA.debugLineNum = 1455;BA.debugLine="s5cij(i, j) = ((Floor((i - 1) / 2  )) + (Flo";
_s5cij[_i][_j] = (int) (((anywheresoftware.b4a.keywords.Common.Floor((_i-1)/(double)2))+(anywheresoftware.b4a.keywords.Common.Floor((_j-1)/(double)3)))%2);
 }
};
 }
};
 };
 //BA.debugLineNum = 1460;BA.debugLine="If maskp = 5 Then";
if (_maskp==5) { 
 //BA.debugLineNum = 1461;BA.debugLine="For i = 1 To qr_size                  'load mask";
{
final int step47 = 1;
final int limit47 = _qr_size;
for (_i = (int) (1) ; (step47 > 0 && _i <= limit47) || (step47 < 0 && _i >= limit47); _i = ((int)(0 + _i + step47)) ) {
 //BA.debugLineNum = 1462;BA.debugLine="For j = 1 To qr_size                'we will n";
{
final int step48 = 1;
final int limit48 = _qr_size;
for (_j = (int) (1) ; (step48 > 0 && _j <= limit48) || (step48 < 0 && _j >= limit48); _j = ((int)(0 + _j + step48)) ) {
 //BA.debugLineNum = 1463;BA.debugLine="s5cij(i, j) = (((i - 1) * (j - 1)) Mod 2) +";
_s5cij[_i][_j] = (int) ((((_i-1)*(_j-1))%2)+(((_i-1)*(_j-1))%3));
 //BA.debugLineNum = 1464;BA.debugLine="If s5cij(i, j) > 1 Then s5cij(i, j) = 1";
if (_s5cij[_i][_j]>1) { 
_s5cij[_i][_j] = (int) (1);};
 }
};
 }
};
 };
 //BA.debugLineNum = 1469;BA.debugLine="If maskp = 6 Then";
if (_maskp==6) { 
 //BA.debugLineNum = 1470;BA.debugLine="For i = 1 To qr_size                  'load mask";
{
final int step55 = 1;
final int limit55 = _qr_size;
for (_i = (int) (1) ; (step55 > 0 && _i <= limit55) || (step55 < 0 && _i >= limit55); _i = ((int)(0 + _i + step55)) ) {
 //BA.debugLineNum = 1471;BA.debugLine="For j = 1 To qr_size                'we will n";
{
final int step56 = 1;
final int limit56 = _qr_size;
for (_j = (int) (1) ; (step56 > 0 && _j <= limit56) || (step56 < 0 && _j >= limit56); _j = ((int)(0 + _j + step56)) ) {
 //BA.debugLineNum = 1472;BA.debugLine="s5cij(i, j) = ((((i - 1) * (j - 1)) Mod 2) +";
_s5cij[_i][_j] = (int) (((((_i-1)*(_j-1))%2)+(((_i-1)*(_j-1))%3))%2);
 }
};
 }
};
 };
 //BA.debugLineNum = 1477;BA.debugLine="If maskp = 7 Then";
if (_maskp==7) { 
 //BA.debugLineNum = 1478;BA.debugLine="For i = 1 To qr_size                  'load mask";
{
final int step62 = 1;
final int limit62 = _qr_size;
for (_i = (int) (1) ; (step62 > 0 && _i <= limit62) || (step62 < 0 && _i >= limit62); _i = ((int)(0 + _i + step62)) ) {
 //BA.debugLineNum = 1479;BA.debugLine="For j = 1 To qr_size                'we will n";
{
final int step63 = 1;
final int limit63 = _qr_size;
for (_j = (int) (1) ; (step63 > 0 && _j <= limit63) || (step63 < 0 && _j >= limit63); _j = ((int)(0 + _j + step63)) ) {
 //BA.debugLineNum = 1480;BA.debugLine="s5cij(i, j) = ((((i - 1) + (j - 1)) Mod 2) +";
_s5cij[_i][_j] = (int) (((((_i-1)+(_j-1))%2)+(((_i-1)*(_j-1))%3))%2);
 }
};
 }
};
 };
 //BA.debugLineNum = 1484;BA.debugLine="Dim teller As Int";
_teller = 0;
 //BA.debugLineNum = 1485;BA.debugLine="teller = 1              'put down the 3 finding pa";
_teller = (int) (1);
 //BA.debugLineNum = 1486;BA.debugLine="For i = 1 To 7";
{
final int step70 = 1;
final int limit70 = (int) (7);
for (_i = (int) (1) ; (step70 > 0 && _i <= limit70) || (step70 < 0 && _i >= limit70); _i = ((int)(0 + _i + step70)) ) {
 //BA.debugLineNum = 1487;BA.debugLine="For j = 1 To 7";
{
final int step71 = 1;
final int limit71 = (int) (7);
for (_j = (int) (1) ; (step71 > 0 && _j <= limit71) || (step71 < 0 && _j >= limit71); _j = ((int)(0 + _j + step71)) ) {
 //BA.debugLineNum = 1488;BA.debugLine="If fp(teller - 1) = 1 Then     'fp() stores th";
if (_fp[(int) (_teller-1)]==1) { 
 //BA.debugLineNum = 1489;BA.debugLine="s5cij(i, j) = 10         'it will become a w";
_s5cij[_i][_j] = (int) (10);
 //BA.debugLineNum = 1490;BA.debugLine="s5cij(i, qr_size - 7 + j) = 10";
_s5cij[_i][(int) (_qr_size-7+_j)] = (int) (10);
 //BA.debugLineNum = 1491;BA.debugLine="s5cij(qr_size - 7 + i, j) = 10";
_s5cij[(int) (_qr_size-7+_i)][_j] = (int) (10);
 //BA.debugLineNum = 1492;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 }else {
 //BA.debugLineNum = 1494;BA.debugLine="s5cij(i, j) = 9  'it will become a black squ";
_s5cij[_i][_j] = (int) (9);
 //BA.debugLineNum = 1495;BA.debugLine="s5cij(i, qr_size - 7 + j) = 9";
_s5cij[_i][(int) (_qr_size-7+_j)] = (int) (9);
 //BA.debugLineNum = 1496;BA.debugLine="s5cij(qr_size - 7 + i, j) = 9";
_s5cij[(int) (_qr_size-7+_i)][_j] = (int) (9);
 //BA.debugLineNum = 1497;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 };
 }
};
 }
};
 //BA.debugLineNum = 1501;BA.debugLine="For j = 9 To qr_size - 7    'place horizontal timi";
{
final int step85 = 1;
final int limit85 = (int) (_qr_size-7);
for (_j = (int) (9) ; (step85 > 0 && _j <= limit85) || (step85 < 0 && _j >= limit85); _j = ((int)(0 + _j + step85)) ) {
 //BA.debugLineNum = 1502;BA.debugLine="If j Mod 2 = 1 Then";
if (_j%2==1) { 
 //BA.debugLineNum = 1503;BA.debugLine="s5cij(7, j) = 10";
_s5cij[(int) (7)][_j] = (int) (10);
 }else {
 //BA.debugLineNum = 1505;BA.debugLine="s5cij(7, j) = 9";
_s5cij[(int) (7)][_j] = (int) (9);
 };
 }
};
 //BA.debugLineNum = 1508;BA.debugLine="For i = 9 To qr_size - 7         'place vertical t";
{
final int step92 = 1;
final int limit92 = (int) (_qr_size-7);
for (_i = (int) (9) ; (step92 > 0 && _i <= limit92) || (step92 < 0 && _i >= limit92); _i = ((int)(0 + _i + step92)) ) {
 //BA.debugLineNum = 1509;BA.debugLine="If i Mod 2 = 1 Then";
if (_i%2==1) { 
 //BA.debugLineNum = 1510;BA.debugLine="s5cij(i, 7) = 10";
_s5cij[_i][(int) (7)] = (int) (10);
 }else {
 //BA.debugLineNum = 1512;BA.debugLine="s5cij(i, 7) = 9";
_s5cij[_i][(int) (7)] = (int) (9);
 };
 }
};
 //BA.debugLineNum = 1515;BA.debugLine="s5cij(qr_size - 7, 9) = 10  'place reserved bit to";
_s5cij[(int) (_qr_size-7)][(int) (9)] = (int) (10);
 //BA.debugLineNum = 1517;BA.debugLine="Dim vi As String";
_vi = "";
 //BA.debugLineNum = 1519;BA.debugLine="Select Case version_no";
switch (_version_no) {
case 7: {
 //BA.debugLineNum = 1521;BA.debugLine="vi = \"001010010011111000\"";
_vi = "001010010011111000";
 break; }
case 8: {
 //BA.debugLineNum = 1523;BA.debugLine="vi = \"001111011010000100\"";
_vi = "001111011010000100";
 break; }
case 9: {
 //BA.debugLineNum = 1525;BA.debugLine="vi = \"100110010101100100\"";
_vi = "100110010101100100";
 break; }
case 10: {
 //BA.debugLineNum = 1527;BA.debugLine="vi = \"110010110010010100\"";
_vi = "110010110010010100";
 break; }
case 11: {
 //BA.debugLineNum = 1529;BA.debugLine="vi = \"011011111101110100\"";
_vi = "011011111101110100";
 break; }
case 12: {
 //BA.debugLineNum = 1531;BA.debugLine="vi = \"010001101110001100\"";
_vi = "010001101110001100";
 break; }
case 13: {
 //BA.debugLineNum = 1533;BA.debugLine="vi = \"111000100001101100\"";
_vi = "111000100001101100";
 break; }
case 14: {
 //BA.debugLineNum = 1535;BA.debugLine="vi = \"101100000110011100\"";
_vi = "101100000110011100";
 break; }
case 15: {
 //BA.debugLineNum = 1537;BA.debugLine="vi = \"000101001001111100\"";
_vi = "000101001001111100";
 break; }
case 16: {
 //BA.debugLineNum = 1539;BA.debugLine="vi = \"000111101101000010\"";
_vi = "000111101101000010";
 break; }
case 17: {
 //BA.debugLineNum = 1541;BA.debugLine="vi = \"101110100010100010\"";
_vi = "101110100010100010";
 break; }
case 18: {
 //BA.debugLineNum = 1543;BA.debugLine="vi = \"111010000101010010\"";
_vi = "111010000101010010";
 break; }
case 19: {
 //BA.debugLineNum = 1545;BA.debugLine="vi = \"010011001010110010\"";
_vi = "010011001010110010";
 break; }
case 20: {
 //BA.debugLineNum = 1547;BA.debugLine="vi = \"011001011001001010\"";
_vi = "011001011001001010";
 break; }
case 21: {
 //BA.debugLineNum = 1549;BA.debugLine="vi = \"110000010110101010\"";
_vi = "110000010110101010";
 break; }
case 22: {
 //BA.debugLineNum = 1551;BA.debugLine="vi = \"100100110001011010\"";
_vi = "100100110001011010";
 break; }
case 23: {
 //BA.debugLineNum = 1553;BA.debugLine="vi = \"001101111110111010\"";
_vi = "001101111110111010";
 break; }
case 24: {
 //BA.debugLineNum = 1555;BA.debugLine="vi = \"001000110111000110\"";
_vi = "001000110111000110";
 break; }
case 25: {
 //BA.debugLineNum = 1557;BA.debugLine="vi = \"100001111000100110\"";
_vi = "100001111000100110";
 break; }
case 26: {
 //BA.debugLineNum = 1559;BA.debugLine="vi = \"110101011111010110\"";
_vi = "110101011111010110";
 break; }
case 27: {
 //BA.debugLineNum = 1561;BA.debugLine="vi = \"011100010000110110\"";
_vi = "011100010000110110";
 break; }
case 28: {
 //BA.debugLineNum = 1563;BA.debugLine="vi = \"010110000011001110\"";
_vi = "010110000011001110";
 break; }
case 29: {
 //BA.debugLineNum = 1565;BA.debugLine="vi = \"111111001100101110\"";
_vi = "111111001100101110";
 break; }
case 30: {
 //BA.debugLineNum = 1567;BA.debugLine="vi = \"101011101011011110\"";
_vi = "101011101011011110";
 break; }
case 31: {
 //BA.debugLineNum = 1569;BA.debugLine="vi = \"000010100100111110\"";
_vi = "000010100100111110";
 break; }
case 32: {
 //BA.debugLineNum = 1571;BA.debugLine="vi = \"101010111001000001\"";
_vi = "101010111001000001";
 break; }
case 33: {
 //BA.debugLineNum = 1573;BA.debugLine="vi = \"000011110110100001\"";
_vi = "000011110110100001";
 break; }
case 34: {
 //BA.debugLineNum = 1575;BA.debugLine="vi = \"010111010001010001\"";
_vi = "010111010001010001";
 break; }
case 35: {
 //BA.debugLineNum = 1577;BA.debugLine="vi = \"111110011110110001\"";
_vi = "111110011110110001";
 break; }
case 36: {
 //BA.debugLineNum = 1579;BA.debugLine="vi = \"110100001101001001\"";
_vi = "110100001101001001";
 break; }
case 37: {
 //BA.debugLineNum = 1581;BA.debugLine="vi = \"011101000010101001\"";
_vi = "011101000010101001";
 break; }
case 38: {
 //BA.debugLineNum = 1583;BA.debugLine="vi = \"001001100101011001\"";
_vi = "001001100101011001";
 break; }
case 39: {
 //BA.debugLineNum = 1585;BA.debugLine="vi = \"100000101010111001\"";
_vi = "100000101010111001";
 break; }
case 40: {
 //BA.debugLineNum = 1587;BA.debugLine="vi = \"100101100011000101\"";
_vi = "100101100011000101";
 break; }
}
;
 //BA.debugLineNum = 1590;BA.debugLine="If version_no >= 7 Then";
if (_version_no>=7) { 
 //BA.debugLineNum = 1591;BA.debugLine="teller = 1         'put version information to";
_teller = (int) (1);
 //BA.debugLineNum = 1592;BA.debugLine="For i = 1 To 6";
{
final int step173 = 1;
final int limit173 = (int) (6);
for (_i = (int) (1) ; (step173 > 0 && _i <= limit173) || (step173 < 0 && _i >= limit173); _i = ((int)(0 + _i + step173)) ) {
 //BA.debugLineNum = 1593;BA.debugLine="For j = 1 To 3";
{
final int step174 = 1;
final int limit174 = (int) (3);
for (_j = (int) (1) ; (step174 > 0 && _j <= limit174) || (step174 < 0 && _j >= limit174); _j = ((int)(0 + _j + step174)) ) {
 //BA.debugLineNum = 1594;BA.debugLine="If sf.Mid(vi, teller, 1) = \"1\" Then";
if ((_sf._vvvv5(_vi,_teller,(int) (1))).equals("1")) { 
 //BA.debugLineNum = 1595;BA.debugLine="s5cij(i, qr_size - 11 + j) = 10";
_s5cij[_i][(int) (_qr_size-11+_j)] = (int) (10);
 //BA.debugLineNum = 1596;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 }else {
 //BA.debugLineNum = 1598;BA.debugLine="s5cij(i, qr_size - 11 + j) = 9";
_s5cij[_i][(int) (_qr_size-11+_j)] = (int) (9);
 //BA.debugLineNum = 1599;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 };
 }
};
 }
};
 //BA.debugLineNum = 1603;BA.debugLine="teller = 1        'put version information abo";
_teller = (int) (1);
 //BA.debugLineNum = 1604;BA.debugLine="For j = 1 To 6";
{
final int step185 = 1;
final int limit185 = (int) (6);
for (_j = (int) (1) ; (step185 > 0 && _j <= limit185) || (step185 < 0 && _j >= limit185); _j = ((int)(0 + _j + step185)) ) {
 //BA.debugLineNum = 1605;BA.debugLine="For i = 1 To 3";
{
final int step186 = 1;
final int limit186 = (int) (3);
for (_i = (int) (1) ; (step186 > 0 && _i <= limit186) || (step186 < 0 && _i >= limit186); _i = ((int)(0 + _i + step186)) ) {
 //BA.debugLineNum = 1606;BA.debugLine="If sf.Mid(vi, teller, 1) = \"1\" Then";
if ((_sf._vvvv5(_vi,_teller,(int) (1))).equals("1")) { 
 //BA.debugLineNum = 1607;BA.debugLine="s5cij(qr_size - 11 + i, j) = 10";
_s5cij[(int) (_qr_size-11+_i)][_j] = (int) (10);
 //BA.debugLineNum = 1608;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 }else {
 //BA.debugLineNum = 1610;BA.debugLine="s5cij(qr_size - 11 + i, j) = 9";
_s5cij[(int) (_qr_size-11+_i)][_j] = (int) (9);
 //BA.debugLineNum = 1611;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 };
 }
};
 }
};
 };
 //BA.debugLineNum = 1618;BA.debugLine="For j = 1 To 8";
{
final int step197 = 1;
final int limit197 = (int) (8);
for (_j = (int) (1) ; (step197 > 0 && _j <= limit197) || (step197 < 0 && _j >= limit197); _j = ((int)(0 + _j + step197)) ) {
 //BA.debugLineNum = 1619;BA.debugLine="s5cij(8, j) = 9";
_s5cij[(int) (8)][_j] = (int) (9);
 //BA.debugLineNum = 1620;BA.debugLine="s5cij(qr_size - 7, j) = 9";
_s5cij[(int) (_qr_size-7)][_j] = (int) (9);
 //BA.debugLineNum = 1621;BA.debugLine="s5cij(8, qr_size - 7 + j) = 9";
_s5cij[(int) (8)][(int) (_qr_size-7+_j)] = (int) (9);
 }
};
 //BA.debugLineNum = 1625;BA.debugLine="For i = 1 To 8";
{
final int step202 = 1;
final int limit202 = (int) (8);
for (_i = (int) (1) ; (step202 > 0 && _i <= limit202) || (step202 < 0 && _i >= limit202); _i = ((int)(0 + _i + step202)) ) {
 //BA.debugLineNum = 1626;BA.debugLine="s5cij(i, 8) = 9";
_s5cij[_i][(int) (8)] = (int) (9);
 //BA.debugLineNum = 1627;BA.debugLine="s5cij(i, qr_size - 7) = 9";
_s5cij[_i][(int) (_qr_size-7)] = (int) (9);
 //BA.debugLineNum = 1628;BA.debugLine="s5cij(qr_size - 7 + i, 8) = 9";
_s5cij[(int) (_qr_size-7+_i)][(int) (8)] = (int) (9);
 }
};
 //BA.debugLineNum = 1632;BA.debugLine="For j = 1 To 9";
{
final int step207 = 1;
final int limit207 = (int) (9);
for (_j = (int) (1) ; (step207 > 0 && _j <= limit207) || (step207 < 0 && _j >= limit207); _j = ((int)(0 + _j + step207)) ) {
 //BA.debugLineNum = 1633;BA.debugLine="If s5cij(9, j) <> 10 Then s5cij(9, j) = 9";
if (_s5cij[(int) (9)][_j]!=10) { 
_s5cij[(int) (9)][_j] = (int) (9);};
 //BA.debugLineNum = 1634;BA.debugLine="If s5cij(9, qr_size - 8 + j) <> 10 Then s5cij(9,";
if (_s5cij[(int) (9)][(int) (_qr_size-8+_j)]!=10) { 
_s5cij[(int) (9)][(int) (_qr_size-8+_j)] = (int) (9);};
 }
};
 //BA.debugLineNum = 1638;BA.debugLine="For i = 1 To 8";
{
final int step211 = 1;
final int limit211 = (int) (8);
for (_i = (int) (1) ; (step211 > 0 && _i <= limit211) || (step211 < 0 && _i >= limit211); _i = ((int)(0 + _i + step211)) ) {
 //BA.debugLineNum = 1639;BA.debugLine="If s5cij(i, 9) <> 10 Then s5cij(i, 9) = 9";
if (_s5cij[_i][(int) (9)]!=10) { 
_s5cij[_i][(int) (9)] = (int) (9);};
 //BA.debugLineNum = 1640;BA.debugLine="If s5cij(qr_size - 8 + i, 9) <> 10 Then s5cij(qr";
if (_s5cij[(int) (_qr_size-8+_i)][(int) (9)]!=10) { 
_s5cij[(int) (_qr_size-8+_i)][(int) (9)] = (int) (9);};
 }
};
 //BA.debugLineNum = 1644;BA.debugLine="Dim tipe As String";
_tipe = "";
 //BA.debugLineNum = 1645;BA.debugLine="If error_level = \"L\" AND maskp = 0 Then tipe = \"11";
if ((_error_level).equals("L") && _maskp==0) { 
_tipe = "111011111000100";};
 //BA.debugLineNum = 1646;BA.debugLine="If error_level = \"L\" AND maskp = 1 Then tipe = \"11";
if ((_error_level).equals("L") && _maskp==1) { 
_tipe = "111001011110011";};
 //BA.debugLineNum = 1647;BA.debugLine="If error_level = \"L\" AND maskp = 2 Then tipe = \"11";
if ((_error_level).equals("L") && _maskp==2) { 
_tipe = "111110110101010";};
 //BA.debugLineNum = 1648;BA.debugLine="If error_level = \"L\" AND maskp = 3 Then tipe = \"11";
if ((_error_level).equals("L") && _maskp==3) { 
_tipe = "111100010011101";};
 //BA.debugLineNum = 1649;BA.debugLine="If error_level = \"L\" AND maskp = 4 Then tipe = \"11";
if ((_error_level).equals("L") && _maskp==4) { 
_tipe = "110011000101111";};
 //BA.debugLineNum = 1650;BA.debugLine="If error_level = \"L\" AND maskp = 5 Then tipe = \"11";
if ((_error_level).equals("L") && _maskp==5) { 
_tipe = "110001100011000";};
 //BA.debugLineNum = 1651;BA.debugLine="If error_level = \"L\" AND maskp = 6 Then tipe = \"11";
if ((_error_level).equals("L") && _maskp==6) { 
_tipe = "110110001000001";};
 //BA.debugLineNum = 1652;BA.debugLine="If error_level = \"L\" AND maskp = 7 Then tipe = \"11";
if ((_error_level).equals("L") && _maskp==7) { 
_tipe = "110100101110110";};
 //BA.debugLineNum = 1653;BA.debugLine="If error_level = \"M\" AND maskp = 0 Then tipe = \"10";
if ((_error_level).equals("M") && _maskp==0) { 
_tipe = "101010000010010";};
 //BA.debugLineNum = 1654;BA.debugLine="If error_level = \"M\" AND maskp = 1 Then tipe = \"10";
if ((_error_level).equals("M") && _maskp==1) { 
_tipe = "101000100100101";};
 //BA.debugLineNum = 1655;BA.debugLine="If error_level = \"M\" AND maskp = 2 Then tipe = \"10";
if ((_error_level).equals("M") && _maskp==2) { 
_tipe = "101111001111100";};
 //BA.debugLineNum = 1656;BA.debugLine="If error_level = \"M\" AND maskp = 3 Then tipe = \"10";
if ((_error_level).equals("M") && _maskp==3) { 
_tipe = "101101101001011";};
 //BA.debugLineNum = 1657;BA.debugLine="If error_level = \"M\" AND maskp = 4 Then tipe = \"10";
if ((_error_level).equals("M") && _maskp==4) { 
_tipe = "100010111111001";};
 //BA.debugLineNum = 1658;BA.debugLine="If error_level = \"M\" AND maskp = 5 Then tipe = \"10";
if ((_error_level).equals("M") && _maskp==5) { 
_tipe = "100000011001110";};
 //BA.debugLineNum = 1659;BA.debugLine="If error_level = \"M\" AND maskp = 6 Then tipe = \"10";
if ((_error_level).equals("M") && _maskp==6) { 
_tipe = "100111110010111";};
 //BA.debugLineNum = 1660;BA.debugLine="If error_level = \"M\" AND maskp = 7 Then tipe = \"10";
if ((_error_level).equals("M") && _maskp==7) { 
_tipe = "100101010100000";};
 //BA.debugLineNum = 1661;BA.debugLine="If error_level = \"Q\" AND maskp = 0 Then tipe = \"01";
if ((_error_level).equals("Q") && _maskp==0) { 
_tipe = "011010101011111";};
 //BA.debugLineNum = 1662;BA.debugLine="If error_level = \"Q\" AND maskp = 1 Then tipe = \"01";
if ((_error_level).equals("Q") && _maskp==1) { 
_tipe = "011000001101000";};
 //BA.debugLineNum = 1663;BA.debugLine="If error_level = \"Q\" AND maskp = 2 Then tipe = \"01";
if ((_error_level).equals("Q") && _maskp==2) { 
_tipe = "011111100110001";};
 //BA.debugLineNum = 1664;BA.debugLine="If error_level = \"Q\" AND maskp = 3 Then tipe = \"01";
if ((_error_level).equals("Q") && _maskp==3) { 
_tipe = "011101000000110";};
 //BA.debugLineNum = 1665;BA.debugLine="If error_level = \"Q\" AND maskp = 4 Then tipe = \"01";
if ((_error_level).equals("Q") && _maskp==4) { 
_tipe = "010010010110100";};
 //BA.debugLineNum = 1666;BA.debugLine="If error_level = \"Q\" AND maskp = 5 Then tipe = \"01";
if ((_error_level).equals("Q") && _maskp==5) { 
_tipe = "010000110000011";};
 //BA.debugLineNum = 1667;BA.debugLine="If error_level = \"Q\" AND maskp = 6 Then tipe = \"01";
if ((_error_level).equals("Q") && _maskp==6) { 
_tipe = "010111011011010";};
 //BA.debugLineNum = 1668;BA.debugLine="If error_level = \"Q\" AND maskp = 7 Then tipe = \"01";
if ((_error_level).equals("Q") && _maskp==7) { 
_tipe = "010101111101101";};
 //BA.debugLineNum = 1669;BA.debugLine="If error_level = \"H\" AND maskp = 0 Then tipe = \"00";
if ((_error_level).equals("H") && _maskp==0) { 
_tipe = "001011010001001";};
 //BA.debugLineNum = 1670;BA.debugLine="If error_level = \"H\" AND maskp = 1 Then tipe = \"00";
if ((_error_level).equals("H") && _maskp==1) { 
_tipe = "001001110111110";};
 //BA.debugLineNum = 1671;BA.debugLine="If error_level = \"H\" AND maskp = 2 Then tipe = \"00";
if ((_error_level).equals("H") && _maskp==2) { 
_tipe = "001110011100111";};
 //BA.debugLineNum = 1672;BA.debugLine="If error_level = \"H\" AND maskp = 3 Then tipe = \"00";
if ((_error_level).equals("H") && _maskp==3) { 
_tipe = "001100111010000";};
 //BA.debugLineNum = 1673;BA.debugLine="If error_level = \"H\" AND maskp = 4 Then tipe = \"00";
if ((_error_level).equals("H") && _maskp==4) { 
_tipe = "000011101100010";};
 //BA.debugLineNum = 1674;BA.debugLine="If error_level = \"H\" AND maskp = 5 Then tipe = \"00";
if ((_error_level).equals("H") && _maskp==5) { 
_tipe = "000001001010101";};
 //BA.debugLineNum = 1675;BA.debugLine="If error_level = \"H\" AND maskp = 6 Then tipe = \"00";
if ((_error_level).equals("H") && _maskp==6) { 
_tipe = "000110100001100";};
 //BA.debugLineNum = 1676;BA.debugLine="If error_level = \"H\" AND maskp = 7 Then tipe = \"00";
if ((_error_level).equals("H") && _maskp==7) { 
_tipe = "000100000111011";};
 //BA.debugLineNum = 1678;BA.debugLine="teller = 1    'place horizontal format info";
_teller = (int) (1);
 //BA.debugLineNum = 1679;BA.debugLine="For j = 1 To 15";
{
final int step249 = 1;
final int limit249 = (int) (15);
for (_j = (int) (1) ; (step249 > 0 && _j <= limit249) || (step249 < 0 && _j >= limit249); _j = ((int)(0 + _j + step249)) ) {
 //BA.debugLineNum = 1680;BA.debugLine="If sf.Mid(tipe, j, 1) = \"1\" Then";
if ((_sf._vvvv5(_tipe,_j,(int) (1))).equals("1")) { 
 //BA.debugLineNum = 1681;BA.debugLine="s5cij(9, teller) = 10";
_s5cij[(int) (9)][_teller] = (int) (10);
 }else {
 //BA.debugLineNum = 1683;BA.debugLine="s5cij(9, teller) = 9";
_s5cij[(int) (9)][_teller] = (int) (9);
 };
 //BA.debugLineNum = 1685;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 //BA.debugLineNum = 1686;BA.debugLine="If teller = 7 Then teller = teller + 1";
if (_teller==7) { 
_teller = (int) (_teller+1);};
 //BA.debugLineNum = 1687;BA.debugLine="If teller = 9 Then teller = qr_size - 7   'was 7";
if (_teller==9) { 
_teller = (int) (_qr_size-7);};
 }
};
 //BA.debugLineNum = 1689;BA.debugLine="teller = qr_size  'place vertical format info";
_teller = _qr_size;
 //BA.debugLineNum = 1690;BA.debugLine="For i = 1 To 15";
{
final int step260 = 1;
final int limit260 = (int) (15);
for (_i = (int) (1) ; (step260 > 0 && _i <= limit260) || (step260 < 0 && _i >= limit260); _i = ((int)(0 + _i + step260)) ) {
 //BA.debugLineNum = 1691;BA.debugLine="If sf.Mid(tipe, i, 1) = \"1\" Then";
if ((_sf._vvvv5(_tipe,_i,(int) (1))).equals("1")) { 
 //BA.debugLineNum = 1692;BA.debugLine="s5cij(teller, 9) = 10";
_s5cij[_teller][(int) (9)] = (int) (10);
 }else {
 //BA.debugLineNum = 1694;BA.debugLine="s5cij(teller, 9) = 9";
_s5cij[_teller][(int) (9)] = (int) (9);
 };
 //BA.debugLineNum = 1696;BA.debugLine="teller = teller - 1";
_teller = (int) (_teller-1);
 //BA.debugLineNum = 1697;BA.debugLine="If teller = qr_size - 7 Then teller = 9";
if (_teller==_qr_size-7) { 
_teller = (int) (9);};
 //BA.debugLineNum = 1698;BA.debugLine="If teller = 7 Then teller = 6";
if (_teller==7) { 
_teller = (int) (6);};
 }
};
 //BA.debugLineNum = 1701;BA.debugLine="Dim k As Int";
_k = 0;
 //BA.debugLineNum = 1702;BA.debugLine="For k = 1 To 7";
{
final int step271 = 1;
final int limit271 = (int) (7);
for (_k = (int) (1) ; (step271 > 0 && _k <= limit271) || (step271 < 0 && _k >= limit271); _k = ((int)(0 + _k + step271)) ) {
 //BA.debugLineNum = 1703;BA.debugLine="co_x(k) = 0";
_co_x[_k] = BA.NumberToString(0);
 //BA.debugLineNum = 1704;BA.debugLine="co_y(k) = 0";
_co_y[_k] = BA.NumberToString(0);
 }
};
 //BA.debugLineNum = 1707;BA.debugLine="Select Case version_no";
switch (_version_no) {
case 2: {
 //BA.debugLineNum = 1709;BA.debugLine="co_x(1) = ver2(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver2[(int) (57)]);
 //BA.debugLineNum = 1710;BA.debugLine="co_x(2) = ver2(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver2[(int) (58)]);
 //BA.debugLineNum = 1711;BA.debugLine="co_x(3) = ver2(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver2[(int) (59)]);
 //BA.debugLineNum = 1712;BA.debugLine="co_x(4) = ver2(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver2[(int) (60)]);
 //BA.debugLineNum = 1713;BA.debugLine="co_x(5) = ver2(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver2[(int) (61)]);
 //BA.debugLineNum = 1714;BA.debugLine="co_x(6) = ver2(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver2[(int) (62)]);
 //BA.debugLineNum = 1715;BA.debugLine="co_x(7) = ver2(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver2[(int) (63)]);
 //BA.debugLineNum = 1716;BA.debugLine="co_y(1) = ver2(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver2[(int) (57)]);
 //BA.debugLineNum = 1717;BA.debugLine="co_y(2) = ver2(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver2[(int) (58)]);
 //BA.debugLineNum = 1718;BA.debugLine="co_y(3) = ver2(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver2[(int) (59)]);
 //BA.debugLineNum = 1719;BA.debugLine="co_y(4) = ver2(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver2[(int) (60)]);
 //BA.debugLineNum = 1720;BA.debugLine="co_y(5) = ver2(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver2[(int) (61)]);
 //BA.debugLineNum = 1721;BA.debugLine="co_y(6) = ver2(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver2[(int) (62)]);
 //BA.debugLineNum = 1722;BA.debugLine="co_y(7) = ver2(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver2[(int) (63)]);
 break; }
case 3: {
 //BA.debugLineNum = 1724;BA.debugLine="co_x(1) = ver3(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver3[(int) (57)]);
 //BA.debugLineNum = 1725;BA.debugLine="co_x(2) = ver3(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver3[(int) (58)]);
 //BA.debugLineNum = 1726;BA.debugLine="co_x(3) = ver3(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver3[(int) (59)]);
 //BA.debugLineNum = 1727;BA.debugLine="co_x(4) = ver3(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver3[(int) (60)]);
 //BA.debugLineNum = 1728;BA.debugLine="co_x(5) = ver3(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver3[(int) (61)]);
 //BA.debugLineNum = 1729;BA.debugLine="co_x(6) = ver3(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver3[(int) (62)]);
 //BA.debugLineNum = 1730;BA.debugLine="co_x(7) = ver3(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver3[(int) (63)]);
 //BA.debugLineNum = 1731;BA.debugLine="co_y(1) = ver3(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver3[(int) (57)]);
 //BA.debugLineNum = 1732;BA.debugLine="co_y(2) = ver3(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver3[(int) (58)]);
 //BA.debugLineNum = 1733;BA.debugLine="co_y(3) = ver3(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver3[(int) (59)]);
 //BA.debugLineNum = 1734;BA.debugLine="co_y(4) = ver3(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver3[(int) (60)]);
 //BA.debugLineNum = 1735;BA.debugLine="co_y(5) = ver3(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver3[(int) (61)]);
 //BA.debugLineNum = 1736;BA.debugLine="co_y(6) = ver3(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver3[(int) (62)]);
 //BA.debugLineNum = 1737;BA.debugLine="co_y(7) = ver3(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver3[(int) (63)]);
 break; }
case 4: {
 //BA.debugLineNum = 1739;BA.debugLine="co_x(1) = ver4(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver4[(int) (57)]);
 //BA.debugLineNum = 1740;BA.debugLine="co_x(2) = ver4(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver4[(int) (58)]);
 //BA.debugLineNum = 1741;BA.debugLine="co_x(3) = ver4(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver4[(int) (59)]);
 //BA.debugLineNum = 1742;BA.debugLine="co_x(4) = ver4(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver4[(int) (60)]);
 //BA.debugLineNum = 1743;BA.debugLine="co_x(5) = ver4(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver4[(int) (61)]);
 //BA.debugLineNum = 1744;BA.debugLine="co_x(6) = ver4(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver4[(int) (62)]);
 //BA.debugLineNum = 1745;BA.debugLine="co_x(7) = ver4(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver4[(int) (63)]);
 //BA.debugLineNum = 1746;BA.debugLine="co_y(1) = ver4(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver4[(int) (57)]);
 //BA.debugLineNum = 1747;BA.debugLine="co_y(2) = ver4(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver4[(int) (58)]);
 //BA.debugLineNum = 1748;BA.debugLine="co_y(3) = ver4(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver4[(int) (59)]);
 //BA.debugLineNum = 1749;BA.debugLine="co_y(4) = ver4(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver4[(int) (60)]);
 //BA.debugLineNum = 1750;BA.debugLine="co_y(5) = ver4(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver4[(int) (61)]);
 //BA.debugLineNum = 1751;BA.debugLine="co_y(6) = ver4(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver4[(int) (62)]);
 //BA.debugLineNum = 1752;BA.debugLine="co_y(7) = ver4(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver4[(int) (63)]);
 break; }
case 5: {
 //BA.debugLineNum = 1754;BA.debugLine="co_x(1) = ver5(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver5[(int) (57)]);
 //BA.debugLineNum = 1755;BA.debugLine="co_x(2) = ver5(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver5[(int) (58)]);
 //BA.debugLineNum = 1756;BA.debugLine="co_x(3) = ver5(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver5[(int) (59)]);
 //BA.debugLineNum = 1757;BA.debugLine="co_x(4) = ver5(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver5[(int) (60)]);
 //BA.debugLineNum = 1758;BA.debugLine="co_x(5) = ver5(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver5[(int) (61)]);
 //BA.debugLineNum = 1759;BA.debugLine="co_x(6) = ver5(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver5[(int) (62)]);
 //BA.debugLineNum = 1760;BA.debugLine="co_x(7) = ver5(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver5[(int) (63)]);
 //BA.debugLineNum = 1761;BA.debugLine="co_y(1) = ver5(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver5[(int) (57)]);
 //BA.debugLineNum = 1762;BA.debugLine="co_y(2) = ver5(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver5[(int) (58)]);
 //BA.debugLineNum = 1763;BA.debugLine="co_y(3) = ver5(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver5[(int) (59)]);
 //BA.debugLineNum = 1764;BA.debugLine="co_y(4) = ver5(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver5[(int) (60)]);
 //BA.debugLineNum = 1765;BA.debugLine="co_y(5) = ver5(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver5[(int) (61)]);
 //BA.debugLineNum = 1766;BA.debugLine="co_y(6) = ver5(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver5[(int) (62)]);
 //BA.debugLineNum = 1767;BA.debugLine="co_y(7) = ver5(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver5[(int) (63)]);
 break; }
case 6: {
 //BA.debugLineNum = 1769;BA.debugLine="co_x(1) = ver6(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver6[(int) (57)]);
 //BA.debugLineNum = 1770;BA.debugLine="co_x(2) = ver6(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver6[(int) (58)]);
 //BA.debugLineNum = 1771;BA.debugLine="co_x(3) = ver6(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver6[(int) (59)]);
 //BA.debugLineNum = 1772;BA.debugLine="co_x(4) = ver6(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver6[(int) (60)]);
 //BA.debugLineNum = 1773;BA.debugLine="co_x(5) = ver6(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver6[(int) (61)]);
 //BA.debugLineNum = 1774;BA.debugLine="co_x(6) = ver6(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver6[(int) (62)]);
 //BA.debugLineNum = 1775;BA.debugLine="co_x(7) = ver6(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver6[(int) (63)]);
 //BA.debugLineNum = 1776;BA.debugLine="co_y(1) = ver6(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver6[(int) (57)]);
 //BA.debugLineNum = 1777;BA.debugLine="co_y(2) = ver6(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver6[(int) (58)]);
 //BA.debugLineNum = 1778;BA.debugLine="co_y(3) = ver6(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver6[(int) (59)]);
 //BA.debugLineNum = 1779;BA.debugLine="co_y(4) = ver6(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver6[(int) (60)]);
 //BA.debugLineNum = 1780;BA.debugLine="co_y(5) = ver6(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver6[(int) (61)]);
 //BA.debugLineNum = 1781;BA.debugLine="co_y(6) = ver6(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver6[(int) (62)]);
 //BA.debugLineNum = 1782;BA.debugLine="co_y(7) = ver6(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver6[(int) (63)]);
 break; }
case 7: {
 //BA.debugLineNum = 1784;BA.debugLine="co_x(1) = ver7(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver7[(int) (57)]);
 //BA.debugLineNum = 1785;BA.debugLine="co_x(2) = ver7(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver7[(int) (58)]);
 //BA.debugLineNum = 1786;BA.debugLine="co_x(3) = ver7(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver7[(int) (59)]);
 //BA.debugLineNum = 1787;BA.debugLine="co_x(4) = ver7(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver7[(int) (60)]);
 //BA.debugLineNum = 1788;BA.debugLine="co_x(5) = ver7(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver7[(int) (61)]);
 //BA.debugLineNum = 1789;BA.debugLine="co_x(6) = ver7(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver7[(int) (62)]);
 //BA.debugLineNum = 1790;BA.debugLine="co_x(7) = ver7(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver7[(int) (63)]);
 //BA.debugLineNum = 1791;BA.debugLine="co_y(1) = ver7(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver7[(int) (57)]);
 //BA.debugLineNum = 1792;BA.debugLine="co_y(2) = ver7(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver7[(int) (58)]);
 //BA.debugLineNum = 1793;BA.debugLine="co_y(3) = ver7(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver7[(int) (59)]);
 //BA.debugLineNum = 1794;BA.debugLine="co_y(4) = ver7(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver7[(int) (60)]);
 //BA.debugLineNum = 1795;BA.debugLine="co_y(5) = ver7(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver7[(int) (61)]);
 //BA.debugLineNum = 1796;BA.debugLine="co_y(6) = ver7(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver7[(int) (62)]);
 //BA.debugLineNum = 1797;BA.debugLine="co_y(7) = ver7(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver7[(int) (63)]);
 break; }
case 8: {
 //BA.debugLineNum = 1799;BA.debugLine="co_x(1) = ver8(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver8[(int) (57)]);
 //BA.debugLineNum = 1800;BA.debugLine="co_x(2) = ver8(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver8[(int) (58)]);
 //BA.debugLineNum = 1801;BA.debugLine="co_x(3) = ver8(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver8[(int) (59)]);
 //BA.debugLineNum = 1802;BA.debugLine="co_x(4) = ver8(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver8[(int) (60)]);
 //BA.debugLineNum = 1803;BA.debugLine="co_x(5) = ver8(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver8[(int) (61)]);
 //BA.debugLineNum = 1804;BA.debugLine="co_x(6) = ver8(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver8[(int) (62)]);
 //BA.debugLineNum = 1805;BA.debugLine="co_x(7) = ver8(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver8[(int) (63)]);
 //BA.debugLineNum = 1806;BA.debugLine="co_y(1) = ver8(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver8[(int) (57)]);
 //BA.debugLineNum = 1807;BA.debugLine="co_y(2) = ver8(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver8[(int) (58)]);
 //BA.debugLineNum = 1808;BA.debugLine="co_y(3) = ver8(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver8[(int) (59)]);
 //BA.debugLineNum = 1809;BA.debugLine="co_y(4) = ver8(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver8[(int) (60)]);
 //BA.debugLineNum = 1810;BA.debugLine="co_y(5) = ver8(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver8[(int) (61)]);
 //BA.debugLineNum = 1811;BA.debugLine="co_y(6) = ver8(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver8[(int) (62)]);
 //BA.debugLineNum = 1812;BA.debugLine="co_y(7) = ver8(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver8[(int) (63)]);
 break; }
case 9: {
 //BA.debugLineNum = 1814;BA.debugLine="co_x(1) = ver9(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver9[(int) (57)]);
 //BA.debugLineNum = 1815;BA.debugLine="co_x(2) = ver9(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver9[(int) (58)]);
 //BA.debugLineNum = 1816;BA.debugLine="co_x(3) = ver9(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver9[(int) (59)]);
 //BA.debugLineNum = 1817;BA.debugLine="co_x(4) = ver9(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver9[(int) (60)]);
 //BA.debugLineNum = 1818;BA.debugLine="co_x(5) = ver9(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver9[(int) (61)]);
 //BA.debugLineNum = 1819;BA.debugLine="co_x(6) = ver9(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver9[(int) (62)]);
 //BA.debugLineNum = 1820;BA.debugLine="co_x(7) = ver9(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver9[(int) (63)]);
 //BA.debugLineNum = 1821;BA.debugLine="co_y(1) = ver9(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver9[(int) (57)]);
 //BA.debugLineNum = 1822;BA.debugLine="co_y(2) = ver9(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver9[(int) (58)]);
 //BA.debugLineNum = 1823;BA.debugLine="co_y(3) = ver9(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver9[(int) (59)]);
 //BA.debugLineNum = 1824;BA.debugLine="co_y(4) = ver9(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver9[(int) (60)]);
 //BA.debugLineNum = 1825;BA.debugLine="co_y(5) = ver9(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver9[(int) (61)]);
 //BA.debugLineNum = 1826;BA.debugLine="co_y(6) = ver9(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver9[(int) (62)]);
 //BA.debugLineNum = 1827;BA.debugLine="co_y(7) = ver9(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver9[(int) (63)]);
 break; }
case 10: {
 //BA.debugLineNum = 1829;BA.debugLine="co_x(1) = ver10(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver10[(int) (57)]);
 //BA.debugLineNum = 1830;BA.debugLine="co_x(2) = ver10(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver10[(int) (58)]);
 //BA.debugLineNum = 1831;BA.debugLine="co_x(3) = ver10(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver10[(int) (59)]);
 //BA.debugLineNum = 1832;BA.debugLine="co_x(4) = ver10(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver10[(int) (60)]);
 //BA.debugLineNum = 1833;BA.debugLine="co_x(5) = ver10(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver10[(int) (61)]);
 //BA.debugLineNum = 1834;BA.debugLine="co_x(6) = ver10(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver10[(int) (62)]);
 //BA.debugLineNum = 1835;BA.debugLine="co_x(7) = ver10(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver10[(int) (63)]);
 //BA.debugLineNum = 1836;BA.debugLine="co_y(1) = ver10(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver10[(int) (57)]);
 //BA.debugLineNum = 1837;BA.debugLine="co_y(2) = ver10(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver10[(int) (58)]);
 //BA.debugLineNum = 1838;BA.debugLine="co_y(3) = ver10(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver10[(int) (59)]);
 //BA.debugLineNum = 1839;BA.debugLine="co_y(4) = ver10(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver10[(int) (60)]);
 //BA.debugLineNum = 1840;BA.debugLine="co_y(5) = ver10(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver10[(int) (61)]);
 //BA.debugLineNum = 1841;BA.debugLine="co_y(6) = ver10(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver10[(int) (62)]);
 //BA.debugLineNum = 1842;BA.debugLine="co_y(7) = ver10(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver10[(int) (63)]);
 break; }
case 11: {
 //BA.debugLineNum = 1844;BA.debugLine="co_x(1) = ver11(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver11[(int) (57)]);
 //BA.debugLineNum = 1845;BA.debugLine="co_x(2) = ver11(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver11[(int) (58)]);
 //BA.debugLineNum = 1846;BA.debugLine="co_x(3) = ver11(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver11[(int) (59)]);
 //BA.debugLineNum = 1847;BA.debugLine="co_x(4) = ver11(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver11[(int) (60)]);
 //BA.debugLineNum = 1848;BA.debugLine="co_x(5) = ver11(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver11[(int) (61)]);
 //BA.debugLineNum = 1849;BA.debugLine="co_x(6) = ver11(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver11[(int) (62)]);
 //BA.debugLineNum = 1850;BA.debugLine="co_x(7) = ver11(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver11[(int) (63)]);
 //BA.debugLineNum = 1851;BA.debugLine="co_y(1) = ver11(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver11[(int) (57)]);
 //BA.debugLineNum = 1852;BA.debugLine="co_y(2) = ver11(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver11[(int) (58)]);
 //BA.debugLineNum = 1853;BA.debugLine="co_y(3) = ver11(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver11[(int) (59)]);
 //BA.debugLineNum = 1854;BA.debugLine="co_y(4) = ver11(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver11[(int) (60)]);
 //BA.debugLineNum = 1855;BA.debugLine="co_y(5) = ver11(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver11[(int) (61)]);
 //BA.debugLineNum = 1856;BA.debugLine="co_y(6) = ver11(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver11[(int) (62)]);
 //BA.debugLineNum = 1857;BA.debugLine="co_y(7) = ver11(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver11[(int) (63)]);
 break; }
case 12: {
 //BA.debugLineNum = 1859;BA.debugLine="co_x(1) = ver12(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver12[(int) (57)]);
 //BA.debugLineNum = 1860;BA.debugLine="co_x(2) = ver12(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver12[(int) (58)]);
 //BA.debugLineNum = 1861;BA.debugLine="co_x(3) = ver12(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver12[(int) (59)]);
 //BA.debugLineNum = 1862;BA.debugLine="co_x(4) = ver12(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver12[(int) (60)]);
 //BA.debugLineNum = 1863;BA.debugLine="co_x(5) = ver12(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver12[(int) (61)]);
 //BA.debugLineNum = 1864;BA.debugLine="co_x(6) = ver12(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver12[(int) (62)]);
 //BA.debugLineNum = 1865;BA.debugLine="co_x(7) = ver12(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver12[(int) (63)]);
 //BA.debugLineNum = 1866;BA.debugLine="co_y(1) = ver12(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver12[(int) (57)]);
 //BA.debugLineNum = 1867;BA.debugLine="co_y(2) = ver12(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver12[(int) (58)]);
 //BA.debugLineNum = 1868;BA.debugLine="co_y(3) = ver12(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver12[(int) (59)]);
 //BA.debugLineNum = 1869;BA.debugLine="co_y(4) = ver12(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver12[(int) (60)]);
 //BA.debugLineNum = 1870;BA.debugLine="co_y(5) = ver12(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver12[(int) (61)]);
 //BA.debugLineNum = 1871;BA.debugLine="co_y(6) = ver12(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver12[(int) (62)]);
 //BA.debugLineNum = 1872;BA.debugLine="co_y(7) = ver12(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver12[(int) (63)]);
 break; }
case 13: {
 //BA.debugLineNum = 1874;BA.debugLine="co_x(1) = ver13(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver13[(int) (57)]);
 //BA.debugLineNum = 1875;BA.debugLine="co_x(2) = ver13(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver13[(int) (58)]);
 //BA.debugLineNum = 1876;BA.debugLine="co_x(3) = ver13(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver13[(int) (59)]);
 //BA.debugLineNum = 1877;BA.debugLine="co_x(4) = ver13(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver13[(int) (60)]);
 //BA.debugLineNum = 1878;BA.debugLine="co_x(5) = ver13(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver13[(int) (61)]);
 //BA.debugLineNum = 1879;BA.debugLine="co_x(6) = ver13(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver13[(int) (62)]);
 //BA.debugLineNum = 1880;BA.debugLine="co_x(7) = ver13(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver13[(int) (63)]);
 //BA.debugLineNum = 1881;BA.debugLine="co_y(1) = ver13(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver13[(int) (57)]);
 //BA.debugLineNum = 1882;BA.debugLine="co_y(2) = ver13(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver13[(int) (58)]);
 //BA.debugLineNum = 1883;BA.debugLine="co_y(3) = ver13(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver13[(int) (59)]);
 //BA.debugLineNum = 1884;BA.debugLine="co_y(4) = ver13(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver13[(int) (60)]);
 //BA.debugLineNum = 1885;BA.debugLine="co_y(5) = ver13(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver13[(int) (61)]);
 //BA.debugLineNum = 1886;BA.debugLine="co_y(6) = ver13(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver13[(int) (62)]);
 //BA.debugLineNum = 1887;BA.debugLine="co_y(7) = ver13(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver13[(int) (63)]);
 break; }
case 14: {
 //BA.debugLineNum = 1889;BA.debugLine="co_x(1) = ver14(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver14[(int) (57)]);
 //BA.debugLineNum = 1890;BA.debugLine="co_x(2) = ver14(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver14[(int) (58)]);
 //BA.debugLineNum = 1891;BA.debugLine="co_x(3) = ver14(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver14[(int) (59)]);
 //BA.debugLineNum = 1892;BA.debugLine="co_x(4) = ver14(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver14[(int) (60)]);
 //BA.debugLineNum = 1893;BA.debugLine="co_x(5) = ver14(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver14[(int) (61)]);
 //BA.debugLineNum = 1894;BA.debugLine="co_x(6) = ver14(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver14[(int) (62)]);
 //BA.debugLineNum = 1895;BA.debugLine="co_x(7) = ver14(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver14[(int) (63)]);
 //BA.debugLineNum = 1896;BA.debugLine="co_y(1) = ver14(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver14[(int) (57)]);
 //BA.debugLineNum = 1897;BA.debugLine="co_y(2) = ver14(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver14[(int) (58)]);
 //BA.debugLineNum = 1898;BA.debugLine="co_y(3) = ver14(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver14[(int) (59)]);
 //BA.debugLineNum = 1899;BA.debugLine="co_y(4) = ver14(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver14[(int) (60)]);
 //BA.debugLineNum = 1900;BA.debugLine="co_y(5) = ver14(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver14[(int) (61)]);
 //BA.debugLineNum = 1901;BA.debugLine="co_y(6) = ver14(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver14[(int) (62)]);
 //BA.debugLineNum = 1902;BA.debugLine="co_y(7) = ver14(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver14[(int) (63)]);
 break; }
case 15: {
 //BA.debugLineNum = 1904;BA.debugLine="co_x(1) = ver15(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver15[(int) (57)]);
 //BA.debugLineNum = 1905;BA.debugLine="co_x(2) = ver15(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver15[(int) (58)]);
 //BA.debugLineNum = 1906;BA.debugLine="co_x(3) = ver15(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver15[(int) (59)]);
 //BA.debugLineNum = 1907;BA.debugLine="co_x(4) = ver15(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver15[(int) (60)]);
 //BA.debugLineNum = 1908;BA.debugLine="co_x(5) = ver15(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver15[(int) (61)]);
 //BA.debugLineNum = 1909;BA.debugLine="co_x(6) = ver15(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver15[(int) (62)]);
 //BA.debugLineNum = 1910;BA.debugLine="co_x(7) = ver15(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver15[(int) (63)]);
 //BA.debugLineNum = 1911;BA.debugLine="co_y(1) = ver15(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver15[(int) (57)]);
 //BA.debugLineNum = 1912;BA.debugLine="co_y(2) = ver15(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver15[(int) (58)]);
 //BA.debugLineNum = 1913;BA.debugLine="co_y(3) = ver15(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver15[(int) (59)]);
 //BA.debugLineNum = 1914;BA.debugLine="co_y(4) = ver15(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver15[(int) (60)]);
 //BA.debugLineNum = 1915;BA.debugLine="co_y(5) = ver15(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver15[(int) (61)]);
 //BA.debugLineNum = 1916;BA.debugLine="co_y(6) = ver15(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver15[(int) (62)]);
 //BA.debugLineNum = 1917;BA.debugLine="co_y(7) = ver15(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver15[(int) (63)]);
 break; }
case 16: {
 //BA.debugLineNum = 1919;BA.debugLine="co_x(1) = ver16(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver16[(int) (57)]);
 //BA.debugLineNum = 1920;BA.debugLine="co_x(2) = ver16(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver16[(int) (58)]);
 //BA.debugLineNum = 1921;BA.debugLine="co_x(3) = ver16(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver16[(int) (59)]);
 //BA.debugLineNum = 1922;BA.debugLine="co_x(4) = ver16(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver16[(int) (60)]);
 //BA.debugLineNum = 1923;BA.debugLine="co_x(5) = ver16(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver16[(int) (61)]);
 //BA.debugLineNum = 1924;BA.debugLine="co_x(6) = ver16(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver16[(int) (62)]);
 //BA.debugLineNum = 1925;BA.debugLine="co_x(7) = ver16(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver16[(int) (63)]);
 //BA.debugLineNum = 1926;BA.debugLine="co_y(1) = ver16(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver16[(int) (57)]);
 //BA.debugLineNum = 1927;BA.debugLine="co_y(2) = ver16(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver16[(int) (58)]);
 //BA.debugLineNum = 1928;BA.debugLine="co_y(3) = ver16(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver16[(int) (59)]);
 //BA.debugLineNum = 1929;BA.debugLine="co_y(4) = ver16(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver16[(int) (60)]);
 //BA.debugLineNum = 1930;BA.debugLine="co_y(5) = ver16(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver16[(int) (61)]);
 //BA.debugLineNum = 1931;BA.debugLine="co_y(6) = ver16(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver16[(int) (62)]);
 //BA.debugLineNum = 1932;BA.debugLine="co_y(7) = ver15(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver15[(int) (63)]);
 break; }
case 17: {
 //BA.debugLineNum = 1934;BA.debugLine="co_x(1) = ver17(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver17[(int) (57)]);
 //BA.debugLineNum = 1935;BA.debugLine="co_x(2) = ver17(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver17[(int) (58)]);
 //BA.debugLineNum = 1936;BA.debugLine="co_x(3) = ver17(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver17[(int) (59)]);
 //BA.debugLineNum = 1937;BA.debugLine="co_x(4) = ver17(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver17[(int) (60)]);
 //BA.debugLineNum = 1938;BA.debugLine="co_x(5) = ver17(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver17[(int) (61)]);
 //BA.debugLineNum = 1939;BA.debugLine="co_x(6) = ver17(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver17[(int) (62)]);
 //BA.debugLineNum = 1940;BA.debugLine="co_x(7) = ver17(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver17[(int) (63)]);
 //BA.debugLineNum = 1941;BA.debugLine="co_y(1) = ver17(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver17[(int) (57)]);
 //BA.debugLineNum = 1942;BA.debugLine="co_y(2) = ver17(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver17[(int) (58)]);
 //BA.debugLineNum = 1943;BA.debugLine="co_y(3) = ver17(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver17[(int) (59)]);
 //BA.debugLineNum = 1944;BA.debugLine="co_y(4) = ver17(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver17[(int) (60)]);
 //BA.debugLineNum = 1945;BA.debugLine="co_y(5) = ver17(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver17[(int) (61)]);
 //BA.debugLineNum = 1946;BA.debugLine="co_y(6) = ver17(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver17[(int) (62)]);
 //BA.debugLineNum = 1947;BA.debugLine="co_y(7) = ver17(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver17[(int) (63)]);
 break; }
case 18: {
 //BA.debugLineNum = 1949;BA.debugLine="co_x(1) = ver18(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver18[(int) (57)]);
 //BA.debugLineNum = 1950;BA.debugLine="co_x(2) = ver18(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver18[(int) (58)]);
 //BA.debugLineNum = 1951;BA.debugLine="co_x(3) = ver18(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver18[(int) (59)]);
 //BA.debugLineNum = 1952;BA.debugLine="co_x(4) = ver18(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver18[(int) (60)]);
 //BA.debugLineNum = 1953;BA.debugLine="co_x(5) = ver18(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver18[(int) (61)]);
 //BA.debugLineNum = 1954;BA.debugLine="co_x(6) = ver18(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver18[(int) (62)]);
 //BA.debugLineNum = 1955;BA.debugLine="co_x(7) = ver18(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver18[(int) (63)]);
 //BA.debugLineNum = 1956;BA.debugLine="co_y(1) = ver18(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver18[(int) (57)]);
 //BA.debugLineNum = 1957;BA.debugLine="co_y(2) = ver18(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver18[(int) (58)]);
 //BA.debugLineNum = 1958;BA.debugLine="co_y(3) = ver18(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver18[(int) (59)]);
 //BA.debugLineNum = 1959;BA.debugLine="co_y(4) = ver18(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver18[(int) (60)]);
 //BA.debugLineNum = 1960;BA.debugLine="co_y(5) = ver18(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver18[(int) (61)]);
 //BA.debugLineNum = 1961;BA.debugLine="co_y(6) = ver18(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver18[(int) (62)]);
 //BA.debugLineNum = 1962;BA.debugLine="co_y(7) = ver18(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver18[(int) (63)]);
 break; }
case 19: {
 //BA.debugLineNum = 1964;BA.debugLine="co_x(1) = ver19(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver19[(int) (57)]);
 //BA.debugLineNum = 1965;BA.debugLine="co_x(2) = ver19(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver19[(int) (58)]);
 //BA.debugLineNum = 1966;BA.debugLine="co_x(3) = ver19(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver19[(int) (59)]);
 //BA.debugLineNum = 1967;BA.debugLine="co_x(4) = ver19(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver19[(int) (60)]);
 //BA.debugLineNum = 1968;BA.debugLine="co_x(5) = ver19(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver19[(int) (61)]);
 //BA.debugLineNum = 1969;BA.debugLine="co_x(6) = ver19(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver19[(int) (62)]);
 //BA.debugLineNum = 1970;BA.debugLine="co_x(7) = ver19(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver19[(int) (63)]);
 //BA.debugLineNum = 1971;BA.debugLine="co_y(1) = ver19(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver19[(int) (57)]);
 //BA.debugLineNum = 1972;BA.debugLine="co_y(2) = ver19(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver19[(int) (58)]);
 //BA.debugLineNum = 1973;BA.debugLine="co_y(3) = ver19(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver19[(int) (59)]);
 //BA.debugLineNum = 1974;BA.debugLine="co_y(4) = ver19(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver19[(int) (60)]);
 //BA.debugLineNum = 1975;BA.debugLine="co_y(5) = ver19(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver19[(int) (61)]);
 //BA.debugLineNum = 1976;BA.debugLine="co_y(6) = ver19(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver19[(int) (62)]);
 //BA.debugLineNum = 1977;BA.debugLine="co_y(7) = ver19(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver19[(int) (63)]);
 break; }
case 20: {
 //BA.debugLineNum = 1979;BA.debugLine="co_x(1) = ver20(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver20[(int) (57)]);
 //BA.debugLineNum = 1980;BA.debugLine="co_x(2) = ver20(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver20[(int) (58)]);
 //BA.debugLineNum = 1981;BA.debugLine="co_x(3) = ver20(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver20[(int) (59)]);
 //BA.debugLineNum = 1982;BA.debugLine="co_x(4) = ver20(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver20[(int) (60)]);
 //BA.debugLineNum = 1983;BA.debugLine="co_x(5) = ver20(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver20[(int) (61)]);
 //BA.debugLineNum = 1984;BA.debugLine="co_x(6) = ver20(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver20[(int) (62)]);
 //BA.debugLineNum = 1985;BA.debugLine="co_x(7) = ver20(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver20[(int) (63)]);
 //BA.debugLineNum = 1986;BA.debugLine="co_y(1) = ver20(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver20[(int) (57)]);
 //BA.debugLineNum = 1987;BA.debugLine="co_y(2) = ver20(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver20[(int) (58)]);
 //BA.debugLineNum = 1988;BA.debugLine="co_y(3) = ver20(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver20[(int) (59)]);
 //BA.debugLineNum = 1989;BA.debugLine="co_y(4) = ver20(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver20[(int) (60)]);
 //BA.debugLineNum = 1990;BA.debugLine="co_y(5) = ver20(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver20[(int) (61)]);
 //BA.debugLineNum = 1991;BA.debugLine="co_y(6) = ver20(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver20[(int) (62)]);
 //BA.debugLineNum = 1992;BA.debugLine="co_y(7) = ver20(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver20[(int) (63)]);
 break; }
case 21: {
 //BA.debugLineNum = 1994;BA.debugLine="co_x(1) = ver21(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver21[(int) (57)]);
 //BA.debugLineNum = 1995;BA.debugLine="co_x(2) = ver21(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver21[(int) (58)]);
 //BA.debugLineNum = 1996;BA.debugLine="co_x(3) = ver21(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver21[(int) (59)]);
 //BA.debugLineNum = 1997;BA.debugLine="co_x(4) = ver21(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver21[(int) (60)]);
 //BA.debugLineNum = 1998;BA.debugLine="co_x(5) = ver21(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver21[(int) (61)]);
 //BA.debugLineNum = 1999;BA.debugLine="co_x(6) = ver21(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver21[(int) (62)]);
 //BA.debugLineNum = 2000;BA.debugLine="co_x(7) = ver21(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver21[(int) (63)]);
 //BA.debugLineNum = 2001;BA.debugLine="co_y(1) = ver21(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver21[(int) (57)]);
 //BA.debugLineNum = 2002;BA.debugLine="co_y(2) = ver21(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver21[(int) (58)]);
 //BA.debugLineNum = 2003;BA.debugLine="co_y(3) = ver21(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver21[(int) (59)]);
 //BA.debugLineNum = 2004;BA.debugLine="co_y(4) = ver21(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver21[(int) (60)]);
 //BA.debugLineNum = 2005;BA.debugLine="co_y(5) = ver21(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver21[(int) (61)]);
 //BA.debugLineNum = 2006;BA.debugLine="co_y(6) = ver21(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver21[(int) (62)]);
 //BA.debugLineNum = 2007;BA.debugLine="co_y(7) = ver21(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver21[(int) (63)]);
 break; }
case 22: {
 //BA.debugLineNum = 2009;BA.debugLine="co_x(1) = ver22(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver22[(int) (57)]);
 //BA.debugLineNum = 2010;BA.debugLine="co_x(2) = ver22(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver22[(int) (58)]);
 //BA.debugLineNum = 2011;BA.debugLine="co_x(3) = ver22(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver22[(int) (59)]);
 //BA.debugLineNum = 2012;BA.debugLine="co_x(4) = ver22(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver22[(int) (60)]);
 //BA.debugLineNum = 2013;BA.debugLine="co_x(5) = ver22(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver22[(int) (61)]);
 //BA.debugLineNum = 2014;BA.debugLine="co_x(6) = ver22(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver22[(int) (62)]);
 //BA.debugLineNum = 2015;BA.debugLine="co_x(7) = ver22(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver22[(int) (63)]);
 //BA.debugLineNum = 2016;BA.debugLine="co_y(1) = ver22(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver22[(int) (57)]);
 //BA.debugLineNum = 2017;BA.debugLine="co_y(2) = ver22(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver22[(int) (58)]);
 //BA.debugLineNum = 2018;BA.debugLine="co_y(3) = ver22(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver22[(int) (59)]);
 //BA.debugLineNum = 2019;BA.debugLine="co_y(4) = ver22(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver22[(int) (60)]);
 //BA.debugLineNum = 2020;BA.debugLine="co_y(5) = ver22(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver22[(int) (61)]);
 //BA.debugLineNum = 2021;BA.debugLine="co_y(6) = ver22(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver22[(int) (62)]);
 //BA.debugLineNum = 2022;BA.debugLine="co_y(7) = ver22(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver22[(int) (63)]);
 break; }
case 23: {
 //BA.debugLineNum = 2024;BA.debugLine="co_x(1) = ver23(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver23[(int) (57)]);
 //BA.debugLineNum = 2025;BA.debugLine="co_x(2) = ver23(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver23[(int) (58)]);
 //BA.debugLineNum = 2026;BA.debugLine="co_x(3) = ver23(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver23[(int) (59)]);
 //BA.debugLineNum = 2027;BA.debugLine="co_x(4) = ver23(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver23[(int) (60)]);
 //BA.debugLineNum = 2028;BA.debugLine="co_x(5) = ver23(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver23[(int) (61)]);
 //BA.debugLineNum = 2029;BA.debugLine="co_x(6) = ver23(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver23[(int) (62)]);
 //BA.debugLineNum = 2030;BA.debugLine="co_x(7) = ver23(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver23[(int) (63)]);
 //BA.debugLineNum = 2031;BA.debugLine="co_y(1) = ver23(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver23[(int) (57)]);
 //BA.debugLineNum = 2032;BA.debugLine="co_y(2) = ver23(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver23[(int) (58)]);
 //BA.debugLineNum = 2033;BA.debugLine="co_y(3) = ver23(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver23[(int) (59)]);
 //BA.debugLineNum = 2034;BA.debugLine="co_y(4) = ver23(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver23[(int) (60)]);
 //BA.debugLineNum = 2035;BA.debugLine="co_y(5) = ver23(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver23[(int) (61)]);
 //BA.debugLineNum = 2036;BA.debugLine="co_y(6) = ver23(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver23[(int) (62)]);
 //BA.debugLineNum = 2037;BA.debugLine="co_y(7) = ver23(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver23[(int) (63)]);
 break; }
case 24: {
 //BA.debugLineNum = 2039;BA.debugLine="co_x(1) = ver24(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver24[(int) (57)]);
 //BA.debugLineNum = 2040;BA.debugLine="co_x(2) = ver24(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver24[(int) (58)]);
 //BA.debugLineNum = 2041;BA.debugLine="co_x(3) = ver24(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver24[(int) (59)]);
 //BA.debugLineNum = 2042;BA.debugLine="co_x(4) = ver24(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver24[(int) (60)]);
 //BA.debugLineNum = 2043;BA.debugLine="co_x(5) = ver24(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver24[(int) (61)]);
 //BA.debugLineNum = 2044;BA.debugLine="co_x(6) = ver24(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver24[(int) (62)]);
 //BA.debugLineNum = 2045;BA.debugLine="co_x(7) = ver24(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver24[(int) (63)]);
 //BA.debugLineNum = 2046;BA.debugLine="co_y(1) = ver24(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver24[(int) (57)]);
 //BA.debugLineNum = 2047;BA.debugLine="co_y(2) = ver24(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver24[(int) (58)]);
 //BA.debugLineNum = 2048;BA.debugLine="co_y(3) = ver24(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver24[(int) (59)]);
 //BA.debugLineNum = 2049;BA.debugLine="co_y(4) = ver24(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver24[(int) (60)]);
 //BA.debugLineNum = 2050;BA.debugLine="co_y(5) = ver24(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver24[(int) (61)]);
 //BA.debugLineNum = 2051;BA.debugLine="co_y(6) = ver24(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver24[(int) (62)]);
 //BA.debugLineNum = 2052;BA.debugLine="co_y(7) = ver24(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver24[(int) (63)]);
 break; }
case 25: {
 //BA.debugLineNum = 2054;BA.debugLine="co_x(1) = ver25(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver25[(int) (57)]);
 //BA.debugLineNum = 2055;BA.debugLine="co_x(2) = ver25(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver25[(int) (58)]);
 //BA.debugLineNum = 2056;BA.debugLine="co_x(3) = ver25(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver25[(int) (59)]);
 //BA.debugLineNum = 2057;BA.debugLine="co_x(4) = ver25(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver25[(int) (60)]);
 //BA.debugLineNum = 2058;BA.debugLine="co_x(5) = ver25(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver25[(int) (61)]);
 //BA.debugLineNum = 2059;BA.debugLine="co_x(6) = ver25(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver25[(int) (62)]);
 //BA.debugLineNum = 2060;BA.debugLine="co_x(7) = ver25(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver25[(int) (63)]);
 //BA.debugLineNum = 2061;BA.debugLine="co_y(1) = ver25(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver25[(int) (57)]);
 //BA.debugLineNum = 2062;BA.debugLine="co_y(2) = ver25(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver25[(int) (58)]);
 //BA.debugLineNum = 2063;BA.debugLine="co_y(3) = ver25(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver25[(int) (59)]);
 //BA.debugLineNum = 2064;BA.debugLine="co_y(4) = ver25(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver25[(int) (60)]);
 //BA.debugLineNum = 2065;BA.debugLine="co_y(5) = ver25(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver25[(int) (61)]);
 //BA.debugLineNum = 2066;BA.debugLine="co_y(6) = ver25(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver25[(int) (62)]);
 //BA.debugLineNum = 2067;BA.debugLine="co_y(7) = ver25(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver25[(int) (63)]);
 break; }
case 26: {
 //BA.debugLineNum = 2069;BA.debugLine="co_x(1) = ver26(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver26[(int) (57)]);
 //BA.debugLineNum = 2070;BA.debugLine="co_x(2) = ver26(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver26[(int) (58)]);
 //BA.debugLineNum = 2071;BA.debugLine="co_x(3) = ver26(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver26[(int) (59)]);
 //BA.debugLineNum = 2072;BA.debugLine="co_x(4) = ver26(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver26[(int) (60)]);
 //BA.debugLineNum = 2073;BA.debugLine="co_x(5) = ver26(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver26[(int) (61)]);
 //BA.debugLineNum = 2074;BA.debugLine="co_x(6) = ver26(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver26[(int) (62)]);
 //BA.debugLineNum = 2075;BA.debugLine="co_x(7) = ver26(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver26[(int) (63)]);
 //BA.debugLineNum = 2076;BA.debugLine="co_y(1) = ver26(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver26[(int) (57)]);
 //BA.debugLineNum = 2077;BA.debugLine="co_y(2) = ver26(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver26[(int) (58)]);
 //BA.debugLineNum = 2078;BA.debugLine="co_y(3) = ver26(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver26[(int) (59)]);
 //BA.debugLineNum = 2079;BA.debugLine="co_y(4) = ver26(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver26[(int) (60)]);
 //BA.debugLineNum = 2080;BA.debugLine="co_y(5) = ver26(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver26[(int) (61)]);
 //BA.debugLineNum = 2081;BA.debugLine="co_y(6) = ver26(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver26[(int) (62)]);
 //BA.debugLineNum = 2082;BA.debugLine="co_y(7) = ver26(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver26[(int) (63)]);
 break; }
case 27: {
 //BA.debugLineNum = 2084;BA.debugLine="co_x(1) = ver27(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver27[(int) (57)]);
 //BA.debugLineNum = 2085;BA.debugLine="co_x(2) = ver27(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver27[(int) (58)]);
 //BA.debugLineNum = 2086;BA.debugLine="co_x(3) = ver27(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver27[(int) (59)]);
 //BA.debugLineNum = 2087;BA.debugLine="co_x(4) = ver27(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver27[(int) (60)]);
 //BA.debugLineNum = 2088;BA.debugLine="co_x(5) = ver27(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver27[(int) (61)]);
 //BA.debugLineNum = 2089;BA.debugLine="co_x(6) = ver27(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver27[(int) (62)]);
 //BA.debugLineNum = 2090;BA.debugLine="co_x(7) = ver27(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver27[(int) (63)]);
 //BA.debugLineNum = 2091;BA.debugLine="co_y(1) = ver27(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver27[(int) (57)]);
 //BA.debugLineNum = 2092;BA.debugLine="co_y(2) = ver27(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver27[(int) (58)]);
 //BA.debugLineNum = 2093;BA.debugLine="co_y(3) = ver27(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver27[(int) (59)]);
 //BA.debugLineNum = 2094;BA.debugLine="co_y(4) = ver27(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver27[(int) (60)]);
 //BA.debugLineNum = 2095;BA.debugLine="co_y(5) = ver27(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver27[(int) (61)]);
 //BA.debugLineNum = 2096;BA.debugLine="co_y(6) = ver27(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver27[(int) (62)]);
 //BA.debugLineNum = 2097;BA.debugLine="co_y(7) = ver27(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver27[(int) (63)]);
 break; }
case 28: {
 //BA.debugLineNum = 2099;BA.debugLine="co_x(1) = ver28(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver28[(int) (57)]);
 //BA.debugLineNum = 2100;BA.debugLine="co_x(2) = ver28(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver28[(int) (58)]);
 //BA.debugLineNum = 2101;BA.debugLine="co_x(3) = ver28(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver28[(int) (59)]);
 //BA.debugLineNum = 2102;BA.debugLine="co_x(4) = ver28(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver28[(int) (60)]);
 //BA.debugLineNum = 2103;BA.debugLine="co_x(5) = ver28(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver28[(int) (61)]);
 //BA.debugLineNum = 2104;BA.debugLine="co_x(6) = ver28(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver28[(int) (62)]);
 //BA.debugLineNum = 2105;BA.debugLine="co_x(7) = ver28(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver28[(int) (63)]);
 //BA.debugLineNum = 2106;BA.debugLine="co_y(1) = ver28(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver28[(int) (57)]);
 //BA.debugLineNum = 2107;BA.debugLine="co_y(2) = ver28(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver28[(int) (58)]);
 //BA.debugLineNum = 2108;BA.debugLine="co_y(3) = ver28(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver28[(int) (59)]);
 //BA.debugLineNum = 2109;BA.debugLine="co_y(4) = ver28(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver28[(int) (60)]);
 //BA.debugLineNum = 2110;BA.debugLine="co_y(5) = ver28(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver28[(int) (61)]);
 //BA.debugLineNum = 2111;BA.debugLine="co_y(6) = ver28(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver28[(int) (62)]);
 //BA.debugLineNum = 2112;BA.debugLine="co_y(7) = ver28(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver28[(int) (63)]);
 break; }
case 29: {
 //BA.debugLineNum = 2114;BA.debugLine="co_x(1) = ver29(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver29[(int) (57)]);
 //BA.debugLineNum = 2115;BA.debugLine="co_x(2) = ver29(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver29[(int) (58)]);
 //BA.debugLineNum = 2116;BA.debugLine="co_x(3) = ver29(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver29[(int) (59)]);
 //BA.debugLineNum = 2117;BA.debugLine="co_x(4) = ver29(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver29[(int) (60)]);
 //BA.debugLineNum = 2118;BA.debugLine="co_x(5) = ver29(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver29[(int) (61)]);
 //BA.debugLineNum = 2119;BA.debugLine="co_x(6) = ver29(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver29[(int) (62)]);
 //BA.debugLineNum = 2120;BA.debugLine="co_x(7) = ver29(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver29[(int) (63)]);
 //BA.debugLineNum = 2121;BA.debugLine="co_y(1) = ver29(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver29[(int) (57)]);
 //BA.debugLineNum = 2122;BA.debugLine="co_y(2) = ver29(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver29[(int) (58)]);
 //BA.debugLineNum = 2123;BA.debugLine="co_y(3) = ver29(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver29[(int) (59)]);
 //BA.debugLineNum = 2124;BA.debugLine="co_y(4) = ver29(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver29[(int) (60)]);
 //BA.debugLineNum = 2125;BA.debugLine="co_y(5) = ver29(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver29[(int) (61)]);
 //BA.debugLineNum = 2126;BA.debugLine="co_y(6) = ver29(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver29[(int) (62)]);
 //BA.debugLineNum = 2127;BA.debugLine="co_y(7) = ver29(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver29[(int) (63)]);
 break; }
case 30: {
 //BA.debugLineNum = 2129;BA.debugLine="co_x(1) = ver30(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver30[(int) (57)]);
 //BA.debugLineNum = 2130;BA.debugLine="co_x(2) = ver30(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver30[(int) (58)]);
 //BA.debugLineNum = 2131;BA.debugLine="co_x(3) = ver30(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver30[(int) (59)]);
 //BA.debugLineNum = 2132;BA.debugLine="co_x(4) = ver30(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver30[(int) (60)]);
 //BA.debugLineNum = 2133;BA.debugLine="co_x(5) = ver30(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver30[(int) (61)]);
 //BA.debugLineNum = 2134;BA.debugLine="co_x(6) = ver30(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver30[(int) (62)]);
 //BA.debugLineNum = 2135;BA.debugLine="co_x(7) = ver30(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver30[(int) (63)]);
 //BA.debugLineNum = 2136;BA.debugLine="co_y(1) = ver30(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver30[(int) (57)]);
 //BA.debugLineNum = 2137;BA.debugLine="co_y(2) = ver30(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver30[(int) (58)]);
 //BA.debugLineNum = 2138;BA.debugLine="co_y(3) = ver30(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver30[(int) (59)]);
 //BA.debugLineNum = 2139;BA.debugLine="co_y(4) = ver30(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver30[(int) (60)]);
 //BA.debugLineNum = 2140;BA.debugLine="co_y(5) = ver30(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver30[(int) (61)]);
 //BA.debugLineNum = 2141;BA.debugLine="co_y(6) = ver30(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver30[(int) (62)]);
 //BA.debugLineNum = 2142;BA.debugLine="co_y(7) = ver30(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver30[(int) (63)]);
 break; }
case 31: {
 //BA.debugLineNum = 2144;BA.debugLine="co_x(1) = ver31(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver31[(int) (57)]);
 //BA.debugLineNum = 2145;BA.debugLine="co_x(2) = ver31(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver31[(int) (58)]);
 //BA.debugLineNum = 2146;BA.debugLine="co_x(3) = ver31(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver31[(int) (59)]);
 //BA.debugLineNum = 2147;BA.debugLine="co_x(4) = ver31(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver31[(int) (60)]);
 //BA.debugLineNum = 2148;BA.debugLine="co_x(5) = ver31(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver31[(int) (61)]);
 //BA.debugLineNum = 2149;BA.debugLine="co_x(6) = ver31(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver31[(int) (62)]);
 //BA.debugLineNum = 2150;BA.debugLine="co_x(7) = ver31(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver31[(int) (63)]);
 //BA.debugLineNum = 2151;BA.debugLine="co_y(1) = ver31(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver31[(int) (57)]);
 //BA.debugLineNum = 2152;BA.debugLine="co_y(2) = ver31(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver31[(int) (58)]);
 //BA.debugLineNum = 2153;BA.debugLine="co_y(3) = ver31(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver31[(int) (59)]);
 //BA.debugLineNum = 2154;BA.debugLine="co_y(4) = ver31(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver31[(int) (60)]);
 //BA.debugLineNum = 2155;BA.debugLine="co_y(5) = ver31(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver31[(int) (61)]);
 //BA.debugLineNum = 2156;BA.debugLine="co_y(6) = ver31(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver31[(int) (62)]);
 //BA.debugLineNum = 2157;BA.debugLine="co_y(7) = ver31(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver31[(int) (63)]);
 break; }
case 32: {
 //BA.debugLineNum = 2159;BA.debugLine="co_x(1) = ver32(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver32[(int) (57)]);
 //BA.debugLineNum = 2160;BA.debugLine="co_x(2) = ver32(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver32[(int) (58)]);
 //BA.debugLineNum = 2161;BA.debugLine="co_x(3) = ver32(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver32[(int) (59)]);
 //BA.debugLineNum = 2162;BA.debugLine="co_x(4) = ver32(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver32[(int) (60)]);
 //BA.debugLineNum = 2163;BA.debugLine="co_x(5) = ver32(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver32[(int) (61)]);
 //BA.debugLineNum = 2164;BA.debugLine="co_x(6) = ver32(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver32[(int) (62)]);
 //BA.debugLineNum = 2165;BA.debugLine="co_x(7) = ver32(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver32[(int) (63)]);
 //BA.debugLineNum = 2166;BA.debugLine="co_y(1) = ver32(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver32[(int) (57)]);
 //BA.debugLineNum = 2167;BA.debugLine="co_y(2) = ver32(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver32[(int) (58)]);
 //BA.debugLineNum = 2168;BA.debugLine="co_y(3) = ver32(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver32[(int) (59)]);
 //BA.debugLineNum = 2169;BA.debugLine="co_y(4) = ver32(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver32[(int) (60)]);
 //BA.debugLineNum = 2170;BA.debugLine="co_y(5) = ver32(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver32[(int) (61)]);
 //BA.debugLineNum = 2171;BA.debugLine="co_y(6) = ver32(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver32[(int) (62)]);
 //BA.debugLineNum = 2172;BA.debugLine="co_y(7) = ver32(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver32[(int) (63)]);
 break; }
case 33: {
 //BA.debugLineNum = 2174;BA.debugLine="co_x(1) = ver33(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver33[(int) (57)]);
 //BA.debugLineNum = 2175;BA.debugLine="co_x(2) = ver33(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver33[(int) (58)]);
 //BA.debugLineNum = 2176;BA.debugLine="co_x(3) = ver33(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver33[(int) (59)]);
 //BA.debugLineNum = 2177;BA.debugLine="co_x(4) = ver33(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver33[(int) (60)]);
 //BA.debugLineNum = 2178;BA.debugLine="co_x(5) = ver33(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver33[(int) (61)]);
 //BA.debugLineNum = 2179;BA.debugLine="co_x(6) = ver33(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver33[(int) (62)]);
 //BA.debugLineNum = 2180;BA.debugLine="co_x(7) = ver33(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver33[(int) (63)]);
 //BA.debugLineNum = 2181;BA.debugLine="co_y(1) = ver33(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver33[(int) (57)]);
 //BA.debugLineNum = 2182;BA.debugLine="co_y(2) = ver33(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver33[(int) (58)]);
 //BA.debugLineNum = 2183;BA.debugLine="co_y(3) = ver33(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver33[(int) (59)]);
 //BA.debugLineNum = 2184;BA.debugLine="co_y(4) = ver33(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver33[(int) (60)]);
 //BA.debugLineNum = 2185;BA.debugLine="co_y(5) = ver33(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver33[(int) (61)]);
 //BA.debugLineNum = 2186;BA.debugLine="co_y(6) = ver33(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver33[(int) (62)]);
 //BA.debugLineNum = 2187;BA.debugLine="co_y(7) = ver33(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver33[(int) (63)]);
 break; }
case 34: {
 //BA.debugLineNum = 2189;BA.debugLine="co_x(1) = ver34(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver34[(int) (57)]);
 //BA.debugLineNum = 2190;BA.debugLine="co_x(2) = ver34(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver34[(int) (58)]);
 //BA.debugLineNum = 2191;BA.debugLine="co_x(3) = ver34(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver34[(int) (59)]);
 //BA.debugLineNum = 2192;BA.debugLine="co_x(4) = ver34(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver34[(int) (60)]);
 //BA.debugLineNum = 2193;BA.debugLine="co_x(5) = ver34(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver34[(int) (61)]);
 //BA.debugLineNum = 2194;BA.debugLine="co_x(6) = ver34(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver34[(int) (62)]);
 //BA.debugLineNum = 2195;BA.debugLine="co_x(7) = ver34(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver34[(int) (63)]);
 //BA.debugLineNum = 2196;BA.debugLine="co_y(1) = ver34(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver34[(int) (57)]);
 //BA.debugLineNum = 2197;BA.debugLine="co_y(2) = ver34(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver34[(int) (58)]);
 //BA.debugLineNum = 2198;BA.debugLine="co_y(3) = ver34(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver34[(int) (59)]);
 //BA.debugLineNum = 2199;BA.debugLine="co_y(4) = ver34(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver34[(int) (60)]);
 //BA.debugLineNum = 2200;BA.debugLine="co_y(5) = ver34(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver34[(int) (61)]);
 //BA.debugLineNum = 2201;BA.debugLine="co_y(6) = ver34(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver34[(int) (62)]);
 //BA.debugLineNum = 2202;BA.debugLine="co_y(7) = ver34(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver34[(int) (63)]);
 break; }
case 35: {
 //BA.debugLineNum = 2204;BA.debugLine="co_x(1) = ver35(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver35[(int) (57)]);
 //BA.debugLineNum = 2205;BA.debugLine="co_x(2) = ver35(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver35[(int) (58)]);
 //BA.debugLineNum = 2206;BA.debugLine="co_x(3) = ver35(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver35[(int) (59)]);
 //BA.debugLineNum = 2207;BA.debugLine="co_x(4) = ver35(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver35[(int) (60)]);
 //BA.debugLineNum = 2208;BA.debugLine="co_x(5) = ver35(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver35[(int) (61)]);
 //BA.debugLineNum = 2209;BA.debugLine="co_x(6) = ver35(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver35[(int) (62)]);
 //BA.debugLineNum = 2210;BA.debugLine="co_x(7) = ver35(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver35[(int) (63)]);
 //BA.debugLineNum = 2211;BA.debugLine="co_y(1) = ver35(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver35[(int) (57)]);
 //BA.debugLineNum = 2212;BA.debugLine="co_y(2) = ver35(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver35[(int) (58)]);
 //BA.debugLineNum = 2213;BA.debugLine="co_y(3) = ver35(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver35[(int) (59)]);
 //BA.debugLineNum = 2214;BA.debugLine="co_y(4) = ver35(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver35[(int) (60)]);
 //BA.debugLineNum = 2215;BA.debugLine="co_y(5) = ver35(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver35[(int) (61)]);
 //BA.debugLineNum = 2216;BA.debugLine="co_y(6) = ver35(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver35[(int) (62)]);
 //BA.debugLineNum = 2217;BA.debugLine="co_y(7) = ver35(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver35[(int) (63)]);
 break; }
case 36: {
 //BA.debugLineNum = 2219;BA.debugLine="co_x(1) = ver36(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver36[(int) (57)]);
 //BA.debugLineNum = 2220;BA.debugLine="co_x(2) = ver36(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver36[(int) (58)]);
 //BA.debugLineNum = 2221;BA.debugLine="co_x(3) = ver36(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver36[(int) (59)]);
 //BA.debugLineNum = 2222;BA.debugLine="co_x(4) = ver36(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver36[(int) (60)]);
 //BA.debugLineNum = 2223;BA.debugLine="co_x(5) = ver36(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver36[(int) (61)]);
 //BA.debugLineNum = 2224;BA.debugLine="co_x(6) = ver36(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver36[(int) (62)]);
 //BA.debugLineNum = 2225;BA.debugLine="co_x(7) = ver36(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver36[(int) (63)]);
 //BA.debugLineNum = 2226;BA.debugLine="co_y(1) = ver36(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver36[(int) (57)]);
 //BA.debugLineNum = 2227;BA.debugLine="co_y(2) = ver36(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver36[(int) (58)]);
 //BA.debugLineNum = 2228;BA.debugLine="co_y(3) = ver36(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver36[(int) (59)]);
 //BA.debugLineNum = 2229;BA.debugLine="co_y(4) = ver36(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver36[(int) (60)]);
 //BA.debugLineNum = 2230;BA.debugLine="co_y(5) = ver36(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver36[(int) (61)]);
 //BA.debugLineNum = 2231;BA.debugLine="co_y(6) = ver36(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver36[(int) (62)]);
 //BA.debugLineNum = 2232;BA.debugLine="co_y(7) = ver36(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver36[(int) (63)]);
 break; }
case 37: {
 //BA.debugLineNum = 2234;BA.debugLine="co_x(1) = ver37(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver37[(int) (57)]);
 //BA.debugLineNum = 2235;BA.debugLine="co_x(2) = ver37(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver37[(int) (58)]);
 //BA.debugLineNum = 2236;BA.debugLine="co_x(3) = ver37(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver37[(int) (59)]);
 //BA.debugLineNum = 2237;BA.debugLine="co_x(4) = ver37(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver37[(int) (60)]);
 //BA.debugLineNum = 2238;BA.debugLine="co_x(5) = ver37(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver37[(int) (61)]);
 //BA.debugLineNum = 2239;BA.debugLine="co_x(6) = ver37(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver37[(int) (62)]);
 //BA.debugLineNum = 2240;BA.debugLine="co_x(7) = ver37(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver37[(int) (63)]);
 //BA.debugLineNum = 2241;BA.debugLine="co_y(1) = ver37(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver37[(int) (57)]);
 //BA.debugLineNum = 2242;BA.debugLine="co_y(2) = ver37(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver37[(int) (58)]);
 //BA.debugLineNum = 2243;BA.debugLine="co_y(3) = ver37(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver37[(int) (59)]);
 //BA.debugLineNum = 2244;BA.debugLine="co_y(4) = ver37(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver37[(int) (60)]);
 //BA.debugLineNum = 2245;BA.debugLine="co_y(5) = ver37(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver37[(int) (61)]);
 //BA.debugLineNum = 2246;BA.debugLine="co_y(6) = ver37(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver37[(int) (62)]);
 //BA.debugLineNum = 2247;BA.debugLine="co_y(7) = ver37(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver37[(int) (63)]);
 break; }
case 38: {
 //BA.debugLineNum = 2249;BA.debugLine="co_x(1) = ver38(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver38[(int) (57)]);
 //BA.debugLineNum = 2250;BA.debugLine="co_x(2) = ver38(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver38[(int) (58)]);
 //BA.debugLineNum = 2251;BA.debugLine="co_x(3) = ver38(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver38[(int) (59)]);
 //BA.debugLineNum = 2252;BA.debugLine="co_x(4) = ver38(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver38[(int) (60)]);
 //BA.debugLineNum = 2253;BA.debugLine="co_x(5) = ver38(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver38[(int) (61)]);
 //BA.debugLineNum = 2254;BA.debugLine="co_x(6) = ver38(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver38[(int) (62)]);
 //BA.debugLineNum = 2255;BA.debugLine="co_x(7) = ver38(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver38[(int) (63)]);
 //BA.debugLineNum = 2256;BA.debugLine="co_y(1) = ver38(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver38[(int) (57)]);
 //BA.debugLineNum = 2257;BA.debugLine="co_y(2) = ver38(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver38[(int) (58)]);
 //BA.debugLineNum = 2258;BA.debugLine="co_y(3) = ver38(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver38[(int) (59)]);
 //BA.debugLineNum = 2259;BA.debugLine="co_y(4) = ver38(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver38[(int) (60)]);
 //BA.debugLineNum = 2260;BA.debugLine="co_y(5) = ver38(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver38[(int) (61)]);
 //BA.debugLineNum = 2261;BA.debugLine="co_y(6) = ver38(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver38[(int) (62)]);
 //BA.debugLineNum = 2262;BA.debugLine="co_y(7) = ver38(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver38[(int) (63)]);
 break; }
case 39: {
 //BA.debugLineNum = 2264;BA.debugLine="co_x(1) = ver39(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver39[(int) (57)]);
 //BA.debugLineNum = 2265;BA.debugLine="co_x(2) = ver39(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver39[(int) (58)]);
 //BA.debugLineNum = 2266;BA.debugLine="co_x(3) = ver39(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver39[(int) (59)]);
 //BA.debugLineNum = 2267;BA.debugLine="co_x(4) = ver39(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver39[(int) (60)]);
 //BA.debugLineNum = 2268;BA.debugLine="co_x(5) = ver39(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver39[(int) (61)]);
 //BA.debugLineNum = 2269;BA.debugLine="co_x(6) = ver39(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver39[(int) (62)]);
 //BA.debugLineNum = 2270;BA.debugLine="co_x(7) = ver39(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver39[(int) (63)]);
 //BA.debugLineNum = 2271;BA.debugLine="co_y(1) = ver39(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver39[(int) (57)]);
 //BA.debugLineNum = 2272;BA.debugLine="co_y(2) = ver39(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver39[(int) (58)]);
 //BA.debugLineNum = 2273;BA.debugLine="co_y(3) = ver39(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver39[(int) (59)]);
 //BA.debugLineNum = 2274;BA.debugLine="co_y(4) = ver39(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver39[(int) (60)]);
 //BA.debugLineNum = 2275;BA.debugLine="co_y(5) = ver39(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver39[(int) (61)]);
 //BA.debugLineNum = 2276;BA.debugLine="co_y(6) = ver39(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver39[(int) (62)]);
 //BA.debugLineNum = 2277;BA.debugLine="co_y(7) = ver39(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver39[(int) (63)]);
 break; }
case 40: {
 //BA.debugLineNum = 2279;BA.debugLine="co_x(1) = ver40(57)";
_co_x[(int) (1)] = BA.NumberToString(_ver40[(int) (57)]);
 //BA.debugLineNum = 2280;BA.debugLine="co_x(2) = ver40(58)";
_co_x[(int) (2)] = BA.NumberToString(_ver40[(int) (58)]);
 //BA.debugLineNum = 2281;BA.debugLine="co_x(3) = ver40(59)";
_co_x[(int) (3)] = BA.NumberToString(_ver40[(int) (59)]);
 //BA.debugLineNum = 2282;BA.debugLine="co_x(4) = ver40(60)";
_co_x[(int) (4)] = BA.NumberToString(_ver40[(int) (60)]);
 //BA.debugLineNum = 2283;BA.debugLine="co_x(5) = ver40(61)";
_co_x[(int) (5)] = BA.NumberToString(_ver40[(int) (61)]);
 //BA.debugLineNum = 2284;BA.debugLine="co_x(6) = ver40(62)";
_co_x[(int) (6)] = BA.NumberToString(_ver40[(int) (62)]);
 //BA.debugLineNum = 2285;BA.debugLine="co_x(7) = ver40(63)";
_co_x[(int) (7)] = BA.NumberToString(_ver40[(int) (63)]);
 //BA.debugLineNum = 2286;BA.debugLine="co_y(1) = ver40(57)";
_co_y[(int) (1)] = BA.NumberToString(_ver40[(int) (57)]);
 //BA.debugLineNum = 2287;BA.debugLine="co_y(2) = ver40(58)";
_co_y[(int) (2)] = BA.NumberToString(_ver40[(int) (58)]);
 //BA.debugLineNum = 2288;BA.debugLine="co_y(3) = ver40(59)";
_co_y[(int) (3)] = BA.NumberToString(_ver40[(int) (59)]);
 //BA.debugLineNum = 2289;BA.debugLine="co_y(4) = ver40(60)";
_co_y[(int) (4)] = BA.NumberToString(_ver40[(int) (60)]);
 //BA.debugLineNum = 2290;BA.debugLine="co_y(5) = ver40(61)";
_co_y[(int) (5)] = BA.NumberToString(_ver40[(int) (61)]);
 //BA.debugLineNum = 2291;BA.debugLine="co_y(6) = ver40(62)";
_co_y[(int) (6)] = BA.NumberToString(_ver40[(int) (62)]);
 //BA.debugLineNum = 2292;BA.debugLine="co_y(7) = ver40(63)";
_co_y[(int) (7)] = BA.NumberToString(_ver40[(int) (63)]);
 break; }
}
;
 //BA.debugLineNum = 2295;BA.debugLine="Dim flag,last As Int";
_flag = 0;
_last = 0;
 //BA.debugLineNum = 2297;BA.debugLine="If version_no > 1 Then  'only required for version";
if (_version_no>1) { 
 //BA.debugLineNum = 2298;BA.debugLine="flag = 0";
_flag = (int) (0);
 //BA.debugLineNum = 2299;BA.debugLine="For k = 1 To 7";
{
final int step865 = 1;
final int limit865 = (int) (7);
for (_k = (int) (1) ; (step865 > 0 && _k <= limit865) || (step865 < 0 && _k >= limit865); _k = ((int)(0 + _k + step865)) ) {
 //BA.debugLineNum = 2300;BA.debugLine="If co_x(k) = 0 Then   'And flag = 0";
if ((_co_x[_k]).equals(BA.NumberToString(0))) { 
 //BA.debugLineNum = 2301;BA.debugLine="last = co_x(k - 1)";
_last = (int)(Double.parseDouble(_co_x[(int) (_k-1)]));
 //BA.debugLineNum = 2302;BA.debugLine="Exit";
if (true) break;
 }else {
 //BA.debugLineNum = 2304;BA.debugLine="last = co_x(k)";
_last = (int)(Double.parseDouble(_co_x[_k]));
 };
 }
};
 };
 //BA.debugLineNum = 2309;BA.debugLine="teller = 1";
_teller = (int) (1);
 //BA.debugLineNum = 2310;BA.debugLine="For i = 1 To 7";
{
final int step875 = 1;
final int limit875 = (int) (7);
for (_i = (int) (1) ; (step875 > 0 && _i <= limit875) || (step875 < 0 && _i >= limit875); _i = ((int)(0 + _i + step875)) ) {
 //BA.debugLineNum = 2311;BA.debugLine="For j = 1 To 7";
{
final int step876 = 1;
final int limit876 = (int) (7);
for (_j = (int) (1) ; (step876 > 0 && _j <= limit876) || (step876 < 0 && _j >= limit876); _j = ((int)(0 + _j + step876)) ) {
 //BA.debugLineNum = 2312;BA.debugLine="apx(teller) = co_x(i)";
_apx[_teller] = _co_x[_i];
 //BA.debugLineNum = 2313;BA.debugLine="apy(teller) = co_y(j)";
_apy[_teller] = _co_y[_j];
 //BA.debugLineNum = 2314;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 }
};
 }
};
 //BA.debugLineNum = 2319;BA.debugLine="Dim first As Int";
_first = 0;
 //BA.debugLineNum = 2320;BA.debugLine="first = 6    'this is always the first x or y coor";
_first = (int) (6);
 //BA.debugLineNum = 2325;BA.debugLine="flag = 0";
_flag = (int) (0);
 //BA.debugLineNum = 2326;BA.debugLine="For i = 1 To 49";
{
final int step885 = 1;
final int limit885 = (int) (49);
for (_i = (int) (1) ; (step885 > 0 && _i <= limit885) || (step885 < 0 && _i >= limit885); _i = ((int)(0 + _i + step885)) ) {
 //BA.debugLineNum = 2327;BA.debugLine="teller = 1";
_teller = (int) (1);
 //BA.debugLineNum = 2328;BA.debugLine="If apx(i) = 0 OR apy(i) = 0 Then flag = 1";
if ((_apx[_i]).equals(BA.NumberToString(0)) || (_apy[_i]).equals(BA.NumberToString(0))) { 
_flag = (int) (1);};
 //BA.debugLineNum = 2329;BA.debugLine="If apx(i) = first AND apy(i) = first Then flag =";
if ((_apx[_i]).equals(BA.NumberToString(_first)) && (_apy[_i]).equals(BA.NumberToString(_first))) { 
_flag = (int) (1);};
 //BA.debugLineNum = 2330;BA.debugLine="If apx(i) = first AND apy(i) = last Then flag =";
if ((_apx[_i]).equals(BA.NumberToString(_first)) && (_apy[_i]).equals(BA.NumberToString(_last))) { 
_flag = (int) (1);};
 //BA.debugLineNum = 2331;BA.debugLine="If apx(i) = last AND apy(i) = first Then flag =";
if ((_apx[_i]).equals(BA.NumberToString(_last)) && (_apy[_i]).equals(BA.NumberToString(_first))) { 
_flag = (int) (1);};
 //BA.debugLineNum = 2332;BA.debugLine="If flag = 0 Then";
if (_flag==0) { 
 //BA.debugLineNum = 2333;BA.debugLine="For k = apx(i) To apx(i) + 4";
{
final int step892 = 1;
final int limit892 = (int) ((double)(Double.parseDouble(_apx[_i]))+4);
for (_k = (int)(Double.parseDouble(_apx[_i])) ; (step892 > 0 && _k <= limit892) || (step892 < 0 && _k >= limit892); _k = ((int)(0 + _k + step892)) ) {
 //BA.debugLineNum = 2334;BA.debugLine="For l = apy(i) To apy(i) + 4";
{
final int step893 = 1;
final int limit893 = (int) ((double)(Double.parseDouble(_apy[_i]))+4);
for (_l = (int)(Double.parseDouble(_apy[_i])) ; (step893 > 0 && _l <= limit893) || (step893 < 0 && _l >= limit893); _l = ((int)(0 + _l + step893)) ) {
 //BA.debugLineNum = 2335;BA.debugLine="If ap(teller - 1) = 1 Then";
if (_ap[(int) (_teller-1)]==1) { 
 //BA.debugLineNum = 2336;BA.debugLine="s5cij(k-1, l-1) = 10";
_s5cij[(int) (_k-1)][(int) (_l-1)] = (int) (10);
 //BA.debugLineNum = 2337;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 }else {
 //BA.debugLineNum = 2339;BA.debugLine="s5cij(k-1, l-1) = 9";
_s5cij[(int) (_k-1)][(int) (_l-1)] = (int) (9);
 //BA.debugLineNum = 2340;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 };
 }
};
 }
};
 }else {
 //BA.debugLineNum = 2345;BA.debugLine="flag = 0";
_flag = (int) (0);
 };
 }
};
 //BA.debugLineNum = 2349;BA.debugLine="teken1";
_teken1(_ba);
 //BA.debugLineNum = 2351;BA.debugLine="End Sub";
return "";
}
public static int  _draw_qr_code(anywheresoftware.b4a.BA _ba,String _message,String _err_lvl,int _mask,int _bc,int _fc,String _shape) throws Exception{
String _qrstring = "";
int _len_dat = 0;
String _rev_len_dat_bin = "";
String _len_dat_bin = "";
int _a1 = 0;
int _b1 = 0;
int _c1 = 0;
int _i = 0;
String _char_to_convert = "";
int _waarde = 0;
String _getal = "";
int _last_flag = 0;
int _teller = 0;
int[][] _data_block = null;
int _j = 0;
int[][] _ecc_block = null;
int _begin = 0;
int _einde = 0;
int _vlag = 0;
int _dec_answer = 0;
String _string_to_convert = "";
String _d = "";
String _dnew = "";
 //BA.debugLineNum = 105;BA.debugLine="Public Sub Draw_QR_Code(message As String, err_lvl";
 //BA.debugLineNum = 108;BA.debugLine="Dim QRSTRING As String";
_qrstring = "";
 //BA.debugLineNum = 109;BA.debugLine="Dim len_dat As Int";
_len_dat = 0;
 //BA.debugLineNum = 110;BA.debugLine="Dim rev_len_dat_bin As String";
_rev_len_dat_bin = "";
 //BA.debugLineNum = 111;BA.debugLine="Dim len_dat_bin As String";
_len_dat_bin = "";
 //BA.debugLineNum = 112;BA.debugLine="bcolor = bc";
_bcolor = _bc;
 //BA.debugLineNum = 113;BA.debugLine="fcolor = fc";
_fcolor = _fc;
 //BA.debugLineNum = 114;BA.debugLine="sf.Initialize";
_sf._initialize((_ba.processBA == null ? _ba : _ba.processBA));
 //BA.debugLineNum = 116;BA.debugLine="shp = shape";
_shp = _shape;
 //BA.debugLineNum = 117;BA.debugLine="dat = message";
_dat = _message;
 //BA.debugLineNum = 119;BA.debugLine="error_level = err_lvl";
_error_level = _err_lvl;
 //BA.debugLineNum = 120;BA.debugLine="tipe = \"8-bit-Byte\"";
_tipe = "8-bit-Byte";
 //BA.debugLineNum = 121;BA.debugLine="maskp = mask";
_maskp = _mask;
 //BA.debugLineNum = 124;BA.debugLine="ECC_woord = \"\"";
_ecc_woord = "";
 //BA.debugLineNum = 126;BA.debugLine="determine_max_len";
_determine_max_len(_ba);
 //BA.debugLineNum = 128;BA.debugLine="select_block";
_select_block(_ba);
 //BA.debugLineNum = 130;BA.debugLine="QRSTRING = \"\"";
_qrstring = "";
 //BA.debugLineNum = 132;BA.debugLine="Select Case tipe              'get the correct mod";
switch (BA.switchObjectToInt(_tipe,"Numeric","Alphanumeric","8-bit-Byte")) {
case 0: {
 //BA.debugLineNum = 134;BA.debugLine="QRSTRING = \"0001\"";
_qrstring = "0001";
 break; }
case 1: {
 //BA.debugLineNum = 136;BA.debugLine="QRSTRING = \"0010\"";
_qrstring = "0010";
 break; }
case 2: {
 //BA.debugLineNum = 138;BA.debugLine="QRSTRING = \"0100\"";
_qrstring = "0100";
 break; }
}
;
 //BA.debugLineNum = 141;BA.debugLine="Generate_log_antilog";
_generate_log_antilog(_ba);
 //BA.debugLineNum = 144;BA.debugLine="If sf.Len(dat) > maxlen Then   'only encode the ma";
if (_sf._vvv7(_dat)>_maxlen) { 
 //BA.debugLineNum = 145;BA.debugLine="dat = sf.Left(dat, maxlen)";
_dat = _sf._vvv6(_dat,(long) (_maxlen));
 };
 //BA.debugLineNum = 148;BA.debugLine="len_dat = sf.Len(dat)";
_len_dat = (int) (_sf._vvv7(_dat));
 //BA.debugLineNum = 149;BA.debugLine="rev_len_dat_bin = \"\"       'this will hold a binar";
_rev_len_dat_bin = "";
 //BA.debugLineNum = 151;BA.debugLine="Dim a1 As Int";
_a1 = 0;
 //BA.debugLineNum = 152;BA.debugLine="Dim b1 As Int";
_b1 = 0;
 //BA.debugLineNum = 153;BA.debugLine="Dim c1 As Int";
_c1 = 0;
 //BA.debugLineNum = 155;BA.debugLine="a1 = len_dat    'get the binary string for the len";
_a1 = _len_dat;
 //BA.debugLineNum = 157;BA.debugLine="Do While a1 <> 0";
while (_a1!=0) {
 //BA.debugLineNum = 158;BA.debugLine="b1 = Floor(a1 / 2)";
_b1 = (int) (anywheresoftware.b4a.keywords.Common.Floor(_a1/(double)2));
 //BA.debugLineNum = 159;BA.debugLine="c1 = a1 - (b1 * 2)";
_c1 = (int) (_a1-(_b1*2));
 //BA.debugLineNum = 160;BA.debugLine="If c1 = 1 Then rev_len_dat_bin = rev_len_dat_bin";
if (_c1==1) { 
_rev_len_dat_bin = _rev_len_dat_bin+"1";};
 //BA.debugLineNum = 161;BA.debugLine="If c1 = 0 Then rev_len_dat_bin = rev_len_dat_bin";
if (_c1==0) { 
_rev_len_dat_bin = _rev_len_dat_bin+"0";};
 //BA.debugLineNum = 162;BA.debugLine="a1 = b1";
_a1 = _b1;
 }
;
 //BA.debugLineNum = 165;BA.debugLine="len_dat_bin = \"\"     'now reverse the sting that i";
_len_dat_bin = "";
 //BA.debugLineNum = 166;BA.debugLine="For i = 1 To sf.Len(rev_len_dat_bin)";
{
final int step43 = 1;
final int limit43 = (int) (_sf._vvv7(_rev_len_dat_bin));
for (_i = (int) (1) ; (step43 > 0 && _i <= limit43) || (step43 < 0 && _i >= limit43); _i = ((int)(0 + _i + step43)) ) {
 //BA.debugLineNum = 167;BA.debugLine="len_dat_bin = sf.Mid(rev_len_dat_bin, i, 1) & le";
_len_dat_bin = _sf._vvvv5(_rev_len_dat_bin,_i,(int) (1))+_len_dat_bin;
 }
};
 //BA.debugLineNum = 170;BA.debugLine="rev_len_dat_bin = sf.Trim(rev_len_dat_bin)";
_rev_len_dat_bin = _sf._vvvvvvv4(_rev_len_dat_bin);
 //BA.debugLineNum = 171;BA.debugLine="len_dat_bin = sf.Trim(len_dat_bin)";
_len_dat_bin = _sf._vvvvvvv4(_len_dat_bin);
 //BA.debugLineNum = 173;BA.debugLine="If tipe = \"8-bit-Byte\" Then";
if ((_tipe).equals("8-bit-Byte")) { 
 //BA.debugLineNum = 174;BA.debugLine="If version_no >= 1 And version_no <= 9 Then  '";
if (_version_no>=1 && _version_no<=9) { 
 //BA.debugLineNum = 175;BA.debugLine="If sf.Len(len_dat_bin) < 8 Then";
if (_sf._vvv7(_len_dat_bin)<8) { 
 //BA.debugLineNum = 176;BA.debugLine="Do While sf.Len(len_dat_bin) < 8";
while (_sf._vvv7(_len_dat_bin)<8) {
 //BA.debugLineNum = 177;BA.debugLine="len_dat_bin = \"0\" & len_dat_bin    'ad";
_len_dat_bin = "0"+_len_dat_bin;
 }
;
 };
 }else if(_version_no>9) { 
 //BA.debugLineNum = 181;BA.debugLine="If sf.Len(len_dat_bin) < 16 Then";
if (_sf._vvv7(_len_dat_bin)<16) { 
 //BA.debugLineNum = 182;BA.debugLine="Do While sf.Len(len_dat_bin) < 16";
while (_sf._vvv7(_len_dat_bin)<16) {
 //BA.debugLineNum = 183;BA.debugLine="len_dat_bin = \"0\" & len_dat_bin   'add";
_len_dat_bin = "0"+_len_dat_bin;
 }
;
 };
 };
 }else if((_tipe).equals("Numeric")) { 
 //BA.debugLineNum = 188;BA.debugLine="If version_no >= 1 And version_no <= 9 Then  '";
if (_version_no>=1 && _version_no<=9) { 
 //BA.debugLineNum = 189;BA.debugLine="If sf.Len(len_dat_bin) < 10 Then";
if (_sf._vvv7(_len_dat_bin)<10) { 
 //BA.debugLineNum = 190;BA.debugLine="Do While sf.Len(len_dat_bin) < 10";
while (_sf._vvv7(_len_dat_bin)<10) {
 //BA.debugLineNum = 191;BA.debugLine="len_dat_bin = \"0\" & len_dat_bin  'add";
_len_dat_bin = "0"+_len_dat_bin;
 }
;
 };
 }else if(_version_no>=10 && _version_no<=26) { 
 //BA.debugLineNum = 195;BA.debugLine="If sf.Len(len_dat_bin) < 12 Then";
if (_sf._vvv7(_len_dat_bin)<12) { 
 //BA.debugLineNum = 196;BA.debugLine="Do While sf.Len(len_dat_bin) < 12";
while (_sf._vvv7(_len_dat_bin)<12) {
 //BA.debugLineNum = 197;BA.debugLine="len_dat_bin = \"0\" & len_dat_bin   'add";
_len_dat_bin = "0"+_len_dat_bin;
 }
;
 };
 }else if(_version_no>26) { 
 //BA.debugLineNum = 201;BA.debugLine="If sf.Len(len_dat_bin) < 14 Then";
if (_sf._vvv7(_len_dat_bin)<14) { 
 //BA.debugLineNum = 202;BA.debugLine="Do While sf.Len(len_dat_bin) < 14";
while (_sf._vvv7(_len_dat_bin)<14) {
 //BA.debugLineNum = 203;BA.debugLine="len_dat_bin = \"0\" & len_dat_bin 'add a";
_len_dat_bin = "0"+_len_dat_bin;
 }
;
 };
 };
 }else if((_tipe).equals("Alphanumeric")) { 
 //BA.debugLineNum = 208;BA.debugLine="If version_no >= 1 And version_no <= 9 Then  '";
if (_version_no>=1 && _version_no<=9) { 
 //BA.debugLineNum = 209;BA.debugLine="If sf.Len(len_dat_bin) < 9 Then";
if (_sf._vvv7(_len_dat_bin)<9) { 
 //BA.debugLineNum = 210;BA.debugLine="Do While sf.Len(len_dat_bin) < 9";
while (_sf._vvv7(_len_dat_bin)<9) {
 //BA.debugLineNum = 211;BA.debugLine="len_dat_bin = \"0\" & len_dat_bin 'add a";
_len_dat_bin = "0"+_len_dat_bin;
 }
;
 };
 }else if(_version_no>9 && _version_no<27) { 
 //BA.debugLineNum = 215;BA.debugLine="If sf.Len(len_dat_bin) < 11 Then";
if (_sf._vvv7(_len_dat_bin)<11) { 
 //BA.debugLineNum = 216;BA.debugLine="Do While sf.Len(len_dat_bin) < 11";
while (_sf._vvv7(_len_dat_bin)<11) {
 //BA.debugLineNum = 217;BA.debugLine="len_dat_bin = \"0\" & len_dat_bin 'add a";
_len_dat_bin = "0"+_len_dat_bin;
 }
;
 };
 }else if(_version_no>26) { 
 //BA.debugLineNum = 221;BA.debugLine="If sf.Len(len_dat_bin) < 13 Then";
if (_sf._vvv7(_len_dat_bin)<13) { 
 //BA.debugLineNum = 222;BA.debugLine="Do While sf.Len(len_dat_bin) < 13";
while (_sf._vvv7(_len_dat_bin)<13) {
 //BA.debugLineNum = 223;BA.debugLine="len_dat_bin = \"0\" & len_dat_bin 'add a";
_len_dat_bin = "0"+_len_dat_bin;
 }
;
 };
 };
 };
 //BA.debugLineNum = 229;BA.debugLine="QRSTRING = QRSTRING & len_dat_bin 'data type numbe";
_qrstring = _qrstring+_len_dat_bin;
 //BA.debugLineNum = 231;BA.debugLine="Dim char_to_convert As String";
_char_to_convert = "";
 //BA.debugLineNum = 232;BA.debugLine="Dim waarde As Int";
_waarde = 0;
 //BA.debugLineNum = 233;BA.debugLine="Dim getal As String";
_getal = "";
 //BA.debugLineNum = 235;BA.debugLine="If tipe = \"8-bit-Byte\" Then";
if ((_tipe).equals("8-bit-Byte")) { 
 //BA.debugLineNum = 236;BA.debugLine="For i = 1 To len_dat";
{
final int step108 = 1;
final int limit108 = _len_dat;
for (_i = (int) (1) ; (step108 > 0 && _i <= limit108) || (step108 < 0 && _i >= limit108); _i = ((int)(0 + _i + step108)) ) {
 //BA.debugLineNum = 237;BA.debugLine="char_to_convert = sf.Mid(dat, i, 1)   'get eac";
_char_to_convert = _sf._vvvv5(_dat,_i,(int) (1));
 //BA.debugLineNum = 238;BA.debugLine="waarde = conv(char_to_convert)       'get the";
_waarde = _conv(_ba,_char_to_convert);
 //BA.debugLineNum = 239;BA.debugLine="z(i) = waarde                         'store t";
_z[_i] = BA.NumberToString(_waarde);
 }
};
 //BA.debugLineNum = 241;BA.debugLine="For i = 1 To len_dat";
{
final int step113 = 1;
final int limit113 = _len_dat;
for (_i = (int) (1) ; (step113 > 0 && _i <= limit113) || (step113 < 0 && _i >= limit113); _i = ((int)(0 + _i + step113)) ) {
 //BA.debugLineNum = 242;BA.debugLine="getal = convert_to_binary(z(i))     'convert e";
_getal = _convert_to_binary(_ba,_z[_i]);
 //BA.debugLineNum = 243;BA.debugLine="If sf.Len(getal) < 8 Then            'and then";
if (_sf._vvv7(_getal)<8) { 
 //BA.debugLineNum = 244;BA.debugLine="Do While sf.Len(getal) < 8";
while (_sf._vvv7(_getal)<8) {
 //BA.debugLineNum = 245;BA.debugLine="getal = \"0\" & getal";
_getal = "0"+_getal;
 }
;
 };
 //BA.debugLineNum = 249;BA.debugLine="QRSTRING = QRSTRING & sf.Trim(getal)";
_qrstring = _qrstring+_sf._vvvvvvv4(_getal);
 }
};
 };
 //BA.debugLineNum = 253;BA.debugLine="If tipe = \"Alphanumeric\" Then";
if ((_tipe).equals("Alphanumeric")) { 
 //BA.debugLineNum = 254;BA.debugLine="a1 = Floor(len_dat / 2)";
_a1 = (int) (anywheresoftware.b4a.keywords.Common.Floor(_len_dat/(double)2));
 //BA.debugLineNum = 255;BA.debugLine="b1 = a1 * 2";
_b1 = (int) (_a1*2);
 //BA.debugLineNum = 257;BA.debugLine="For i = 1 To len_dat";
{
final int step126 = 1;
final int limit126 = _len_dat;
for (_i = (int) (1) ; (step126 > 0 && _i <= limit126) || (step126 < 0 && _i >= limit126); _i = ((int)(0 + _i + step126)) ) {
 //BA.debugLineNum = 258;BA.debugLine="char_to_convert = sf.Mid(dat, i, 1)";
_char_to_convert = _sf._vvvv5(_dat,_i,(int) (1));
 //BA.debugLineNum = 259;BA.debugLine="waarde = anconv(char_to_convert)";
_waarde = _anconv(_ba,_char_to_convert);
 //BA.debugLineNum = 260;BA.debugLine="z(i) = waarde";
_z[_i] = BA.NumberToString(_waarde);
 }
};
 //BA.debugLineNum = 263;BA.debugLine="If len_dat - b1 = 1 Then                  'une";
if (_len_dat-_b1==1) { 
 //BA.debugLineNum = 264;BA.debugLine="For i = 1 To len_dat - 1 Step 2";
{
final int step132 = (int) (2);
final int limit132 = (int) (_len_dat-1);
for (_i = (int) (1) ; (step132 > 0 && _i <= limit132) || (step132 < 0 && _i >= limit132); _i = ((int)(0 + _i + step132)) ) {
 //BA.debugLineNum = 265;BA.debugLine="waarde = (z(i) * 45) + z(i + 1)";
_waarde = (int) (((double)(Double.parseDouble(_z[_i]))*45)+(double)(Double.parseDouble(_z[(int) (_i+1)])));
 //BA.debugLineNum = 266;BA.debugLine="getal = convert_to_binary(waarde)";
_getal = _convert_to_binary(_ba,BA.NumberToString(_waarde));
 //BA.debugLineNum = 267;BA.debugLine="If sf.Len(getal) < 11 Then";
if (_sf._vvv7(_getal)<11) { 
 //BA.debugLineNum = 268;BA.debugLine="Do While sf.Len(getal) < 11";
while (_sf._vvv7(_getal)<11) {
 //BA.debugLineNum = 269;BA.debugLine="getal = \"0\" & getal";
_getal = "0"+_getal;
 }
;
 };
 //BA.debugLineNum = 272;BA.debugLine="QRSTRING = QRSTRING & sf.Trim(getal)";
_qrstring = _qrstring+_sf._vvvvvvv4(_getal);
 }
};
 //BA.debugLineNum = 274;BA.debugLine="waarde = z(len_dat)";
_waarde = (int)(Double.parseDouble(_z[_len_dat]));
 //BA.debugLineNum = 275;BA.debugLine="getal = convert_to_binary(waarde)";
_getal = _convert_to_binary(_ba,BA.NumberToString(_waarde));
 //BA.debugLineNum = 276;BA.debugLine="If sf.Len(getal) < 6 Then               'do";
if (_sf._vvv7(_getal)<6) { 
 //BA.debugLineNum = 277;BA.debugLine="Do While sf.Len(getal) < 6";
while (_sf._vvv7(_getal)<6) {
 //BA.debugLineNum = 278;BA.debugLine="getal = \"0\" & getal";
_getal = "0"+_getal;
 }
;
 };
 //BA.debugLineNum = 281;BA.debugLine="QRSTRING = QRSTRING & sf.Trim(getal)";
_qrstring = _qrstring+_sf._vvvvvvv4(_getal);
 };
 //BA.debugLineNum = 284;BA.debugLine="If len_dat - b1 = 0 Then                  'eve";
if (_len_dat-_b1==0) { 
 //BA.debugLineNum = 285;BA.debugLine="For i = 1 To len_dat - 1 Step 2";
{
final int step152 = (int) (2);
final int limit152 = (int) (_len_dat-1);
for (_i = (int) (1) ; (step152 > 0 && _i <= limit152) || (step152 < 0 && _i >= limit152); _i = ((int)(0 + _i + step152)) ) {
 //BA.debugLineNum = 286;BA.debugLine="waarde = (z(i) * 45) + z(i + 1)";
_waarde = (int) (((double)(Double.parseDouble(_z[_i]))*45)+(double)(Double.parseDouble(_z[(int) (_i+1)])));
 //BA.debugLineNum = 287;BA.debugLine="getal = convert_to_binary(waarde)";
_getal = _convert_to_binary(_ba,BA.NumberToString(_waarde));
 //BA.debugLineNum = 288;BA.debugLine="If sf.Len(getal) < 11 Then";
if (_sf._vvv7(_getal)<11) { 
 //BA.debugLineNum = 289;BA.debugLine="Do While sf.Len(getal) < 11";
while (_sf._vvv7(_getal)<11) {
 //BA.debugLineNum = 290;BA.debugLine="getal = \"0\" & getal";
_getal = "0"+_getal;
 }
;
 };
 //BA.debugLineNum = 293;BA.debugLine="QRSTRING = QRSTRING & sf.Trim(getal)";
_qrstring = _qrstring+_sf._vvvvvvv4(_getal);
 }
};
 };
 };
 //BA.debugLineNum = 298;BA.debugLine="If tipe = \"Numeric\" Then";
if ((_tipe).equals("Numeric")) { 
 //BA.debugLineNum = 300;BA.debugLine="a1 = Floor(len_dat / 3 )";
_a1 = (int) (anywheresoftware.b4a.keywords.Common.Floor(_len_dat/(double)3));
 //BA.debugLineNum = 301;BA.debugLine="b1 = a1 * 3                               'how";
_b1 = (int) (_a1*3);
 //BA.debugLineNum = 303;BA.debugLine="If len_dat - b1 = 2 Then                  'rem";
if (_len_dat-_b1==2) { 
 //BA.debugLineNum = 304;BA.debugLine="For i = 1 To len_dat - 2 Step 3";
{
final int step168 = (int) (3);
final int limit168 = (int) (_len_dat-2);
for (_i = (int) (1) ; (step168 > 0 && _i <= limit168) || (step168 < 0 && _i >= limit168); _i = ((int)(0 + _i + step168)) ) {
 //BA.debugLineNum = 305;BA.debugLine="waarde = sf.Val(sf.Mid(dat, i, 3))";
_waarde = (int) (_sf._vvvvvvv6(_sf._vvvv5(_dat,_i,(int) (3))));
 //BA.debugLineNum = 306;BA.debugLine="getal = convert_to_binary(waarde)";
_getal = _convert_to_binary(_ba,BA.NumberToString(_waarde));
 //BA.debugLineNum = 307;BA.debugLine="If sf.Len(getal) < 10 Then";
if (_sf._vvv7(_getal)<10) { 
 //BA.debugLineNum = 308;BA.debugLine="Do While sf.Len(getal) < 10";
while (_sf._vvv7(_getal)<10) {
 //BA.debugLineNum = 309;BA.debugLine="getal = \"0\" & getal";
_getal = "0"+_getal;
 }
;
 };
 //BA.debugLineNum = 312;BA.debugLine="QRSTRING = QRSTRING & sf.Trim(getal)";
_qrstring = _qrstring+_sf._vvvvvvv4(_getal);
 }
};
 //BA.debugLineNum = 314;BA.debugLine="waarde = sf.Val(sf.Mid(dat, i, 2))";
_waarde = (int) (_sf._vvvvvvv6(_sf._vvvv5(_dat,_i,(int) (2))));
 //BA.debugLineNum = 315;BA.debugLine="getal = convert_to_binary(waarde)";
_getal = _convert_to_binary(_ba,BA.NumberToString(_waarde));
 //BA.debugLineNum = 316;BA.debugLine="If sf.Len(getal) < 7 Then               '2";
if (_sf._vvv7(_getal)<7) { 
 //BA.debugLineNum = 317;BA.debugLine="Do While sf.Len(getal) < 7";
while (_sf._vvv7(_getal)<7) {
 //BA.debugLineNum = 318;BA.debugLine="getal = \"0\" & getal";
_getal = "0"+_getal;
 }
;
 };
 //BA.debugLineNum = 321;BA.debugLine="QRSTRING = QRSTRING & sf.Trim(getal)";
_qrstring = _qrstring+_sf._vvvvvvv4(_getal);
 };
 //BA.debugLineNum = 325;BA.debugLine="If len_dat - b1 = 1 Then                  'rem";
if (_len_dat-_b1==1) { 
 //BA.debugLineNum = 326;BA.debugLine="For i = 1 To len_dat - 1 Step 3";
{
final int step188 = (int) (3);
final int limit188 = (int) (_len_dat-1);
for (_i = (int) (1) ; (step188 > 0 && _i <= limit188) || (step188 < 0 && _i >= limit188); _i = ((int)(0 + _i + step188)) ) {
 //BA.debugLineNum = 327;BA.debugLine="waarde = sf.Val(sf.Mid(dat, i, 3))";
_waarde = (int) (_sf._vvvvvvv6(_sf._vvvv5(_dat,_i,(int) (3))));
 //BA.debugLineNum = 328;BA.debugLine="getal = convert_to_binary(waarde)";
_getal = _convert_to_binary(_ba,BA.NumberToString(_waarde));
 //BA.debugLineNum = 329;BA.debugLine="If sf.Len(getal) < 10 Then";
if (_sf._vvv7(_getal)<10) { 
 //BA.debugLineNum = 330;BA.debugLine="Do While sf.Len(getal) < 10";
while (_sf._vvv7(_getal)<10) {
 //BA.debugLineNum = 331;BA.debugLine="getal = \"0\" & getal";
_getal = "0"+_getal;
 }
;
 };
 //BA.debugLineNum = 334;BA.debugLine="QRSTRING = QRSTRING & sf.Trim(getal)";
_qrstring = _qrstring+_sf._vvvvvvv4(_getal);
 }
};
 //BA.debugLineNum = 336;BA.debugLine="waarde = sf.Val(sf.Mid(dat, i, 1))";
_waarde = (int) (_sf._vvvvvvv6(_sf._vvvv5(_dat,_i,(int) (1))));
 //BA.debugLineNum = 337;BA.debugLine="getal = convert_to_binary(waarde)";
_getal = _convert_to_binary(_ba,BA.NumberToString(_waarde));
 //BA.debugLineNum = 338;BA.debugLine="If sf.Len(getal) < 4 Then               'on";
if (_sf._vvv7(_getal)<4) { 
 //BA.debugLineNum = 339;BA.debugLine="Do While sf.Len(getal) < 4";
while (_sf._vvv7(_getal)<4) {
 //BA.debugLineNum = 340;BA.debugLine="getal = \"0\" & getal";
_getal = "0"+_getal;
 }
;
 };
 //BA.debugLineNum = 343;BA.debugLine="QRSTRING = QRSTRING & sf.Trim(getal)";
_qrstring = _qrstring+_sf._vvvvvvv4(_getal);
 };
 //BA.debugLineNum = 346;BA.debugLine="If len_dat - b1 = 0 Then                  'mul";
if (_len_dat-_b1==0) { 
 //BA.debugLineNum = 347;BA.debugLine="For i = 1 To len_dat Step 3";
{
final int step208 = (int) (3);
final int limit208 = _len_dat;
for (_i = (int) (1) ; (step208 > 0 && _i <= limit208) || (step208 < 0 && _i >= limit208); _i = ((int)(0 + _i + step208)) ) {
 //BA.debugLineNum = 348;BA.debugLine="waarde = sf.Val(sf.Mid(dat, i, 3))";
_waarde = (int) (_sf._vvvvvvv6(_sf._vvvv5(_dat,_i,(int) (3))));
 //BA.debugLineNum = 349;BA.debugLine="getal = convert_to_binary(waarde)";
_getal = _convert_to_binary(_ba,BA.NumberToString(_waarde));
 //BA.debugLineNum = 350;BA.debugLine="If sf.Len(getal) < 10 Then";
if (_sf._vvv7(_getal)<10) { 
 //BA.debugLineNum = 351;BA.debugLine="Do While sf.Len(getal) < 10";
while (_sf._vvv7(_getal)<10) {
 //BA.debugLineNum = 352;BA.debugLine="getal = \"0\" & getal";
_getal = "0"+_getal;
 }
;
 };
 //BA.debugLineNum = 355;BA.debugLine="QRSTRING = QRSTRING & sf.Trim(getal)";
_qrstring = _qrstring+_sf._vvvvvvv4(_getal);
 }
};
 };
 };
 //BA.debugLineNum = 361;BA.debugLine="If sf.Len(QRSTRING) <= max_data_bits - 4 Then";
if (_sf._vvv7(_qrstring)<=_max_data_bits-4) { 
 //BA.debugLineNum = 362;BA.debugLine="QRSTRING = QRSTRING & \"0000\"";
_qrstring = _qrstring+"0000";
 }else {
 //BA.debugLineNum = 364;BA.debugLine="Do While sf.Len(QRSTRING) < max_data_bits";
while (_sf._vvv7(_qrstring)<_max_data_bits) {
 //BA.debugLineNum = 365;BA.debugLine="QRSTRING = QRSTRING & \"0\"";
_qrstring = _qrstring+"0";
 }
;
 };
 //BA.debugLineNum = 371;BA.debugLine="a1 = sf.Len(QRSTRING)";
_a1 = (int) (_sf._vvv7(_qrstring));
 //BA.debugLineNum = 372;BA.debugLine="b1 = a1 Mod 8         'check if the sting is multi";
_b1 = (int) (_a1%8);
 //BA.debugLineNum = 374;BA.debugLine="If b1 <> 0 Then";
if (_b1!=0) { 
 //BA.debugLineNum = 375;BA.debugLine="Do While sf.Len(QRSTRING) Mod 8 <> 0";
while (_sf._vvv7(_qrstring)%8!=0) {
 //BA.debugLineNum = 376;BA.debugLine="QRSTRING = QRSTRING & \"0\"         'if not, then";
_qrstring = _qrstring+"0";
 }
;
 };
 //BA.debugLineNum = 380;BA.debugLine="Dim last_flag As Int";
_last_flag = 0;
 //BA.debugLineNum = 381;BA.debugLine="last_flag = 0";
_last_flag = (int) (0);
 //BA.debugLineNum = 382;BA.debugLine="If sf.Len(QRSTRING) < max_data_bits Then";
if (_sf._vvv7(_qrstring)<_max_data_bits) { 
 //BA.debugLineNum = 383;BA.debugLine="Do While sf.Len(QRSTRING) <> max_data_bits";
while (_sf._vvv7(_qrstring)!=_max_data_bits) {
 //BA.debugLineNum = 384;BA.debugLine="If last_flag = 0 Then";
if (_last_flag==0) { 
 //BA.debugLineNum = 385;BA.debugLine="QRSTRING = QRSTRING & \"11101100\"    'pad the";
_qrstring = _qrstring+"11101100";
 //BA.debugLineNum = 386;BA.debugLine="last_flag = 1";
_last_flag = (int) (1);
 }else {
 //BA.debugLineNum = 388;BA.debugLine="QRSTRING = QRSTRING & \"00010001\"     '....and";
_qrstring = _qrstring+"00010001";
 //BA.debugLineNum = 389;BA.debugLine="last_flag = 0";
_last_flag = (int) (0);
 };
 }
;
 };
 //BA.debugLineNum = 394;BA.debugLine="Dim teller As Int";
_teller = 0;
 //BA.debugLineNum = 396;BA.debugLine="If dw2 <> 0 Then";
if (_dw2!=0) { 
 //BA.debugLineNum = 397;BA.debugLine="Dim data_block(block1 + block2 + 1, dw2 + 1) As";
_data_block = new int[(int) (_block1+_block2+1)][];
{
int d0 = _data_block.length;
int d1 = (int) (_dw2+1);
for (int i0 = 0;i0 < d0;i0++) {
_data_block[i0] = new int[d1];
}
}
;
 //BA.debugLineNum = 398;BA.debugLine="For j = 1 To dw2";
{
final int step250 = 1;
final int limit250 = _dw2;
for (_j = (int) (1) ; (step250 > 0 && _j <= limit250) || (step250 < 0 && _j >= limit250); _j = ((int)(0 + _j + step250)) ) {
 //BA.debugLineNum = 399;BA.debugLine="For i = 1 To block1 + block2";
{
final int step251 = 1;
final int limit251 = (int) (_block1+_block2);
for (_i = (int) (1) ; (step251 > 0 && _i <= limit251) || (step251 < 0 && _i >= limit251); _i = ((int)(0 + _i + step251)) ) {
 //BA.debugLineNum = 400;BA.debugLine="data_block(i, j) = 0              'load the";
_data_block[_i][_j] = (int) (0);
 }
};
 }
};
 //BA.debugLineNum = 403;BA.debugLine="teller = 1";
_teller = (int) (1);
 //BA.debugLineNum = 404;BA.debugLine="For i = 1 To block1                     'load th";
{
final int step256 = 1;
final int limit256 = _block1;
for (_i = (int) (1) ; (step256 > 0 && _i <= limit256) || (step256 < 0 && _i >= limit256); _i = ((int)(0 + _i + step256)) ) {
 //BA.debugLineNum = 405;BA.debugLine="For j = 1 To dw1";
{
final int step257 = 1;
final int limit257 = _dw1;
for (_j = (int) (1) ; (step257 > 0 && _j <= limit257) || (step257 < 0 && _j >= limit257); _j = ((int)(0 + _j + step257)) ) {
 //BA.debugLineNum = 406;BA.debugLine="data_block(i, j) = teller";
_data_block[_i][_j] = _teller;
 //BA.debugLineNum = 407;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 }
};
 }
};
 //BA.debugLineNum = 410;BA.debugLine="For i = block1 + 1 To block1 + block2";
{
final int step262 = 1;
final int limit262 = (int) (_block1+_block2);
for (_i = (int) (_block1+1) ; (step262 > 0 && _i <= limit262) || (step262 < 0 && _i >= limit262); _i = ((int)(0 + _i + step262)) ) {
 //BA.debugLineNum = 411;BA.debugLine="For j = 1 To dw2";
{
final int step263 = 1;
final int limit263 = _dw2;
for (_j = (int) (1) ; (step263 > 0 && _j <= limit263) || (step263 < 0 && _j >= limit263); _j = ((int)(0 + _j + step263)) ) {
 //BA.debugLineNum = 412;BA.debugLine="data_block(i, j) = teller";
_data_block[_i][_j] = _teller;
 //BA.debugLineNum = 413;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 }
};
 }
};
 }else {
 //BA.debugLineNum = 417;BA.debugLine="Dim data_block(block1 + block2 + 1 , dw1 + 1) As";
_data_block = new int[(int) (_block1+_block2+1)][];
{
int d0 = _data_block.length;
int d1 = (int) (_dw1+1);
for (int i0 = 0;i0 < d0;i0++) {
_data_block[i0] = new int[d1];
}
}
;
 //BA.debugLineNum = 418;BA.debugLine="For j = 1 To dw1";
{
final int step270 = 1;
final int limit270 = _dw1;
for (_j = (int) (1) ; (step270 > 0 && _j <= limit270) || (step270 < 0 && _j >= limit270); _j = ((int)(0 + _j + step270)) ) {
 //BA.debugLineNum = 419;BA.debugLine="For i = 1 To block1";
{
final int step271 = 1;
final int limit271 = _block1;
for (_i = (int) (1) ; (step271 > 0 && _i <= limit271) || (step271 < 0 && _i >= limit271); _i = ((int)(0 + _i + step271)) ) {
 //BA.debugLineNum = 420;BA.debugLine="data_block(i, j) = 0              'load the";
_data_block[_i][_j] = (int) (0);
 }
};
 }
};
 //BA.debugLineNum = 423;BA.debugLine="teller = 1";
_teller = (int) (1);
 //BA.debugLineNum = 424;BA.debugLine="For i = 1 To block1                      'load t";
{
final int step276 = 1;
final int limit276 = _block1;
for (_i = (int) (1) ; (step276 > 0 && _i <= limit276) || (step276 < 0 && _i >= limit276); _i = ((int)(0 + _i + step276)) ) {
 //BA.debugLineNum = 425;BA.debugLine="For j = 1 To dw1";
{
final int step277 = 1;
final int limit277 = _dw1;
for (_j = (int) (1) ; (step277 > 0 && _j <= limit277) || (step277 < 0 && _j >= limit277); _j = ((int)(0 + _j + step277)) ) {
 //BA.debugLineNum = 426;BA.debugLine="data_block(i, j) = teller";
_data_block[_i][_j] = _teller;
 //BA.debugLineNum = 427;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 }
};
 }
};
 };
 //BA.debugLineNum = 432;BA.debugLine="Dim ecc_block(block1 + block2 + 1, ew1 + 1) As Int";
_ecc_block = new int[(int) (_block1+_block2+1)][];
{
int d0 = _ecc_block.length;
int d1 = (int) (_ew1+1);
for (int i0 = 0;i0 < d0;i0++) {
_ecc_block[i0] = new int[d1];
}
}
;
 //BA.debugLineNum = 433;BA.debugLine="For j = 1 To ew1";
{
final int step284 = 1;
final int limit284 = _ew1;
for (_j = (int) (1) ; (step284 > 0 && _j <= limit284) || (step284 < 0 && _j >= limit284); _j = ((int)(0 + _j + step284)) ) {
 //BA.debugLineNum = 434;BA.debugLine="For i = 1 To block1 + block2";
{
final int step285 = 1;
final int limit285 = (int) (_block1+_block2);
for (_i = (int) (1) ; (step285 > 0 && _i <= limit285) || (step285 < 0 && _i >= limit285); _i = ((int)(0 + _i + step285)) ) {
 //BA.debugLineNum = 435;BA.debugLine="ecc_block(i, j) = 0              'load the arr";
_ecc_block[_i][_j] = (int) (0);
 }
};
 }
};
 //BA.debugLineNum = 439;BA.debugLine="teller = 1";
_teller = (int) (1);
 //BA.debugLineNum = 440;BA.debugLine="For i = 1 To block1 + block2";
{
final int step290 = 1;
final int limit290 = (int) (_block1+_block2);
for (_i = (int) (1) ; (step290 > 0 && _i <= limit290) || (step290 < 0 && _i >= limit290); _i = ((int)(0 + _i + step290)) ) {
 //BA.debugLineNum = 441;BA.debugLine="For j = 1 To ew1";
{
final int step291 = 1;
final int limit291 = _ew1;
for (_j = (int) (1) ; (step291 > 0 && _j <= limit291) || (step291 < 0 && _j >= limit291); _j = ((int)(0 + _j + step291)) ) {
 //BA.debugLineNum = 442;BA.debugLine="ecc_block(i, j) = teller";
_ecc_block[_i][_j] = _teller;
 //BA.debugLineNum = 443;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 }
};
 }
};
 //BA.debugLineNum = 447;BA.debugLine="Dim begin,einde,vlag,dec_answer As Int";
_begin = 0;
_einde = 0;
_vlag = 0;
_dec_answer = 0;
 //BA.debugLineNum = 448;BA.debugLine="Dim string_to_convert As String";
_string_to_convert = "";
 //BA.debugLineNum = 450;BA.debugLine="begin = 1";
_begin = (int) (1);
 //BA.debugLineNum = 451;BA.debugLine="einde = dw1 * 8";
_einde = (int) (_dw1*8);
 //BA.debugLineNum = 452;BA.debugLine="vlag = 0";
_vlag = (int) (0);
 //BA.debugLineNum = 453;BA.debugLine="Do While vlag <> block1 + block2";
while (_vlag!=_block1+_block2) {
 //BA.debugLineNum = 454;BA.debugLine="no_of_error_words = ew1";
_no_of_error_words = _ew1;
 //BA.debugLineNum = 455;BA.debugLine="mess_coef_teller = 1";
_mess_coef_teller = (int) (1);
 //BA.debugLineNum = 456;BA.debugLine="If vlag < block1 Then";
if (_vlag<_block1) { 
 //BA.debugLineNum = 457;BA.debugLine="For i = begin To einde Step 8";
{
final int step305 = (int) (8);
final int limit305 = _einde;
for (_i = _begin ; (step305 > 0 && _i <= limit305) || (step305 < 0 && _i >= limit305); _i = ((int)(0 + _i + step305)) ) {
 //BA.debugLineNum = 458;BA.debugLine="string_to_convert = sf.Mid(QRSTRING, i, 8)";
_string_to_convert = _sf._vvvv5(_qrstring,_i,(int) (8));
 //BA.debugLineNum = 459;BA.debugLine="dec_answer = convert_to_decimal(string_to_co";
_dec_answer = _convert_to_decimal(_ba,_string_to_convert);
 //BA.debugLineNum = 460;BA.debugLine="message_coeff(mess_coef_teller) = dec_answer";
_message_coeff[_mess_coef_teller] = _dec_answer;
 //BA.debugLineNum = 461;BA.debugLine="mess_coef_teller = mess_coef_teller + 1";
_mess_coef_teller = (int) (_mess_coef_teller+1);
 }
};
 //BA.debugLineNum = 463;BA.debugLine="begin = einde + 1";
_begin = (int) (_einde+1);
 //BA.debugLineNum = 464;BA.debugLine="If vlag = block1 - 1 Then";
if (_vlag==_block1-1) { 
 //BA.debugLineNum = 465;BA.debugLine="einde = einde + dw2 * 8";
_einde = (int) (_einde+_dw2*8);
 }else {
 //BA.debugLineNum = 467;BA.debugLine="einde = einde + dw1 * 8";
_einde = (int) (_einde+_dw1*8);
 };
 };
 //BA.debugLineNum = 471;BA.debugLine="If vlag >= block1 Then";
if (_vlag>=_block1) { 
 //BA.debugLineNum = 472;BA.debugLine="For i = begin To einde Step 8    'take portion";
{
final int step319 = (int) (8);
final int limit319 = _einde;
for (_i = _begin ; (step319 > 0 && _i <= limit319) || (step319 < 0 && _i >= limit319); _i = ((int)(0 + _i + step319)) ) {
 //BA.debugLineNum = 473;BA.debugLine="string_to_convert = sf.Mid(QRSTRING, i, 8)";
_string_to_convert = _sf._vvvv5(_qrstring,_i,(int) (8));
 //BA.debugLineNum = 474;BA.debugLine="dec_answer = convert_to_decimal(string_to_co";
_dec_answer = _convert_to_decimal(_ba,_string_to_convert);
 //BA.debugLineNum = 475;BA.debugLine="message_coeff(mess_coef_teller) = dec_answer";
_message_coeff[_mess_coef_teller] = _dec_answer;
 //BA.debugLineNum = 476;BA.debugLine="mess_coef_teller = mess_coef_teller + 1";
_mess_coef_teller = (int) (_mess_coef_teller+1);
 }
};
 //BA.debugLineNum = 478;BA.debugLine="begin = einde + 1";
_begin = (int) (_einde+1);
 //BA.debugLineNum = 479;BA.debugLine="einde = einde + dw2 * 8";
_einde = (int) (_einde+_dw2*8);
 };
 //BA.debugLineNum = 482;BA.debugLine="mess_coef_teller = mess_coef_teller - 1";
_mess_coef_teller = (int) (_mess_coef_teller-1);
 //BA.debugLineNum = 484;BA.debugLine="For i = 1 To 196";
{
final int step329 = 1;
final int limit329 = (int) (196);
for (_i = (int) (1) ; (step329 > 0 && _i <= limit329) || (step329 < 0 && _i >= limit329); _i = ((int)(0 + _i + step329)) ) {
 //BA.debugLineNum = 485;BA.debugLine="s4c1(i) = \"\"";
_s4c1[_i] = "";
 }
};
 //BA.debugLineNum = 488;BA.debugLine="For i = 1 To mess_coef_teller";
{
final int step332 = 1;
final int limit332 = _mess_coef_teller;
for (_i = (int) (1) ; (step332 > 0 && _i <= limit332) || (step332 < 0 && _i >= limit332); _i = ((int)(0 + _i + step332)) ) {
 //BA.debugLineNum = 489;BA.debugLine="s4c1(i) = message_coeff(i)";
_s4c1[_i] = BA.NumberToString(_message_coeff[_i]);
 }
};
 //BA.debugLineNum = 492;BA.debugLine="generator_polynomial(no_of_error_words)    'crea";
_generator_polynomial(_ba,_no_of_error_words);
 //BA.debugLineNum = 494;BA.debugLine="q = ECC_words          'calculate the ECC words";
_q = _ecc_words(_ba);
 //BA.debugLineNum = 495;BA.debugLine="vlag = vlag + 1";
_vlag = (int) (_vlag+1);
 }
;
 //BA.debugLineNum = 498;BA.debugLine="a = QRSTRING";
_a = _qrstring;
 //BA.debugLineNum = 499;BA.debugLine="b = q   'first block of error correction words";
_b = _q;
 //BA.debugLineNum = 501;BA.debugLine="anew = \"\"                       'now build a new i";
_anew = "";
 //BA.debugLineNum = 503;BA.debugLine="If dw2 <> 0 Then";
if (_dw2!=0) { 
 //BA.debugLineNum = 504;BA.debugLine="For j = 1 To dw2";
{
final int step343 = 1;
final int limit343 = _dw2;
for (_j = (int) (1) ; (step343 > 0 && _j <= limit343) || (step343 < 0 && _j >= limit343); _j = ((int)(0 + _j + step343)) ) {
 //BA.debugLineNum = 505;BA.debugLine="For i = 1 To block1 + block2";
{
final int step344 = 1;
final int limit344 = (int) (_block1+_block2);
for (_i = (int) (1) ; (step344 > 0 && _i <= limit344) || (step344 < 0 && _i >= limit344); _i = ((int)(0 + _i + step344)) ) {
 //BA.debugLineNum = 506;BA.debugLine="If data_block(i, j) <> 0 Then";
if (_data_block[_i][_j]!=0) { 
 //BA.debugLineNum = 507;BA.debugLine="anew = anew & sf.Mid(a, data_block(i, j) *";
_anew = _anew+_sf._vvvv5(_a,(int) (_data_block[_i][_j]*8-7),(int) (8));
 };
 }
};
 }
};
 };
 //BA.debugLineNum = 513;BA.debugLine="If dw2 = 0 Then";
if (_dw2==0) { 
 //BA.debugLineNum = 514;BA.debugLine="For j = 1 To dw1";
{
final int step352 = 1;
final int limit352 = _dw1;
for (_j = (int) (1) ; (step352 > 0 && _j <= limit352) || (step352 < 0 && _j >= limit352); _j = ((int)(0 + _j + step352)) ) {
 //BA.debugLineNum = 515;BA.debugLine="For i = 1 To block1 + block2";
{
final int step353 = 1;
final int limit353 = (int) (_block1+_block2);
for (_i = (int) (1) ; (step353 > 0 && _i <= limit353) || (step353 < 0 && _i >= limit353); _i = ((int)(0 + _i + step353)) ) {
 //BA.debugLineNum = 516;BA.debugLine="If data_block(i, j) <> 0 Then";
if (_data_block[_i][_j]!=0) { 
 //BA.debugLineNum = 517;BA.debugLine="anew = anew & sf.Mid(a, data_block(i, j) *";
_anew = _anew+_sf._vvvv5(_a,(int) (_data_block[_i][_j]*8-7),(int) (8));
 };
 }
};
 }
};
 };
 //BA.debugLineNum = 525;BA.debugLine="Dim d, dnew As String";
_d = "";
_dnew = "";
 //BA.debugLineNum = 526;BA.debugLine="d = \"\"                           'now do the same";
_d = "";
 //BA.debugLineNum = 527;BA.debugLine="d = b";
_d = _b;
 //BA.debugLineNum = 528;BA.debugLine="dnew = \"\"                        'this will be the";
_dnew = "";
 //BA.debugLineNum = 529;BA.debugLine="For j = 1 To ew1";
{
final int step364 = 1;
final int limit364 = _ew1;
for (_j = (int) (1) ; (step364 > 0 && _j <= limit364) || (step364 < 0 && _j >= limit364); _j = ((int)(0 + _j + step364)) ) {
 //BA.debugLineNum = 530;BA.debugLine="For i = 1 To block1 + block2";
{
final int step365 = 1;
final int limit365 = (int) (_block1+_block2);
for (_i = (int) (1) ; (step365 > 0 && _i <= limit365) || (step365 < 0 && _i >= limit365); _i = ((int)(0 + _i + step365)) ) {
 //BA.debugLineNum = 531;BA.debugLine="If ecc_block(i, j) <> 0 Then";
if (_ecc_block[_i][_j]!=0) { 
 //BA.debugLineNum = 532;BA.debugLine="dnew = dnew & sf.Mid(d, ecc_block(i, j) *";
_dnew = _dnew+_sf._vvvv5(_d,(int) (_ecc_block[_i][_j]*8-7),(int) (8));
 };
 }
};
 }
};
 //BA.debugLineNum = 539;BA.debugLine="anew = anew & dnew       'now build one long strin";
_anew = _anew+_dnew;
 //BA.debugLineNum = 541;BA.debugLine="place_matrix_data";
_place_matrix_data(_ba);
 //BA.debugLineNum = 543;BA.debugLine="Return version_no";
if (true) return _version_no;
 //BA.debugLineNum = 545;BA.debugLine="End Sub";
return 0;
}
public static String  _ecc_words(anywheresoftware.b4a.BA _ba) throws Exception{
int[] _msg_out = null;
int _coef = 0;
int _bollie = 0;
int _i = 0;
int _j = 0;
String _getal = "";
int _getalle = 0;
 //BA.debugLineNum = 1212;BA.debugLine="Private Sub ECC_words                     'sub tha";
 //BA.debugLineNum = 1214;BA.debugLine="Dim msg_out(2956) As Int";
_msg_out = new int[(int) (2956)];
;
 //BA.debugLineNum = 1215;BA.debugLine="Dim coef,bollie As Int";
_coef = 0;
_bollie = 0;
 //BA.debugLineNum = 1217;BA.debugLine="For i =0 To 2955";
{
final int step3 = 1;
final int limit3 = (int) (2955);
for (_i = (int) (0) ; (step3 > 0 && _i <= limit3) || (step3 < 0 && _i >= limit3); _i = ((int)(0 + _i + step3)) ) {
 //BA.debugLineNum = 1218;BA.debugLine="msg_out(i) = 0";
_msg_out[_i] = (int) (0);
 }
};
 //BA.debugLineNum = 1220;BA.debugLine="For i = 0 To mess_coef_teller - 1";
{
final int step6 = 1;
final int limit6 = (int) (_mess_coef_teller-1);
for (_i = (int) (0) ; (step6 > 0 && _i <= limit6) || (step6 < 0 && _i >= limit6); _i = ((int)(0 + _i + step6)) ) {
 //BA.debugLineNum = 1221;BA.debugLine="msg_out(i) = message_coeff(i + 1)";
_msg_out[_i] = _message_coeff[(int) (_i+1)];
 }
};
 //BA.debugLineNum = 1223;BA.debugLine="For i = 0 To mess_coef_teller - 1";
{
final int step9 = 1;
final int limit9 = (int) (_mess_coef_teller-1);
for (_i = (int) (0) ; (step9 > 0 && _i <= limit9) || (step9 < 0 && _i >= limit9); _i = ((int)(0 + _i + step9)) ) {
 //BA.debugLineNum = 1224;BA.debugLine="coef = msg_out(i)";
_coef = _msg_out[_i];
 //BA.debugLineNum = 1225;BA.debugLine="If coef <> 0 Then";
if (_coef!=0) { 
 //BA.debugLineNum = 1226;BA.debugLine="For j = 0 To no_of_error_words";
{
final int step12 = 1;
final int limit12 = _no_of_error_words;
for (_j = (int) (0) ; (step12 > 0 && _j <= limit12) || (step12 < 0 && _j >= limit12); _j = ((int)(0 + _j + step12)) ) {
 //BA.debugLineNum = 1227;BA.debugLine="gf_mul_result = gf_mul(s4c4(j + 1), coef)";
_gf_mul_result = _gf_mul(_ba,_s4c4[(int) (_j+1)],_coef);
 //BA.debugLineNum = 1228;BA.debugLine="bollie = Bit.Xor(msg_out(i + j), gf_mu";
_bollie = anywheresoftware.b4a.keywords.Common.Bit.Xor(_msg_out[(int) (_i+_j)],_gf_mul_result);
 //BA.debugLineNum = 1229;BA.debugLine="msg_out(i + j) = bollie";
_msg_out[(int) (_i+_j)] = _bollie;
 }
};
 };
 }
};
 //BA.debugLineNum = 1234;BA.debugLine="For i = 0 To mess_coef_teller - 1";
{
final int step19 = 1;
final int limit19 = (int) (_mess_coef_teller-1);
for (_i = (int) (0) ; (step19 > 0 && _i <= limit19) || (step19 < 0 && _i >= limit19); _i = ((int)(0 + _i + step19)) ) {
 //BA.debugLineNum = 1235;BA.debugLine="msg_out(i) = message_coeff(i + 1)";
_msg_out[_i] = _message_coeff[(int) (_i+1)];
 }
};
 //BA.debugLineNum = 1239;BA.debugLine="For i = 1 To no_of_error_words";
{
final int step22 = 1;
final int limit22 = _no_of_error_words;
for (_i = (int) (1) ; (step22 > 0 && _i <= limit22) || (step22 < 0 && _i >= limit22); _i = ((int)(0 + _i + step22)) ) {
 //BA.debugLineNum = 1240;BA.debugLine="s4c24(i) = msg_out(mess_coef_teller - 1 + i)";
_s4c24[_i] = BA.NumberToString(_msg_out[(int) (_mess_coef_teller-1+_i)]);
 }
};
 //BA.debugLineNum = 1243;BA.debugLine="Dim getal As String";
_getal = "";
 //BA.debugLineNum = 1244;BA.debugLine="Dim getalle As Int";
_getalle = 0;
 //BA.debugLineNum = 1245;BA.debugLine="For i = 1 To no_of_error_words";
{
final int step27 = 1;
final int limit27 = _no_of_error_words;
for (_i = (int) (1) ; (step27 > 0 && _i <= limit27) || (step27 < 0 && _i >= limit27); _i = ((int)(0 + _i + step27)) ) {
 //BA.debugLineNum = 1246;BA.debugLine="getalle = s4c24(i)";
_getalle = (int)(Double.parseDouble(_s4c24[_i]));
 //BA.debugLineNum = 1247;BA.debugLine="getal = convert_to_binary(getalle)";
_getal = _convert_to_binary(_ba,BA.NumberToString(_getalle));
 //BA.debugLineNum = 1248;BA.debugLine="Do While sf.Len(getal) < 8";
while (_sf._vvv7(_getal)<8) {
 //BA.debugLineNum = 1249;BA.debugLine="If sf.Len(getal) < 8 Then";
if (_sf._vvv7(_getal)<8) { 
 //BA.debugLineNum = 1250;BA.debugLine="getal = \"0\" & getal";
_getal = "0"+_getal;
 };
 }
;
 //BA.debugLineNum = 1253;BA.debugLine="ECC_woord = ECC_woord & getal";
_ecc_woord = _ecc_woord+_getal;
 //BA.debugLineNum = 1254;BA.debugLine="q = ECC_woord";
_q = _ecc_woord;
 }
};
 //BA.debugLineNum = 1257;BA.debugLine="Return q";
if (true) return _q;
 //BA.debugLineNum = 1259;BA.debugLine="End Sub";
return "";
}
public static String  _generate_log_antilog(anywheresoftware.b4a.BA _ba) throws Exception{
int _i = 0;
 //BA.debugLineNum = 957;BA.debugLine="Private Sub Generate_log_antilog";
 //BA.debugLineNum = 959;BA.debugLine="logg(0) = 1";
_logg[(int) (0)] = (int) (1);
 //BA.debugLineNum = 960;BA.debugLine="alogg(0) = 1";
_alogg[(int) (0)] = (int) (1);
 //BA.debugLineNum = 962;BA.debugLine="For i = 1 To 255       'set up log / anti-log tabl";
{
final int step3 = 1;
final int limit3 = (int) (255);
for (_i = (int) (1) ; (step3 > 0 && _i <= limit3) || (step3 < 0 && _i >= limit3); _i = ((int)(0 + _i + step3)) ) {
 //BA.debugLineNum = 963;BA.debugLine="alogg(i) = alogg(i - 1) * 2";
_alogg[_i] = (int) (_alogg[(int) (_i-1)]*2);
 //BA.debugLineNum = 964;BA.debugLine="If alogg(i) >= gf Then";
if (_alogg[_i]>=_gf) { 
 //BA.debugLineNum = 965;BA.debugLine="alogg(i) = Bit.Xor(alogg(i), PP)";
_alogg[_i] = anywheresoftware.b4a.keywords.Common.Bit.Xor(_alogg[_i],_pp);
 };
 //BA.debugLineNum = 967;BA.debugLine="logg(alogg(i)) = i";
_logg[_alogg[_i]] = _i;
 }
};
 //BA.debugLineNum = 970;BA.debugLine="For i = 256 To 511";
{
final int step10 = 1;
final int limit10 = (int) (511);
for (_i = (int) (256) ; (step10 > 0 && _i <= limit10) || (step10 < 0 && _i >= limit10); _i = ((int)(0 + _i + step10)) ) {
 //BA.debugLineNum = 971;BA.debugLine="alogg(i) = alogg(i - 255)";
_alogg[_i] = _alogg[(int) (_i-255)];
 }
};
 //BA.debugLineNum = 974;BA.debugLine="logg(alogg(255)) = 255 '# Set last missing element";
_logg[_alogg[(int) (255)]] = (int) (255);
 //BA.debugLineNum = 978;BA.debugLine="End Sub";
return "";
}
public static int  _generator_polynomial(anywheresoftware.b4a.BA _ba,int _noew) throws Exception{
int[] _a3 = null;
int _i = 0;
 //BA.debugLineNum = 1167;BA.debugLine="Private Sub generator_polynomial(noew As Int) As I";
 //BA.debugLineNum = 1169;BA.debugLine="Dim a3() As Int";
_a3 = new int[(int) (0)];
;
 //BA.debugLineNum = 1172;BA.debugLine="Select Case noew";
switch (_noew) {
case 7: {
 //BA.debugLineNum = 1174;BA.debugLine="a3 = Array As Int(1, 127, 122, 154, 164, 11, 6";
_a3 = new int[]{(int) (1),(int) (127),(int) (122),(int) (154),(int) (164),(int) (11),(int) (68),(int) (117)};
 break; }
case 10: {
 //BA.debugLineNum = 1176;BA.debugLine="a3 = Array As Int(1, 216, 194, 159, 111, 199,";
_a3 = new int[]{(int) (1),(int) (216),(int) (194),(int) (159),(int) (111),(int) (199),(int) (94),(int) (95),(int) (113),(int) (157),(int) (193)};
 break; }
case 13: {
 //BA.debugLineNum = 1178;BA.debugLine="a3 = Array As Int(1, 137, 73, 227, 17, 177, 17";
_a3 = new int[]{(int) (1),(int) (137),(int) (73),(int) (227),(int) (17),(int) (177),(int) (17),(int) (52),(int) (13),(int) (46),(int) (43),(int) (83),(int) (132),(int) (120)};
 break; }
case 15: {
 //BA.debugLineNum = 1180;BA.debugLine="a3 = Array As Int(1, 29, 196, 111, 163, 112, 7";
_a3 = new int[]{(int) (1),(int) (29),(int) (196),(int) (111),(int) (163),(int) (112),(int) (74),(int) (10),(int) (105),(int) (105),(int) (139),(int) (132),(int) (151),(int) (32),(int) (134),(int) (26)};
 break; }
case 16: {
 //BA.debugLineNum = 1182;BA.debugLine="a3 = Array As Int(1, 59, 13, 104, 189, 68, 209";
_a3 = new int[]{(int) (1),(int) (59),(int) (13),(int) (104),(int) (189),(int) (68),(int) (209),(int) (30),(int) (8),(int) (163),(int) (65),(int) (41),(int) (229),(int) (98),(int) (50),(int) (36),(int) (59)};
 break; }
case 17: {
 //BA.debugLineNum = 1184;BA.debugLine="a3 = Array As Int(1, 119, 66, 83, 120, 119, 22";
_a3 = new int[]{(int) (1),(int) (119),(int) (66),(int) (83),(int) (120),(int) (119),(int) (22),(int) (197),(int) (83),(int) (249),(int) (41),(int) (143),(int) (134),(int) (85),(int) (53),(int) (125),(int) (99),(int) (79)};
 break; }
case 18: {
 //BA.debugLineNum = 1186;BA.debugLine="a3 = Array As Int(1, 239, 251, 183, 113, 149,";
_a3 = new int[]{(int) (1),(int) (239),(int) (251),(int) (183),(int) (113),(int) (149),(int) (175),(int) (199),(int) (215),(int) (240),(int) (220),(int) (73),(int) (82),(int) (173),(int) (75),(int) (32),(int) (67),(int) (217),(int) (146)};
 break; }
case 20: {
 //BA.debugLineNum = 1188;BA.debugLine="a3 = Array As Int(1, 152, 185, 240, 5, 111, 99";
_a3 = new int[]{(int) (1),(int) (152),(int) (185),(int) (240),(int) (5),(int) (111),(int) (99),(int) (6),(int) (220),(int) (112),(int) (150),(int) (69),(int) (36),(int) (187),(int) (22),(int) (228),(int) (198),(int) (121),(int) (121),(int) (165),(int) (174)};
 break; }
case 22: {
 //BA.debugLineNum = 1190;BA.debugLine="a3 = Array As Int(1, 89, 179, 131, 176, 182, 2";
_a3 = new int[]{(int) (1),(int) (89),(int) (179),(int) (131),(int) (176),(int) (182),(int) (244),(int) (19),(int) (189),(int) (69),(int) (40),(int) (28),(int) (137),(int) (29),(int) (123),(int) (67),(int) (253),(int) (86),(int) (218),(int) (230),(int) (26),(int) (145),(int) (245)};
 break; }
case 24: {
 //BA.debugLineNum = 1192;BA.debugLine="a3 = Array As Int(1, 122, 118, 169, 70, 178, 2";
_a3 = new int[]{(int) (1),(int) (122),(int) (118),(int) (169),(int) (70),(int) (178),(int) (237),(int) (216),(int) (102),(int) (115),(int) (150),(int) (229),(int) (73),(int) (130),(int) (72),(int) (61),(int) (43),(int) (206),(int) (1),(int) (237),(int) (247),(int) (127),(int) (217),(int) (144),(int) (117)};
 break; }
case 26: {
 //BA.debugLineNum = 1194;BA.debugLine="a3 = Array As Int(1, 246, 51, 183, 4, 136, 98,";
_a3 = new int[]{(int) (1),(int) (246),(int) (51),(int) (183),(int) (4),(int) (136),(int) (98),(int) (199),(int) (152),(int) (77),(int) (56),(int) (206),(int) (24),(int) (145),(int) (40),(int) (209),(int) (117),(int) (233),(int) (42),(int) (135),(int) (68),(int) (70),(int) (144),(int) (146),(int) (77),(int) (43),(int) (94)};
 break; }
case 28: {
 //BA.debugLineNum = 1196;BA.debugLine="a3 = Array As Int(1, 252, 9, 28, 13, 18, 251,";
_a3 = new int[]{(int) (1),(int) (252),(int) (9),(int) (28),(int) (13),(int) (18),(int) (251),(int) (208),(int) (150),(int) (103),(int) (174),(int) (100),(int) (41),(int) (167),(int) (12),(int) (247),(int) (56),(int) (117),(int) (119),(int) (233),(int) (127),(int) (181),(int) (100),(int) (121),(int) (147),(int) (176),(int) (74),(int) (58),(int) (197)};
 break; }
case 30: {
 //BA.debugLineNum = 1198;BA.debugLine="a3 = Array As Int(1, 212, 246, 77, 73, 195, 19";
_a3 = new int[]{(int) (1),(int) (212),(int) (246),(int) (77),(int) (73),(int) (195),(int) (192),(int) (75),(int) (98),(int) (5),(int) (70),(int) (103),(int) (177),(int) (22),(int) (217),(int) (138),(int) (51),(int) (181),(int) (246),(int) (72),(int) (25),(int) (18),(int) (46),(int) (228),(int) (74),(int) (216),(int) (195),(int) (11),(int) (106),(int) (130),(int) (150)};
 break; }
}
;
 //BA.debugLineNum = 1202;BA.debugLine="For i = 1 To 35";
{
final int step30 = 1;
final int limit30 = (int) (35);
for (_i = (int) (1) ; (step30 > 0 && _i <= limit30) || (step30 < 0 && _i >= limit30); _i = ((int)(0 + _i + step30)) ) {
 //BA.debugLineNum = 1203;BA.debugLine="s4c4(i) = 0";
_s4c4[_i] = (int) (0);
 }
};
 //BA.debugLineNum = 1206;BA.debugLine="For i = 1 To noew + 1";
{
final int step33 = 1;
final int limit33 = (int) (_noew+1);
for (_i = (int) (1) ; (step33 > 0 && _i <= limit33) || (step33 < 0 && _i >= limit33); _i = ((int)(0 + _i + step33)) ) {
 //BA.debugLineNum = 1207;BA.debugLine="s4c4(i) = a3(i - 1)";
_s4c4[_i] = _a3[(int) (_i-1)];
 }
};
 //BA.debugLineNum = 1210;BA.debugLine="End Sub";
return 0;
}
public static int  _gf_mul(anywheresoftware.b4a.BA _ba,int _x,int _y) throws Exception{
 //BA.debugLineNum = 1261;BA.debugLine="Private Sub gf_mul(x As Int, y As Int) As Int";
 //BA.debugLineNum = 1263;BA.debugLine="If x = 0 OR y = 0 Then";
if (_x==0 || _y==0) { 
 //BA.debugLineNum = 1264;BA.debugLine="gf_mul_result = 0";
_gf_mul_result = (int) (0);
 }else {
 //BA.debugLineNum = 1266;BA.debugLine="gf_mul_result = alogg(logg(x) + logg(y))";
_gf_mul_result = _alogg[(int) (_logg[_x]+_logg[_y])];
 };
 //BA.debugLineNum = 1269;BA.debugLine="Return gf_mul_result";
if (true) return _gf_mul_result;
 //BA.debugLineNum = 1270;BA.debugLine="End Sub";
return 0;
}
public static String  _place_matrix_data(anywheresoftware.b4a.BA _ba) throws Exception{
int[] _x1 = null;
int[] _y1 = null;
int _ry = 0;
int _col1 = 0;
int _col2 = 0;
int _rgt = 0;
int _teller = 0;
int _up = 0;
int _a3 = 0;
int _i = 0;
int _bitt = 0;
 //BA.debugLineNum = 1272;BA.debugLine="Private Sub place_matrix_data";
 //BA.debugLineNum = 1274;BA.debugLine="Dim x1(31335) As Int   'stores the x coordinate of";
_x1 = new int[(int) (31335)];
;
 //BA.debugLineNum = 1275;BA.debugLine="Dim y1(31335) As Int    'stores the y coordinate o";
_y1 = new int[(int) (31335)];
;
 //BA.debugLineNum = 1281;BA.debugLine="draw_qr      'call procedure to draw the QR matrix";
_draw_qr(_ba);
 //BA.debugLineNum = 1283;BA.debugLine="Dim ry,col1,col2,rgt,teller,up,a3,i As Int";
_ry = 0;
_col1 = 0;
_col2 = 0;
_rgt = 0;
_teller = 0;
_up = 0;
_a3 = 0;
_i = 0;
 //BA.debugLineNum = 1285;BA.debugLine="ry = qr_size                     'we start on exce";
_ry = _qr_size;
 //BA.debugLineNum = 1286;BA.debugLine="col1 = qr_size                   'we start first c";
_col1 = _qr_size;
 //BA.debugLineNum = 1287;BA.debugLine="col2 = col1 - 1              'we do two columns at";
_col2 = (int) (_col1-1);
 //BA.debugLineNum = 1288;BA.debugLine="rgt = 1                      'marker for the right";
_rgt = (int) (1);
 //BA.debugLineNum = 1289;BA.debugLine="teller = 1                   'keeps count of the n";
_teller = (int) (1);
 //BA.debugLineNum = 1290;BA.debugLine="up = 1                       'keep track of the di";
_up = (int) (1);
 //BA.debugLineNum = 1293;BA.debugLine="Do While teller <> max_mod + 1";
while (_teller!=_max_mod+1) {
 //BA.debugLineNum = 1294;BA.debugLine="If rgt = 1 AND up = 1 Then        'in the righ";
if (_rgt==1 && _up==1) { 
 //BA.debugLineNum = 1295;BA.debugLine="a3 = s5cij(ry, col1)";
_a3 = _s5cij[_ry][_col1];
 //BA.debugLineNum = 1296;BA.debugLine="If a3 <> 9 AND a3 <> 10 AND ry > 0 Then";
if (_a3!=9 && _a3!=10 && _ry>0) { 
 //BA.debugLineNum = 1297;BA.debugLine="x1(teller) = ry";
_x1[_teller] = _ry;
 //BA.debugLineNum = 1298;BA.debugLine="y1(teller) = col1";
_y1[_teller] = _col1;
 //BA.debugLineNum = 1299;BA.debugLine="rgt = 0                       'next bit to";
_rgt = (int) (0);
 //BA.debugLineNum = 1300;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 }else {
 //BA.debugLineNum = 1302;BA.debugLine="rgt = 0";
_rgt = (int) (0);
 };
 }else if(_rgt==0 && _up==1) { 
 //BA.debugLineNum = 1306;BA.debugLine="a3 = s5cij(ry, col2)";
_a3 = _s5cij[_ry][_col2];
 //BA.debugLineNum = 1307;BA.debugLine="If a3 <> 9 AND a3 <> 10 AND ry > 0 Then";
if (_a3!=9 && _a3!=10 && _ry>0) { 
 //BA.debugLineNum = 1308;BA.debugLine="x1(teller) = ry";
_x1[_teller] = _ry;
 //BA.debugLineNum = 1309;BA.debugLine="y1(teller) = col2";
_y1[_teller] = _col2;
 //BA.debugLineNum = 1310;BA.debugLine="rgt = 1                      'next bit to";
_rgt = (int) (1);
 //BA.debugLineNum = 1311;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 //BA.debugLineNum = 1312;BA.debugLine="ry = ry - 1                  'go up 1 row";
_ry = (int) (_ry-1);
 }else {
 //BA.debugLineNum = 1314;BA.debugLine="rgt = 1";
_rgt = (int) (1);
 //BA.debugLineNum = 1315;BA.debugLine="ry = ry - 1";
_ry = (int) (_ry-1);
 };
 }else if(_rgt==1 && _up==0) { 
 //BA.debugLineNum = 1319;BA.debugLine="a3 = s5cij(ry, col1)";
_a3 = _s5cij[_ry][_col1];
 //BA.debugLineNum = 1320;BA.debugLine="If a3 <> 9 AND a3 <> 10 AND ry < qr_size +";
if (_a3!=9 && _a3!=10 && _ry<_qr_size+1) { 
 //BA.debugLineNum = 1321;BA.debugLine="x1(teller) = ry";
_x1[_teller] = _ry;
 //BA.debugLineNum = 1322;BA.debugLine="y1(teller) = col1";
_y1[_teller] = _col1;
 //BA.debugLineNum = 1323;BA.debugLine="rgt = 0";
_rgt = (int) (0);
 //BA.debugLineNum = 1324;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 }else {
 //BA.debugLineNum = 1326;BA.debugLine="rgt = 0";
_rgt = (int) (0);
 };
 }else if(_rgt==0 && _up==0) { 
 //BA.debugLineNum = 1330;BA.debugLine="a3 = s5cij(ry, col2)";
_a3 = _s5cij[_ry][_col2];
 //BA.debugLineNum = 1331;BA.debugLine="If a3 <> 9 AND a3 <> 10 AND ry < qr_size +";
if (_a3!=9 && _a3!=10 && _ry<_qr_size+1) { 
 //BA.debugLineNum = 1332;BA.debugLine="x1(teller) = ry";
_x1[_teller] = _ry;
 //BA.debugLineNum = 1333;BA.debugLine="y1(teller) = col2";
_y1[_teller] = _col2;
 //BA.debugLineNum = 1334;BA.debugLine="rgt = 1";
_rgt = (int) (1);
 //BA.debugLineNum = 1335;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 //BA.debugLineNum = 1336;BA.debugLine="ry = ry + 1             'go down 1 row";
_ry = (int) (_ry+1);
 }else {
 //BA.debugLineNum = 1338;BA.debugLine="rgt = 1";
_rgt = (int) (1);
 //BA.debugLineNum = 1339;BA.debugLine="ry = ry + 1";
_ry = (int) (_ry+1);
 };
 };
 //BA.debugLineNum = 1343;BA.debugLine="If ry = 0 AND col1 > 1 AND up = 1 AND rgt = 1";
if (_ry==0 && _col1>1 && _up==1 && _rgt==1) { 
 //BA.debugLineNum = 1344;BA.debugLine="ry = 1";
_ry = (int) (1);
 //BA.debugLineNum = 1345;BA.debugLine="rgt = 1";
_rgt = (int) (1);
 //BA.debugLineNum = 1346;BA.debugLine="up = 0";
_up = (int) (0);
 //BA.debugLineNum = 1347;BA.debugLine="col1 = col1 - 2";
_col1 = (int) (_col1-2);
 //BA.debugLineNum = 1348;BA.debugLine="If col1 = 7 Then col1 = 6    'the vertical t";
if (_col1==7) { 
_col1 = (int) (6);};
 //BA.debugLineNum = 1349;BA.debugLine="col2 = col1 - 1";
_col2 = (int) (_col1-1);
 }else if(_ry==_qr_size+1 && _col1>1 && _up==0 && _rgt==1) { 
 //BA.debugLineNum = 1351;BA.debugLine="ry = qr_size";
_ry = _qr_size;
 //BA.debugLineNum = 1352;BA.debugLine="rgt = 1";
_rgt = (int) (1);
 //BA.debugLineNum = 1353;BA.debugLine="up = 1";
_up = (int) (1);
 //BA.debugLineNum = 1354;BA.debugLine="col1 = col1 - 2";
_col1 = (int) (_col1-2);
 //BA.debugLineNum = 1355;BA.debugLine="If col1 = 7 Then col1 = 6";
if (_col1==7) { 
_col1 = (int) (6);};
 //BA.debugLineNum = 1356;BA.debugLine="col2 = col1 - 1";
_col2 = (int) (_col1-1);
 };
 }
;
 //BA.debugLineNum = 1362;BA.debugLine="If sf.Len(anew) < max_mod Then    'if the string l";
if (_sf._vvv7(_anew)<_max_mod) { 
 //BA.debugLineNum = 1363;BA.debugLine="Do While sf.Len(anew) <> max_mod";
while (_sf._vvv7(_anew)!=_max_mod) {
 //BA.debugLineNum = 1364;BA.debugLine="anew = anew & \"1\"   'Changed from 0 to 1 on 28";
_anew = _anew+"1";
 }
;
 };
 //BA.debugLineNum = 1368;BA.debugLine="teller = 1                    'keep track of the b";
_teller = (int) (1);
 //BA.debugLineNum = 1370;BA.debugLine="Dim bitt As Int";
_bitt = 0;
 //BA.debugLineNum = 1372;BA.debugLine="Do While teller <> max_mod + 1";
while (_teller!=_max_mod+1) {
 //BA.debugLineNum = 1373;BA.debugLine="bitt = sf.Val(sf.Mid(anew, teller, 1))  'get a bi";
_bitt = (int) (_sf._vvvvvvv6(_sf._vvvv5(_anew,_teller,(int) (1))));
 //BA.debugLineNum = 1375;BA.debugLine="If s5cij(x1(teller), y1(teller)) = 0 AND bitt = 0";
if (_s5cij[_x1[_teller]][_y1[_teller]]==0 && _bitt==0) { 
 //BA.debugLineNum = 1376;BA.debugLine="s5cij(x1(teller), y1(teller)) = 10   'decide wh";
_s5cij[_x1[_teller]][_y1[_teller]] = (int) (10);
 }else if(_s5cij[_x1[_teller]][_y1[_teller]]==0 && _bitt==1) { 
 //BA.debugLineNum = 1378;BA.debugLine="s5cij(x1(teller), y1(teller)) = 9";
_s5cij[_x1[_teller]][_y1[_teller]] = (int) (9);
 }else if(_s5cij[_x1[_teller]][_y1[_teller]]==1 && _bitt==0) { 
 //BA.debugLineNum = 1381;BA.debugLine="s5cij(x1(teller), y1(teller)) = 9";
_s5cij[_x1[_teller]][_y1[_teller]] = (int) (9);
 }else if(_s5cij[_x1[_teller]][_y1[_teller]]==1 && _bitt==1) { 
 //BA.debugLineNum = 1383;BA.debugLine="s5cij(x1(teller), y1(teller)) = 10";
_s5cij[_x1[_teller]][_y1[_teller]] = (int) (10);
 };
 //BA.debugLineNum = 1385;BA.debugLine="teller = teller + 1";
_teller = (int) (_teller+1);
 }
;
 //BA.debugLineNum = 1388;BA.debugLine="teken1";
_teken1(_ba);
 //BA.debugLineNum = 1390;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Private Sub Process_Globals";
 //BA.debugLineNum = 6;BA.debugLine="Private Rect1 As Rect";
_rect1 = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper();
 //BA.debugLineNum = 8;BA.debugLine="Private sf As StringFunctions";
_sf = new adr.stringfunctions.stringfunctions();
 //BA.debugLineNum = 9;BA.debugLine="Private gf As Int = 256  'define the Size & Prime";
_gf = (int) (256);
 //BA.debugLineNum = 10;BA.debugLine="Private PP As Int = 285  '...for QR codes";
_pp = (int) (285);
 //BA.debugLineNum = 11;BA.debugLine="Private logg(256) As Int";
_logg = new int[(int) (256)];
;
 //BA.debugLineNum = 12;BA.debugLine="Private alogg(512) As Int";
_alogg = new int[(int) (512)];
;
 //BA.debugLineNum = 13;BA.debugLine="Private gf_mul_result As Int";
_gf_mul_result = 0;
 //BA.debugLineNum = 14;BA.debugLine="Private s4c4(37) As Int";
_s4c4 = new int[(int) (37)];
;
 //BA.debugLineNum = 15;BA.debugLine="Private s4c24(35)";
_s4c24 = new String[(int) (35)];
java.util.Arrays.fill(_s4c24,"");
 //BA.debugLineNum = 16;BA.debugLine="Private s4c1(301)";
_s4c1 = new String[(int) (301)];
java.util.Arrays.fill(_s4c1,"");
 //BA.debugLineNum = 17;BA.debugLine="Private z(4000)";
_z = new String[(int) (4000)];
java.util.Arrays.fill(_z,"");
 //BA.debugLineNum = 18;BA.debugLine="Private message_coeff(2956) As Int   'might have";
_message_coeff = new int[(int) (2956)];
;
 //BA.debugLineNum = 19;BA.debugLine="Private s5cij(180,180) As Int        'dimensioned";
_s5cij = new int[(int) (180)][];
{
int d0 = _s5cij.length;
int d1 = (int) (180);
for (int i0 = 0;i0 < d0;i0++) {
_s5cij[i0] = new int[d1];
}
}
;
 //BA.debugLineNum = 20;BA.debugLine="Private version_no, max_mod, qr_size As Int";
_version_no = 0;
_max_mod = 0;
_qr_size = 0;
 //BA.debugLineNum = 21;BA.debugLine="Private error_level As String";
_error_level = "";
 //BA.debugLineNum = 22;BA.debugLine="Private a As String";
_a = "";
 //BA.debugLineNum = 23;BA.debugLine="Private b As String";
_b = "";
 //BA.debugLineNum = 24;BA.debugLine="Private q As String";
_q = "";
 //BA.debugLineNum = 25;BA.debugLine="Private tel2 As Int";
_tel2 = 0;
 //BA.debugLineNum = 26;BA.debugLine="Private anew As String";
_anew = "";
 //BA.debugLineNum = 27;BA.debugLine="Private ECC_woord As String";
_ecc_woord = "";
 //BA.debugLineNum = 28;BA.debugLine="Private no_of_error_words,mess_coef_teller As Int";
_no_of_error_words = 0;
_mess_coef_teller = 0;
 //BA.debugLineNum = 29;BA.debugLine="Private block1,block2,dw1,dw2,ew1,ew2 As Int";
_block1 = 0;
_block2 = 0;
_dw1 = 0;
_dw2 = 0;
_ew1 = 0;
_ew2 = 0;
 //BA.debugLineNum = 30;BA.debugLine="Private max_data_bits As Int";
_max_data_bits = 0;
 //BA.debugLineNum = 31;BA.debugLine="Private maxlen As Int";
_maxlen = 0;
 //BA.debugLineNum = 32;BA.debugLine="Private tipe As String";
_tipe = "";
 //BA.debugLineNum = 33;BA.debugLine="Private maskp As Int";
_maskp = 0;
 //BA.debugLineNum = 34;BA.debugLine="Private dat As String";
_dat = "";
 //BA.debugLineNum = 35;BA.debugLine="Private ver1(), ver2(), ver3(), ver4(), ver5(), v";
_ver1 = new int[(int) (0)];
;
_ver2 = new int[(int) (0)];
;
_ver3 = new int[(int) (0)];
;
_ver4 = new int[(int) (0)];
;
_ver5 = new int[(int) (0)];
;
_ver6 = new int[(int) (0)];
;
_ver7 = new int[(int) (0)];
;
_ver8 = new int[(int) (0)];
;
_ver9 = new int[(int) (0)];
;
_ver10 = new int[(int) (0)];
;
 //BA.debugLineNum = 36;BA.debugLine="Private ver11(), ver12(), ver13(), ver14(), ver15";
_ver11 = new int[(int) (0)];
;
_ver12 = new int[(int) (0)];
;
_ver13 = new int[(int) (0)];
;
_ver14 = new int[(int) (0)];
;
_ver15 = new int[(int) (0)];
;
_ver16 = new int[(int) (0)];
;
_ver17 = new int[(int) (0)];
;
_ver18 = new int[(int) (0)];
;
_ver19 = new int[(int) (0)];
;
_ver20 = new int[(int) (0)];
;
 //BA.debugLineNum = 37;BA.debugLine="Private ver21(), ver22(), ver23(), ver24(), ver25";
_ver21 = new int[(int) (0)];
;
_ver22 = new int[(int) (0)];
;
_ver23 = new int[(int) (0)];
;
_ver24 = new int[(int) (0)];
;
_ver25 = new int[(int) (0)];
;
_ver26 = new int[(int) (0)];
;
_ver27 = new int[(int) (0)];
;
_ver28 = new int[(int) (0)];
;
_ver29 = new int[(int) (0)];
;
_ver30 = new int[(int) (0)];
;
 //BA.debugLineNum = 38;BA.debugLine="Private ver31(), ver32(), ver33(), ver34(), ver35";
_ver31 = new int[(int) (0)];
;
_ver32 = new int[(int) (0)];
;
_ver33 = new int[(int) (0)];
;
_ver34 = new int[(int) (0)];
;
_ver35 = new int[(int) (0)];
;
_ver36 = new int[(int) (0)];
;
_ver37 = new int[(int) (0)];
;
_ver38 = new int[(int) (0)];
;
_ver39 = new int[(int) (0)];
;
_ver40 = new int[(int) (0)];
;
 //BA.debugLineNum = 40;BA.debugLine="ver1 = Array As Int (1,21,441,0,30,1,0,0,0,10,19";
_ver1 = new int[]{(int) (1),(int) (21),(int) (441),(int) (0),(int) (30),(int) (1),(int) (0),(int) (0),(int) (0),(int) (10),(int) (192),(int) (233),(int) (208),(int) (208),(int) (0),(int) (26),(int) (7),(int) (10),(int) (13),(int) (17),(int) (152),(int) (128),(int) (104),(int) (72),(int) (1),(int) (26),(int) (19),(int) (7),(int) (0),(int) (0),(int) (0),(int) (0),(int) (1),(int) (26),(int) (16),(int) (10),(int) (0),(int) (0),(int) (0),(int) (0),(int) (1),(int) (26),(int) (13),(int) (13),(int) (0),(int) (0),(int) (0),(int) (0),(int) (1),(int) (26),(int) (9),(int) (17),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (17),(int) (14),(int) (11),(int) (7),(int) (40),(int) (33),(int) (26),(int) (16),(int) (24),(int) (19),(int) (15),(int) (9),(int) (19),(int) (16),(int) (13),(int) (9)};
 //BA.debugLineNum = 41;BA.debugLine="ver2 = Array As Int (2,25,625,0,30,1,1,0,25,18,1";
_ver2 = new int[]{(int) (2),(int) (25),(int) (625),(int) (0),(int) (30),(int) (1),(int) (1),(int) (0),(int) (25),(int) (18),(int) (192),(int) (266),(int) (359),(int) (352),(int) (7),(int) (44),(int) (10),(int) (16),(int) (22),(int) (28),(int) (272),(int) (224),(int) (176),(int) (128),(int) (1),(int) (44),(int) (34),(int) (10),(int) (0),(int) (0),(int) (0),(int) (0),(int) (1),(int) (44),(int) (28),(int) (16),(int) (0),(int) (0),(int) (0),(int) (0),(int) (1),(int) (44),(int) (22),(int) (22),(int) (0),(int) (0),(int) (0),(int) (0),(int) (1),(int) (44),(int) (16),(int) (28),(int) (0),(int) (0),(int) (0),(int) (0),(int) (1),(int) (6),(int) (18),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (32),(int) (26),(int) (20),(int) (14),(int) (76),(int) (62),(int) (47),(int) (33),(int) (46),(int) (37),(int) (28),(int) (19),(int) (34),(int) (28),(int) (22),(int) (16)};
 //BA.debugLineNum = 42;BA.debugLine="ver3 = Array As Int (3,29,841,0,30,1,1,0,25,26,1";
_ver3 = new int[]{(int) (3),(int) (29),(int) (841),(int) (0),(int) (30),(int) (1),(int) (1),(int) (0),(int) (25),(int) (26),(int) (192),(int) (274),(int) (567),(int) (560),(int) (7),(int) (70),(int) (15),(int) (26),(int) (36),(int) (44),(int) (440),(int) (352),(int) (272),(int) (208),(int) (1),(int) (70),(int) (55),(int) (15),(int) (0),(int) (0),(int) (0),(int) (0),(int) (1),(int) (70),(int) (44),(int) (26),(int) (0),(int) (0),(int) (0),(int) (0),(int) (2),(int) (35),(int) (17),(int) (18),(int) (0),(int) (0),(int) (0),(int) (0),(int) (2),(int) (35),(int) (13),(int) (22),(int) (0),(int) (0),(int) (0),(int) (0),(int) (1),(int) (6),(int) (22),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (53),(int) (42),(int) (32),(int) (24),(int) (126),(int) (100),(int) (76),(int) (57),(int) (76),(int) (60),(int) (46),(int) (34),(int) (55),(int) (44),(int) (17),(int) (13)};
 //BA.debugLineNum = 43;BA.debugLine="ver4 = Array As Int (4,33,1089,0,30,1,1,0,25,34,";
_ver4 = new int[]{(int) (4),(int) (33),(int) (1089),(int) (0),(int) (30),(int) (1),(int) (1),(int) (0),(int) (25),(int) (34),(int) (192),(int) (282),(int) (807),(int) (800),(int) (7),(int) (100),(int) (20),(int) (36),(int) (52),(int) (64),(int) (640),(int) (512),(int) (384),(int) (288),(int) (1),(int) (100),(int) (80),(int) (20),(int) (0),(int) (0),(int) (0),(int) (0),(int) (2),(int) (50),(int) (32),(int) (18),(int) (0),(int) (0),(int) (0),(int) (0),(int) (2),(int) (50),(int) (24),(int) (26),(int) (0),(int) (0),(int) (0),(int) (0),(int) (4),(int) (25),(int) (9),(int) (16),(int) (0),(int) (0),(int) (0),(int) (0),(int) (1),(int) (6),(int) (26),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (78),(int) (62),(int) (46),(int) (34),(int) (113),(int) (89),(int) (66),(int) (49),(int) (113),(int) (89),(int) (66),(int) (49),(int) (80),(int) (32),(int) (24),(int) (9)};
 //BA.debugLineNum = 44;BA.debugLine="ver5 = Array As Int (5,37,1369,0,30,1,1,0,25,42,";
_ver5 = new int[]{(int) (5),(int) (37),(int) (1369),(int) (0),(int) (30),(int) (1),(int) (1),(int) (0),(int) (25),(int) (42),(int) (192),(int) (290),(int) (1079),(int) (1072),(int) (7),(int) (134),(int) (26),(int) (48),(int) (72),(int) (88),(int) (864),(int) (688),(int) (496),(int) (368),(int) (1),(int) (134),(int) (108),(int) (26),(int) (0),(int) (0),(int) (0),(int) (0),(int) (2),(int) (67),(int) (43),(int) (24),(int) (0),(int) (0),(int) (0),(int) (0),(int) (2),(int) (33),(int) (15),(int) (18),(int) (2),(int) (34),(int) (16),(int) (18),(int) (2),(int) (33),(int) (11),(int) (22),(int) (2),(int) (34),(int) (12),(int) (22),(int) (1),(int) (6),(int) (30),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (106),(int) (84),(int) (60),(int) (44),(int) (153),(int) (121),(int) (86),(int) (63),(int) (153),(int) (121),(int) (86),(int) (63),(int) (108),(int) (43),(int) (16),(int) (12)};
 //BA.debugLineNum = 45;BA.debugLine="ver6 = Array As Int (6,41,1681,0,30,1,1,0,25,50,";
_ver6 = new int[]{(int) (6),(int) (41),(int) (1681),(int) (0),(int) (30),(int) (1),(int) (1),(int) (0),(int) (25),(int) (50),(int) (192),(int) (298),(int) (1383),(int) (1376),(int) (7),(int) (172),(int) (36),(int) (64),(int) (96),(int) (112),(int) (1088),(int) (864),(int) (608),(int) (480),(int) (2),(int) (86),(int) (68),(int) (18),(int) (0),(int) (0),(int) (0),(int) (0),(int) (4),(int) (43),(int) (27),(int) (16),(int) (0),(int) (0),(int) (0),(int) (0),(int) (4),(int) (43),(int) (19),(int) (24),(int) (0),(int) (0),(int) (0),(int) (0),(int) (4),(int) (43),(int) (15),(int) (28),(int) (0),(int) (0),(int) (0),(int) (0),(int) (1),(int) (6),(int) (34),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (134),(int) (106),(int) (74),(int) (58),(int) (194),(int) (153),(int) (107),(int) (83),(int) (194),(int) (153),(int) (107),(int) (83),(int) (68),(int) (27),(int) (19),(int) (15)};
 //BA.debugLineNum = 46;BA.debugLine="ver7 = Array As Int (7,45,2025,36,30,1,6,1,150,4";
_ver7 = new int[]{(int) (7),(int) (45),(int) (2025),(int) (36),(int) (30),(int) (1),(int) (6),(int) (1),(int) (150),(int) (48),(int) (192),(int) (457),(int) (1568),(int) (1568),(int) (0),(int) (196),(int) (40),(int) (72),(int) (108),(int) (130),(int) (1248),(int) (992),(int) (704),(int) (528),(int) (2),(int) (98),(int) (78),(int) (20),(int) (0),(int) (0),(int) (0),(int) (0),(int) (4),(int) (49),(int) (31),(int) (18),(int) (0),(int) (0),(int) (0),(int) (0),(int) (2),(int) (32),(int) (14),(int) (18),(int) (4),(int) (33),(int) (15),(int) (18),(int) (4),(int) (39),(int) (13),(int) (26),(int) (1),(int) (40),(int) (14),(int) (26),(int) (6),(int) (6),(int) (22),(int) (38),(int) (0),(int) (0),(int) (0),(int) (0),(int) (154),(int) (122),(int) (86),(int) (64),(int) (223),(int) (177),(int) (124),(int) (92),(int) (223),(int) (177),(int) (124),(int) (92),(int) (78),(int) (31),(int) (15),(int) (14)};
 //BA.debugLineNum = 47;BA.debugLine="ver8 = Array As Int (8,49,2401,36,30,1,6,1,150,5";
_ver8 = new int[]{(int) (8),(int) (49),(int) (2401),(int) (36),(int) (30),(int) (1),(int) (6),(int) (1),(int) (150),(int) (56),(int) (192),(int) (465),(int) (1936),(int) (1936),(int) (0),(int) (242),(int) (48),(int) (88),(int) (132),(int) (156),(int) (1552),(int) (1232),(int) (880),(int) (688),(int) (2),(int) (121),(int) (97),(int) (24),(int) (0),(int) (0),(int) (0),(int) (0),(int) (2),(int) (60),(int) (38),(int) (22),(int) (2),(int) (61),(int) (39),(int) (22),(int) (4),(int) (40),(int) (18),(int) (22),(int) (2),(int) (41),(int) (19),(int) (22),(int) (4),(int) (40),(int) (14),(int) (26),(int) (2),(int) (41),(int) (15),(int) (26),(int) (6),(int) (6),(int) (24),(int) (42),(int) (0),(int) (0),(int) (0),(int) (0),(int) (192),(int) (152),(int) (108),(int) (84),(int) (278),(int) (220),(int) (156),(int) (121),(int) (278),(int) (220),(int) (156),(int) (121),(int) (97),(int) (39),(int) (19),(int) (15)};
 //BA.debugLineNum = 48;BA.debugLine="ver9 = Array As Int (9,53,2809,36,30,1,6,1,150,6";
_ver9 = new int[]{(int) (9),(int) (53),(int) (2809),(int) (36),(int) (30),(int) (1),(int) (6),(int) (1),(int) (150),(int) (64),(int) (192),(int) (473),(int) (2336),(int) (2336),(int) (0),(int) (292),(int) (60),(int) (110),(int) (160),(int) (192),(int) (1856),(int) (1456),(int) (1056),(int) (800),(int) (2),(int) (146),(int) (116),(int) (30),(int) (0),(int) (0),(int) (0),(int) (0),(int) (3),(int) (58),(int) (36),(int) (22),(int) (2),(int) (59),(int) (37),(int) (22),(int) (4),(int) (36),(int) (16),(int) (20),(int) (4),(int) (37),(int) (17),(int) (20),(int) (4),(int) (36),(int) (12),(int) (24),(int) (4),(int) (37),(int) (13),(int) (24),(int) (6),(int) (6),(int) (26),(int) (46),(int) (0),(int) (0),(int) (0),(int) (0),(int) (230),(int) (180),(int) (130),(int) (98),(int) (551),(int) (431),(int) (311),(int) (234),(int) (334),(int) (261),(int) (188),(int) (142),(int) (116),(int) (37),(int) (17),(int) (13)};
 //BA.debugLineNum = 49;BA.debugLine="ver10 = Array As Int (10,57,3249,36,30,1,6,1,150";
_ver10 = new int[]{(int) (10),(int) (57),(int) (3249),(int) (36),(int) (30),(int) (1),(int) (6),(int) (1),(int) (150),(int) (72),(int) (192),(int) (481),(int) (2768),(int) (2768),(int) (0),(int) (346),(int) (72),(int) (130),(int) (192),(int) (224),(int) (2192),(int) (1728),(int) (1232),(int) (976),(int) (2),(int) (86),(int) (68),(int) (18),(int) (2),(int) (87),(int) (69),(int) (18),(int) (4),(int) (69),(int) (43),(int) (26),(int) (1),(int) (70),(int) (44),(int) (26),(int) (6),(int) (43),(int) (19),(int) (24),(int) (2),(int) (44),(int) (20),(int) (24),(int) (6),(int) (43),(int) (15),(int) (28),(int) (2),(int) (44),(int) (16),(int) (28),(int) (6),(int) (6),(int) (28),(int) (50),(int) (0),(int) (0),(int) (0),(int) (0),(int) (271),(int) (213),(int) (151),(int) (119),(int) (651),(int) (512),(int) (363),(int) (287),(int) (394),(int) (310),(int) (220),(int) (173),(int) (69),(int) (44),(int) (20),(int) (16)};
 //BA.debugLineNum = 50;BA.debugLine="ver11 = Array As Int (11,61,3721,36,30,1,6,1,150";
_ver11 = new int[]{(int) (11),(int) (61),(int) (3721),(int) (36),(int) (30),(int) (1),(int) (6),(int) (1),(int) (150),(int) (80),(int) (192),(int) (489),(int) (3232),(int) (3232),(int) (0),(int) (404),(int) (80),(int) (150),(int) (224),(int) (264),(int) (2592),(int) (2032),(int) (1440),(int) (1120),(int) (4),(int) (101),(int) (81),(int) (20),(int) (0),(int) (0),(int) (0),(int) (0),(int) (1),(int) (80),(int) (50),(int) (30),(int) (4),(int) (81),(int) (51),(int) (30),(int) (4),(int) (50),(int) (22),(int) (28),(int) (4),(int) (51),(int) (23),(int) (28),(int) (3),(int) (36),(int) (12),(int) (24),(int) (8),(int) (37),(int) (13),(int) (24),(int) (6),(int) (6),(int) (30),(int) (54),(int) (0),(int) (0),(int) (0),(int) (0),(int) (321),(int) (251),(int) (177),(int) (137),(int) (771),(int) (603),(int) (426),(int) (330),(int) (467),(int) (365),(int) (258),(int) (199),(int) (81),(int) (51),(int) (23),(int) (13)};
 //BA.debugLineNum = 51;BA.debugLine="ver12 = Array As Int (12,65,4225,36,30,1,6,1,150";
_ver12 = new int[]{(int) (12),(int) (65),(int) (4225),(int) (36),(int) (30),(int) (1),(int) (6),(int) (1),(int) (150),(int) (88),(int) (192),(int) (497),(int) (3728),(int) (3728),(int) (0),(int) (466),(int) (96),(int) (176),(int) (260),(int) (308),(int) (2960),(int) (2320),(int) (1648),(int) (1264),(int) (2),(int) (116),(int) (92),(int) (24),(int) (2),(int) (117),(int) (93),(int) (24),(int) (6),(int) (58),(int) (36),(int) (22),(int) (2),(int) (59),(int) (37),(int) (22),(int) (4),(int) (46),(int) (20),(int) (26),(int) (6),(int) (47),(int) (21),(int) (26),(int) (7),(int) (42),(int) (14),(int) (28),(int) (4),(int) (43),(int) (15),(int) (28),(int) (6),(int) (6),(int) (32),(int) (58),(int) (0),(int) (0),(int) (0),(int) (0),(int) (367),(int) (287),(int) (203),(int) (155),(int) (882),(int) (690),(int) (488),(int) (373),(int) (534),(int) (418),(int) (295),(int) (226),(int) (93),(int) (37),(int) (21),(int) (15)};
 //BA.debugLineNum = 52;BA.debugLine="ver13 = Array As Int (13,69,4761,36,30,1,6,1,150";
_ver13 = new int[]{(int) (13),(int) (69),(int) (4761),(int) (36),(int) (30),(int) (1),(int) (6),(int) (1),(int) (150),(int) (96),(int) (192),(int) (505),(int) (4256),(int) (4256),(int) (0),(int) (532),(int) (104),(int) (198),(int) (288),(int) (352),(int) (3424),(int) (2672),(int) (1952),(int) (1440),(int) (4),(int) (133),(int) (107),(int) (26),(int) (0),(int) (0),(int) (0),(int) (0),(int) (8),(int) (59),(int) (37),(int) (22),(int) (1),(int) (60),(int) (38),(int) (22),(int) (8),(int) (44),(int) (20),(int) (24),(int) (4),(int) (45),(int) (21),(int) (24),(int) (12),(int) (33),(int) (11),(int) (22),(int) (4),(int) (34),(int) (12),(int) (22),(int) (6),(int) (6),(int) (34),(int) (62),(int) (0),(int) (0),(int) (0),(int) (0),(int) (425),(int) (331),(int) (241),(int) (177),(int) (1021),(int) (795),(int) (579),(int) (426),(int) (618),(int) (482),(int) (351),(int) (258),(int) (107),(int) (38),(int) (21),(int) (12)};
 //BA.debugLineNum = 53;BA.debugLine="ver14 = Array As Int (14,73,5329,36,30,1,13,2,32";
_ver14 = new int[]{(int) (14),(int) (73),(int) (5329),(int) (36),(int) (30),(int) (1),(int) (13),(int) (2),(int) (325),(int) (94),(int) (192),(int) (678),(int) (4651),(int) (4648),(int) (3),(int) (581),(int) (120),(int) (216),(int) (320),(int) (384),(int) (3688),(int) (2920),(int) (2088),(int) (1576),(int) (3),(int) (145),(int) (115),(int) (30),(int) (1),(int) (146),(int) (116),(int) (30),(int) (4),(int) (64),(int) (40),(int) (24),(int) (5),(int) (65),(int) (41),(int) (24),(int) (11),(int) (36),(int) (16),(int) (20),(int) (5),(int) (37),(int) (17),(int) (20),(int) (11),(int) (36),(int) (12),(int) (24),(int) (5),(int) (37),(int) (13),(int) (24),(int) (13),(int) (6),(int) (26),(int) (46),(int) (66),(int) (0),(int) (0),(int) (0),(int) (458),(int) (362),(int) (258),(int) (194),(int) (1100),(int) (870),(int) (620),(int) (467),(int) (666),(int) (527),(int) (375),(int) (282),(int) (116),(int) (41),(int) (17),(int) (13)};
 //BA.debugLineNum = 54;BA.debugLine="ver15 = Array As Int (15,77,5929,36,30,1,13,2,32";
_ver15 = new int[]{(int) (15),(int) (77),(int) (5929),(int) (36),(int) (30),(int) (1),(int) (13),(int) (2),(int) (325),(int) (102),(int) (192),(int) (686),(int) (5243),(int) (5240),(int) (3),(int) (655),(int) (132),(int) (240),(int) (36),(int) (432),(int) (4184),(int) (3320),(int) (4952),(int) (1784),(int) (5),(int) (109),(int) (87),(int) (22),(int) (1),(int) (110),(int) (88),(int) (22),(int) (5),(int) (65),(int) (41),(int) (24),(int) (5),(int) (66),(int) (42),(int) (24),(int) (5),(int) (54),(int) (24),(int) (30),(int) (7),(int) (55),(int) (25),(int) (30),(int) (11),(int) (36),(int) (12),(int) (24),(int) (7),(int) (37),(int) (13),(int) (24),(int) (13),(int) (6),(int) (26),(int) (48),(int) (70),(int) (0),(int) (0),(int) (0),(int) (520),(int) (412),(int) (292),(int) (220),(int) (1249),(int) (990),(int) (702),(int) (529),(int) (757),(int) (599),(int) (425),(int) (320),(int) (88),(int) (42),(int) (25),(int) (13)};
 //BA.debugLineNum = 55;BA.debugLine="ver16 = Array As Int (16,81,6561,36,30,1,13,2,32";
_ver16 = new int[]{(int) (16),(int) (81),(int) (6561),(int) (36),(int) (30),(int) (1),(int) (13),(int) (2),(int) (325),(int) (110),(int) (192),(int) (694),(int) (5867),(int) (5864),(int) (3),(int) (733),(int) (144),(int) (280),(int) (408),(int) (480),(int) (4712),(int) (3624),(int) (2600),(int) (2024),(int) (5),(int) (122),(int) (98),(int) (24),(int) (1),(int) (123),(int) (99),(int) (24),(int) (7),(int) (73),(int) (45),(int) (28),(int) (3),(int) (74),(int) (46),(int) (28),(int) (15),(int) (43),(int) (19),(int) (24),(int) (2),(int) (44),(int) (20),(int) (24),(int) (3),(int) (45),(int) (15),(int) (30),(int) (13),(int) (46),(int) (16),(int) (30),(int) (13),(int) (6),(int) (26),(int) (50),(int) (74),(int) (0),(int) (0),(int) (0),(int) (586),(int) (450),(int) (322),(int) (250),(int) (1407),(int) (1081),(int) (774),(int) (601),(int) (853),(int) (655),(int) (469),(int) (364),(int) (99),(int) (46),(int) (20),(int) (16)};
 //BA.debugLineNum = 56;BA.debugLine="ver17 = Array As Int (17,85,7225,36,30,1,13,2,32";
_ver17 = new int[]{(int) (17),(int) (85),(int) (7225),(int) (36),(int) (30),(int) (1),(int) (13),(int) (2),(int) (325),(int) (118),(int) (192),(int) (702),(int) (6523),(int) (6520),(int) (3),(int) (815),(int) (168),(int) (308),(int) (448),(int) (532),(int) (5176),(int) (4056),(int) (2936),(int) (2264),(int) (1),(int) (135),(int) (107),(int) (28),(int) (5),(int) (136),(int) (108),(int) (28),(int) (10),(int) (74),(int) (46),(int) (28),(int) (1),(int) (75),(int) (47),(int) (14),(int) (1),(int) (50),(int) (22),(int) (28),(int) (15),(int) (51),(int) (23),(int) (28),(int) (2),(int) (42),(int) (14),(int) (28),(int) (17),(int) (43),(int) (15),(int) (28),(int) (13),(int) (6),(int) (30),(int) (54),(int) (78),(int) (0),(int) (0),(int) (0),(int) (644),(int) (504),(int) (364),(int) (280),(int) (1547),(int) (1211),(int) (875),(int) (673),(int) (937),(int) (733),(int) (530),(int) (407),(int) (108),(int) (47),(int) (23),(int) (15)};
 //BA.debugLineNum = 57;BA.debugLine="ver18 = Array As Int (18,89,7921,36,30,1,13,2,32";
_ver18 = new int[]{(int) (18),(int) (89),(int) (7921),(int) (36),(int) (30),(int) (1),(int) (13),(int) (2),(int) (325),(int) (126),(int) (192),(int) (710),(int) (7211),(int) (7208),(int) (3),(int) (901),(int) (180),(int) (338),(int) (504),(int) (588),(int) (5768),(int) (4504),(int) (3176),(int) (2504),(int) (5),(int) (150),(int) (120),(int) (30),(int) (1),(int) (151),(int) (121),(int) (30),(int) (9),(int) (69),(int) (43),(int) (26),(int) (4),(int) (70),(int) (44),(int) (26),(int) (17),(int) (50),(int) (22),(int) (28),(int) (1),(int) (51),(int) (23),(int) (28),(int) (2),(int) (42),(int) (14),(int) (28),(int) (19),(int) (43),(int) (15),(int) (28),(int) (13),(int) (6),(int) (30),(int) (56),(int) (82),(int) (0),(int) (0),(int) (0),(int) (718),(int) (560),(int) (394),(int) (310),(int) (1724),(int) (1345),(int) (947),(int) (745),(int) (1045),(int) (815),(int) (573),(int) (451),(int) (121),(int) (44),(int) (23),(int) (15)};
 //BA.debugLineNum = 58;BA.debugLine="ver19 = Array As Int (19,93,8649,36,30,1,13,2,32";
_ver19 = new int[]{(int) (19),(int) (93),(int) (8649),(int) (36),(int) (30),(int) (1),(int) (13),(int) (2),(int) (325),(int) (134),(int) (192),(int) (718),(int) (7931),(int) (7928),(int) (3),(int) (991),(int) (196),(int) (364),(int) (546),(int) (650),(int) (6360),(int) (5016),(int) (3560),(int) (2728),(int) (3),(int) (141),(int) (113),(int) (28),(int) (4),(int) (142),(int) (114),(int) (28),(int) (3),(int) (70),(int) (44),(int) (26),(int) (11),(int) (71),(int) (45),(int) (26),(int) (17),(int) (47),(int) (21),(int) (26),(int) (4),(int) (48),(int) (22),(int) (26),(int) (9),(int) (39),(int) (13),(int) (26),(int) (16),(int) (40),(int) (14),(int) (26),(int) (13),(int) (6),(int) (30),(int) (58),(int) (86),(int) (0),(int) (0),(int) (0),(int) (792),(int) (624),(int) (442),(int) (338),(int) (192),(int) (1499),(int) (1062),(int) (812),(int) (1152),(int) (908),(int) (643),(int) (492),(int) (114),(int) (45),(int) (22),(int) (14)};
 //BA.debugLineNum = 59;BA.debugLine="ver20 = Array As Int (20,97,9409,36,30,1,13,2,32";
_ver20 = new int[]{(int) (20),(int) (97),(int) (9409),(int) (36),(int) (30),(int) (1),(int) (13),(int) (2),(int) (325),(int) (142),(int) (192),(int) (726),(int) (8683),(int) (8680),(int) (3),(int) (1085),(int) (224),(int) (416),(int) (600),(int) (700),(int) (6888),(int) (5352),(int) (3880),(int) (3080),(int) (3),(int) (135),(int) (107),(int) (28),(int) (5),(int) (136),(int) (108),(int) (28),(int) (3),(int) (67),(int) (41),(int) (26),(int) (13),(int) (68),(int) (42),(int) (26),(int) (15),(int) (54),(int) (24),(int) (30),(int) (5),(int) (55),(int) (25),(int) (30),(int) (15),(int) (43),(int) (15),(int) (28),(int) (10),(int) (44),(int) (16),(int) (28),(int) (13),(int) (6),(int) (34),(int) (62),(int) (90),(int) (0),(int) (0),(int) (0),(int) (858),(int) (666),(int) (482),(int) (382),(int) (2060),(int) (1599),(int) (1158),(int) (918),(int) (1248),(int) (969),(int) (701),(int) (556),(int) (108),(int) (42),(int) (25),(int) (16)};
 //BA.debugLineNum = 60;BA.debugLine="ver21 = Array As Int (21,101,10201,36,30,1,22,3,";
_ver21 = new int[]{(int) (21),(int) (101),(int) (10201),(int) (36),(int) (30),(int) (1),(int) (22),(int) (3),(int) (550),(int) (140),(int) (192),(int) (949),(int) (9252),(int) (9248),(int) (4),(int) (1156),(int) (224),(int) (442),(int) (644),(int) (750),(int) (7456),(int) (5712),(int) (4096),(int) (3248),(int) (4),(int) (144),(int) (116),(int) (28),(int) (4),(int) (145),(int) (117),(int) (28),(int) (17),(int) (68),(int) (42),(int) (26),(int) (0),(int) (0),(int) (0),(int) (0),(int) (17),(int) (50),(int) (22),(int) (28),(int) (6),(int) (51),(int) (23),(int) (28),(int) (19),(int) (46),(int) (16),(int) (30),(int) (6),(int) (47),(int) (17),(int) (30),(int) (22),(int) (6),(int) (28),(int) (50),(int) (72),(int) (94),(int) (0),(int) (0),(int) (929),(int) (711),(int) (509),(int) (403),(int) (2231),(int) (1707),(int) (1223),(int) (968),(int) (1351),(int) (1034),(int) (741),(int) (586),(int) (117),(int) (42),(int) (23),(int) (17)};
 //BA.debugLineNum = 61;BA.debugLine="ver22 = Array As Int (22,105,11025,36,30,1,22,3,";
_ver22 = new int[]{(int) (22),(int) (105),(int) (11025),(int) (36),(int) (30),(int) (1),(int) (22),(int) (3),(int) (550),(int) (148),(int) (192),(int) (957),(int) (10068),(int) (10064),(int) (4),(int) (1258),(int) (252),(int) (476),(int) (690),(int) (816),(int) (8048),(int) (6256),(int) (4544),(int) (3536),(int) (2),(int) (139),(int) (111),(int) (28),(int) (7),(int) (140),(int) (112),(int) (28),(int) (17),(int) (74),(int) (46),(int) (28),(int) (0),(int) (0),(int) (0),(int) (0),(int) (7),(int) (54),(int) (24),(int) (30),(int) (16),(int) (55),(int) (25),(int) (30),(int) (34),(int) (37),(int) (13),(int) (24),(int) (0),(int) (0),(int) (0),(int) (0),(int) (22),(int) (6),(int) (26),(int) (50),(int) (74),(int) (98),(int) (0),(int) (0),(int) (1003),(int) (779),(int) (565),(int) (439),(int) (2408),(int) (1871),(int) (1357),(int) (1055),(int) (1459),(int) (1133),(int) (822),(int) (639),(int) (112),(int) (46),(int) (25),(int) (13)};
 //BA.debugLineNum = 62;BA.debugLine="ver23 = Array As Int (23,109,11881,36,30,1,22,3,";
_ver23 = new int[]{(int) (23),(int) (109),(int) (11881),(int) (36),(int) (30),(int) (1),(int) (22),(int) (3),(int) (550),(int) (156),(int) (192),(int) (965),(int) (10916),(int) (10912),(int) (4),(int) (1364),(int) (270),(int) (504),(int) (750),(int) (900),(int) (8752),(int) (6880),(int) (4912),(int) (3712),(int) (4),(int) (151),(int) (121),(int) (30),(int) (5),(int) (152),(int) (122),(int) (30),(int) (4),(int) (75),(int) (47),(int) (28),(int) (14),(int) (76),(int) (48),(int) (28),(int) (11),(int) (54),(int) (24),(int) (30),(int) (14),(int) (55),(int) (25),(int) (30),(int) (16),(int) (45),(int) (15),(int) (30),(int) (14),(int) (46),(int) (16),(int) (30),(int) (22),(int) (6),(int) (30),(int) (54),(int) (78),(int) (102),(int) (0),(int) (0),(int) (1091),(int) (857),(int) (611),(int) (461),(int) (2619),(int) (2058),(int) (1467),(int) (1107),(int) (1587),(int) (1247),(int) (88),(int) (671),(int) (122),(int) (48),(int) (25),(int) (16)};
 //BA.debugLineNum = 63;BA.debugLine="ver24 = Array As Int (24,113,12769,36,30,1,22,3,";
_ver24 = new int[]{(int) (24),(int) (113),(int) (12769),(int) (36),(int) (30),(int) (1),(int) (22),(int) (3),(int) (550),(int) (164),(int) (192),(int) (973),(int) (11796),(int) (11792),(int) (4),(int) (1474),(int) (300),(int) (560),(int) (810),(int) (960),(int) (9392),(int) (7312),(int) (5312),(int) (4112),(int) (6),(int) (147),(int) (117),(int) (30),(int) (4),(int) (148),(int) (118),(int) (30),(int) (6),(int) (73),(int) (45),(int) (28),(int) (14),(int) (74),(int) (46),(int) (28),(int) (11),(int) (54),(int) (24),(int) (30),(int) (16),(int) (55),(int) (25),(int) (30),(int) (30),(int) (46),(int) (16),(int) (30),(int) (2),(int) (47),(int) (17),(int) (30),(int) (22),(int) (6),(int) (28),(int) (54),(int) (80),(int) (106),(int) (0),(int) (0),(int) (1171),(int) (911),(int) (661),(int) (511),(int) (2811),(int) (2187),(int) (1587),(int) (1227),(int) (1703),(int) (1325),(int) (962),(int) (743),(int) (118),(int) (46),(int) (25),(int) (17)};
 //BA.debugLineNum = 64;BA.debugLine="ver25 = Array As Int (25,117,13689,36,30,1,22,3,";
_ver25 = new int[]{(int) (25),(int) (117),(int) (13689),(int) (36),(int) (30),(int) (1),(int) (22),(int) (3),(int) (550),(int) (172),(int) (192),(int) (981),(int) (12708),(int) (12704),(int) (4),(int) (1588),(int) (312),(int) (588),(int) (870),(int) (1050),(int) (10208),(int) (8000),(int) (5744),(int) (4304),(int) (8),(int) (132),(int) (106),(int) (26),(int) (4),(int) (133),(int) (107),(int) (26),(int) (8),(int) (75),(int) (47),(int) (28),(int) (13),(int) (76),(int) (48),(int) (28),(int) (7),(int) (54),(int) (24),(int) (30),(int) (22),(int) (55),(int) (25),(int) (30),(int) (22),(int) (45),(int) (15),(int) (30),(int) (13),(int) (46),(int) (16),(int) (30),(int) (22),(int) (6),(int) (32),(int) (58),(int) (84),(int) (110),(int) (0),(int) (0),(int) (1273),(int) (997),(int) (715),(int) (535),(int) (3056),(int) (2394),(int) (1717),(int) (1285),(int) (1852),(int) (1450),(int) (1040),(int) (778),(int) (107),(int) (48),(int) (25),(int) (16)};
 //BA.debugLineNum = 65;BA.debugLine="ver26 = Array As Int (26,121,14641,36,30,1,22,3,";
_ver26 = new int[]{(int) (26),(int) (121),(int) (14641),(int) (36),(int) (30),(int) (1),(int) (22),(int) (3),(int) (550),(int) (180),(int) (192),(int) (989),(int) (13652),(int) (13648),(int) (4),(int) (1706),(int) (336),(int) (644),(int) (952),(int) (1110),(int) (10960),(int) (8496),(int) (6032),(int) (4768),(int) (10),(int) (142),(int) (114),(int) (28),(int) (2),(int) (143),(int) (115),(int) (28),(int) (19),(int) (74),(int) (46),(int) (28),(int) (4),(int) (75),(int) (47),(int) (28),(int) (28),(int) (50),(int) (22),(int) (28),(int) (6),(int) (51),(int) (23),(int) (28),(int) (33),(int) (46),(int) (16),(int) (30),(int) (4),(int) (47),(int) (17),(int) (30),(int) (22),(int) (6),(int) (30),(int) (58),(int) (86),(int) (114),(int) (0),(int) (0),(int) (1367),(int) (1059),(int) (751),(int) (593),(int) (3282),(int) (2543),(int) (1803),(int) (1424),(int) (1989),(int) (1541),(int) (1093),(int) (863),(int) (115),(int) (47),(int) (23),(int) (17)};
 //BA.debugLineNum = 66;BA.debugLine="ver27 = Array As Int (27,125,15625,36,30,1,22,3,";
_ver27 = new int[]{(int) (27),(int) (125),(int) (15625),(int) (36),(int) (30),(int) (1),(int) (22),(int) (3),(int) (550),(int) (188),(int) (192),(int) (997),(int) (14628),(int) (14624),(int) (4),(int) (1828),(int) (360),(int) (700),(int) (1020),(int) (1200),(int) (11744),(int) (9024),(int) (6464),(int) (5024),(int) (8),(int) (152),(int) (122),(int) (30),(int) (4),(int) (153),(int) (123),(int) (30),(int) (22),(int) (73),(int) (45),(int) (28),(int) (3),(int) (74),(int) (46),(int) (28),(int) (8),(int) (53),(int) (23),(int) (30),(int) (26),(int) (54),(int) (24),(int) (30),(int) (12),(int) (45),(int) (15),(int) (30),(int) (28),(int) (26),(int) (16),(int) (30),(int) (22),(int) (6),(int) (34),(int) (62),(int) (90),(int) (118),(int) (0),(int) (0),(int) (1465),(int) (1125),(int) (805),(int) (625),(int) (3516),(int) (2700),(int) (1932),(int) (1500),(int) (2131),(int) (1636),(int) (1171),(int) (909),(int) (123),(int) (46),(int) (24),(int) (16)};
 //BA.debugLineNum = 67;BA.debugLine="ver28 = Array As Int (28,129,16641,36,30,1,33,4,";
_ver28 = new int[]{(int) (28),(int) (129),(int) (16641),(int) (36),(int) (30),(int) (1),(int) (33),(int) (4),(int) (825),(int) (186),(int) (192),(int) (1270),(int) (15371),(int) (15368),(int) (3),(int) (1921),(int) (390),(int) (728),(int) (1050),(int) (1260),(int) (12248),(int) (9544),(int) (6968),(int) (5288),(int) (3),(int) (147),(int) (117),(int) (30),(int) (10),(int) (148),(int) (118),(int) (30),(int) (3),(int) (73),(int) (45),(int) (28),(int) (23),(int) (74),(int) (46),(int) (28),(int) (4),(int) (54),(int) (24),(int) (30),(int) (31),(int) (55),(int) (25),(int) (30),(int) (11),(int) (45),(int) (15),(int) (30),(int) (31),(int) (46),(int) (16),(int) (30),(int) (33),(int) (6),(int) (26),(int) (50),(int) (74),(int) (98),(int) (122),(int) (0),(int) (1528),(int) (1190),(int) (868),(int) (658),(int) (3668),(int) (2856),(int) (2084),(int) (1580),(int) (2222),(int) (1731),(int) (1262),(int) (957),(int) (118),(int) (46),(int) (25),(int) (16)};
 //BA.debugLineNum = 68;BA.debugLine="ver29 = Array As Int (29,133,17689,36,30,1,33,4,";
_ver29 = new int[]{(int) (29),(int) (133),(int) (17689),(int) (36),(int) (30),(int) (1),(int) (33),(int) (4),(int) (825),(int) (194),(int) (192),(int) (1278),(int) (16411),(int) (16408),(int) (3),(int) (2051),(int) (420),(int) (784),(int) (1140),(int) (1350),(int) (13048),(int) (10136),(int) (7288),(int) (5608),(int) (7),(int) (146),(int) (116),(int) (30),(int) (7),(int) (147),(int) (117),(int) (30),(int) (21),(int) (73),(int) (45),(int) (28),(int) (7),(int) (74),(int) (46),(int) (28),(int) (1),(int) (53),(int) (23),(int) (30),(int) (37),(int) (54),(int) (24),(int) (30),(int) (19),(int) (45),(int) (15),(int) (30),(int) (26),(int) (46),(int) (16),(int) (30),(int) (33),(int) (6),(int) (30),(int) (54),(int) (78),(int) (102),(int) (126),(int) (0),(int) (1628),(int) (1264),(int) (908),(int) (698),(int) (398),(int) (3034),(int) (2180),(int) (1676),(int) (2368),(int) (1838),(int) (1321),(int) (1015),(int) (117),(int) (46),(int) (24),(int) (16)};
 //BA.debugLineNum = 69;BA.debugLine="ver30 = Array As Int (30,137,18769,36,30,1,33,4,";
_ver30 = new int[]{(int) (30),(int) (137),(int) (18769),(int) (36),(int) (30),(int) (1),(int) (33),(int) (4),(int) (825),(int) (202),(int) (192),(int) (1286),(int) (17483),(int) (17480),(int) (3),(int) (2185),(int) (450),(int) (812),(int) (1200),(int) (1440),(int) (13880),(int) (10984),(int) (7880),(int) (5960),(int) (5),(int) (145),(int) (115),(int) (30),(int) (10),(int) (146),(int) (116),(int) (30),(int) (19),(int) (75),(int) (47),(int) (28),(int) (10),(int) (76),(int) (48),(int) (28),(int) (15),(int) (54),(int) (24),(int) (30),(int) (25),(int) (55),(int) (25),(int) (30),(int) (23),(int) (45),(int) (15),(int) (30),(int) (25),(int) (46),(int) (16),(int) (30),(int) (33),(int) (6),(int) (26),(int) (52),(int) (78),(int) (104),(int) (130),(int) (0),(int) (1732),(int) (1370),(int) (982),(int) (742),(int) (4157),(int) (3288),(int) (2357),(int) (1781),(int) (2519),(int) (1993),(int) (1428),(int) (1079),(int) (116),(int) (48),(int) (25),(int) (16)};
 //BA.debugLineNum = 70;BA.debugLine="ver31 = Array As Int (31,141,19881,36,30,1,33,4,";
_ver31 = new int[]{(int) (31),(int) (141),(int) (19881),(int) (36),(int) (30),(int) (1),(int) (33),(int) (4),(int) (825),(int) (210),(int) (192),(int) (1294),(int) (18587),(int) (18584),(int) (3),(int) (2323),(int) (480),(int) (868),(int) (1290),(int) (1530),(int) (14744),(int) (11640),(int) (8264),(int) (6344),(int) (13),(int) (145),(int) (115),(int) (30),(int) (3),(int) (146),(int) (116),(int) (30),(int) (2),(int) (74),(int) (46),(int) (28),(int) (29),(int) (75),(int) (47),(int) (28),(int) (42),(int) (54),(int) (24),(int) (30),(int) (1),(int) (55),(int) (25),(int) (30),(int) (23),(int) (45),(int) (15),(int) (30),(int) (28),(int) (46),(int) (16),(int) (30),(int) (33),(int) (6),(int) (30),(int) (56),(int) (82),(int) (108),(int) (134),(int) (0),(int) (1840),(int) (1452),(int) (1030),(int) (790),(int) (4416),(int) (3485),(int) (2472),(int) (1896),(int) (2676),(int) (2112),(int) (1498),(int) (1149),(int) (116),(int) (47),(int) (25),(int) (16)};
 //BA.debugLineNum = 71;BA.debugLine="ver32 = Array As Int (32,145,21025,36,30,1,33,4,";
_ver32 = new int[]{(int) (32),(int) (145),(int) (21025),(int) (36),(int) (30),(int) (1),(int) (33),(int) (4),(int) (825),(int) (218),(int) (192),(int) (1302),(int) (19723),(int) (19720),(int) (3),(int) (2465),(int) (510),(int) (924),(int) (1350),(int) (1620),(int) (15640),(int) (12328),(int) (8920),(int) (6760),(int) (17),(int) (145),(int) (115),(int) (30),(int) (0),(int) (0),(int) (0),(int) (0),(int) (10),(int) (74),(int) (46),(int) (28),(int) (23),(int) (75),(int) (47),(int) (28),(int) (10),(int) (54),(int) (24),(int) (30),(int) (35),(int) (55),(int) (25),(int) (30),(int) (19),(int) (45),(int) (15),(int) (30),(int) (35),(int) (46),(int) (16),(int) (30),(int) (33),(int) (6),(int) (34),(int) (60),(int) (86),(int) (112),(int) (138),(int) (0),(int) (1952),(int) (1538),(int) (1112),(int) (842),(int) (4685),(int) (3692),(int) (2669),(int) (2021),(int) (2839),(int) (2237),(int) (1617),(int) (1225),(int) (115),(int) (47),(int) (25),(int) (16)};
 //BA.debugLineNum = 72;BA.debugLine="ver33 = Array As Int (33,149,22201,36,30,1,33,4,";
_ver33 = new int[]{(int) (33),(int) (149),(int) (22201),(int) (36),(int) (30),(int) (1),(int) (33),(int) (4),(int) (825),(int) (226),(int) (192),(int) (1310),(int) (20891),(int) (20888),(int) (3),(int) (2611),(int) (540),(int) (980),(int) (1440),(int) (1710),(int) (16568),(int) (13048),(int) (9368),(int) (7208),(int) (17),(int) (145),(int) (115),(int) (30),(int) (1),(int) (146),(int) (116),(int) (30),(int) (14),(int) (74),(int) (46),(int) (28),(int) (21),(int) (75),(int) (47),(int) (28),(int) (29),(int) (54),(int) (24),(int) (30),(int) (19),(int) (55),(int) (25),(int) (30),(int) (11),(int) (45),(int) (15),(int) (30),(int) (46),(int) (46),(int) (16),(int) (30),(int) (33),(int) (6),(int) (30),(int) (58),(int) (86),(int) (114),(int) (142),(int) (0),(int) (2068),(int) (1628),(int) (1168),(int) (898),(int) (4964),(int) (3908),(int) (2804),(int) (2156),(int) (3008),(int) (2368),(int) (1699),(int) (1306),(int) (116),(int) (47),(int) (25),(int) (16)};
 //BA.debugLineNum = 73;BA.debugLine="ver34 = Array As Int (34,153,23409,36,30,1,33,4,";
_ver34 = new int[]{(int) (34),(int) (153),(int) (23409),(int) (36),(int) (30),(int) (1),(int) (33),(int) (4),(int) (825),(int) (234),(int) (192),(int) (1318),(int) (22091),(int) (22088),(int) (3),(int) (2761),(int) (570),(int) (1036),(int) (1530),(int) (1800),(int) (17528),(int) (13800),(int) (9848),(int) (7688),(int) (13),(int) (145),(int) (115),(int) (30),(int) (6),(int) (146),(int) (116),(int) (30),(int) (14),(int) (74),(int) (46),(int) (28),(int) (23),(int) (75),(int) (47),(int) (28),(int) (44),(int) (54),(int) (24),(int) (30),(int) (7),(int) (55),(int) (25),(int) (30),(int) (59),(int) (46),(int) (16),(int) (30),(int) (1),(int) (47),(int) (17),(int) (30),(int) (33),(int) (6),(int) (34),(int) (62),(int) (90),(int) (118),(int) (146),(int) (0),(int) (2188),(int) (1722),(int) (1228),(int) (958),(int) (5252),(int) (4133),(int) (2948),(int) (2300),(int) (3182),(int) (2505),(int) (1786),(int) (1393),(int) (116),(int) (47),(int) (25),(int) (17)};
 //BA.debugLineNum = 74;BA.debugLine="ver35 = Array As Int (35,157,24649,36,30,1,46,5,";
_ver35 = new int[]{(int) (35),(int) (157),(int) (24649),(int) (36),(int) (30),(int) (1),(int) (46),(int) (5),(int) (1150),(int) (232),(int) (192),(int) (1641),(int) (23008),(int) (23008),(int) (0),(int) (2876),(int) (570),(int) (1064),(int) (1590),(int) (1890),(int) (18448),(int) (14496),(int) (10288),(int) (7888),(int) (12),(int) (151),(int) (121),(int) (30),(int) (7),(int) (152),(int) (122),(int) (30),(int) (12),(int) (75),(int) (47),(int) (28),(int) (26),(int) (76),(int) (48),(int) (28),(int) (39),(int) (54),(int) (24),(int) (30),(int) (14),(int) (55),(int) (25),(int) (30),(int) (22),(int) (45),(int) (15),(int) (30),(int) (41),(int) (46),(int) (16),(int) (30),(int) (46),(int) (6),(int) (30),(int) (54),(int) (78),(int) (102),(int) (126),(int) (150),(int) (2303),(int) (1809),(int) (1283),(int) (983),(int) (5528),(int) (4342),(int) (3080),(int) (2360),(int) (3350),(int) (2631),(int) (1866),(int) (1430),(int) (122),(int) (48),(int) (25),(int) (16)};
 //BA.debugLineNum = 75;BA.debugLine="ver36 = Array As Int (36,161,25921,36,30,1,46,5,";
_ver36 = new int[]{(int) (36),(int) (161),(int) (25921),(int) (36),(int) (30),(int) (1),(int) (46),(int) (5),(int) (1150),(int) (240),(int) (192),(int) (1649),(int) (24272),(int) (24272),(int) (0),(int) (3034),(int) (600),(int) (1120),(int) (1680),(int) (1980),(int) (19472),(int) (15312),(int) (10832),(int) (8432),(int) (6),(int) (151),(int) (121),(int) (30),(int) (14),(int) (152),(int) (122),(int) (30),(int) (6),(int) (75),(int) (47),(int) (28),(int) (34),(int) (76),(int) (48),(int) (28),(int) (46),(int) (54),(int) (24),(int) (30),(int) (10),(int) (55),(int) (25),(int) (30),(int) (2),(int) (45),(int) (15),(int) (30),(int) (64),(int) (46),(int) (16),(int) (30),(int) (46),(int) (6),(int) (24),(int) (50),(int) (76),(int) (102),(int) (128),(int) (154),(int) (2431),(int) (1911),(int) (1351),(int) (1051),(int) (5835),(int) (4587),(int) (3243),(int) (2523),(int) (3536),(int) (2779),(int) (1965),(int) (1529),(int) (122),(int) (48),(int) (25),(int) (16)};
 //BA.debugLineNum = 76;BA.debugLine="ver37 = Array As Int (37,165,27225,36,30,1,46,5,";
_ver37 = new int[]{(int) (37),(int) (165),(int) (27225),(int) (36),(int) (30),(int) (1),(int) (46),(int) (5),(int) (1150),(int) (248),(int) (192),(int) (1657),(int) (25568),(int) (25568),(int) (0),(int) (3196),(int) (630),(int) (1204),(int) (1770),(int) (2100),(int) (20528),(int) (15936),(int) (11408),(int) (8768),(int) (17),(int) (152),(int) (122),(int) (30),(int) (4),(int) (153),(int) (123),(int) (30),(int) (29),(int) (74),(int) (46),(int) (28),(int) (14),(int) (75),(int) (47),(int) (28),(int) (49),(int) (54),(int) (24),(int) (30),(int) (10),(int) (55),(int) (25),(int) (30),(int) (24),(int) (45),(int) (15),(int) (30),(int) (46),(int) (46),(int) (16),(int) (30),(int) (46),(int) (6),(int) (28),(int) (54),(int) (80),(int) (106),(int) (132),(int) (158),(int) (2563),(int) (1989),(int) (1423),(int) (1093),(int) (6152),(int) (4774),(int) (3416),(int) (2624),(int) (3728),(int) (2893),(int) (2070),(int) (1590),(int) (123),(int) (47),(int) (25),(int) (16)};
 //BA.debugLineNum = 77;BA.debugLine="ver38 = Array As Int (38,169,28561,36,30,1,46,5,";
_ver38 = new int[]{(int) (38),(int) (169),(int) (28561),(int) (36),(int) (30),(int) (1),(int) (46),(int) (5),(int) (1150),(int) (256),(int) (192),(int) (1665),(int) (26896),(int) (26896),(int) (0),(int) (3362),(int) (660),(int) (1260),(int) (1860),(int) (2220),(int) (21616),(int) (16816),(int) (12016),(int) (9136),(int) (4),(int) (152),(int) (122),(int) (30),(int) (18),(int) (153),(int) (123),(int) (30),(int) (13),(int) (74),(int) (46),(int) (28),(int) (32),(int) (75),(int) (47),(int) (28),(int) (48),(int) (54),(int) (24),(int) (30),(int) (14),(int) (55),(int) (25),(int) (30),(int) (42),(int) (45),(int) (15),(int) (30),(int) (32),(int) (46),(int) (16),(int) (30),(int) (46),(int) (6),(int) (32),(int) (58),(int) (84),(int) (110),(int) (136),(int) (162),(int) (2699),(int) (2099),(int) (1499),(int) (1139),(int) (6478),(int) (5038),(int) (3598),(int) (2734),(int) (3926),(int) (3053),(int) (2180),(int) (1657),(int) (123),(int) (47),(int) (25),(int) (16)};
 //BA.debugLineNum = 78;BA.debugLine="ver39 = Array As Int (39,173,29929,36,30,1,46,5,";
_ver39 = new int[]{(int) (39),(int) (173),(int) (29929),(int) (36),(int) (30),(int) (1),(int) (46),(int) (5),(int) (1150),(int) (264),(int) (192),(int) (1673),(int) (28256),(int) (28256),(int) (0),(int) (3532),(int) (720),(int) (1316),(int) (1950),(int) (2310),(int) (22496),(int) (17728),(int) (12656),(int) (9776),(int) (20),(int) (147),(int) (117),(int) (30),(int) (4),(int) (148),(int) (118),(int) (30),(int) (40),(int) (75),(int) (47),(int) (28),(int) (7),(int) (76),(int) (48),(int) (28),(int) (43),(int) (54),(int) (24),(int) (30),(int) (22),(int) (55),(int) (25),(int) (30),(int) (10),(int) (45),(int) (15),(int) (30),(int) (67),(int) (46),(int) (16),(int) (30),(int) (46),(int) (6),(int) (26),(int) (54),(int) (82),(int) (110),(int) (138),(int) (166),(int) (2809),(int) (2213),(int) (1579),(int) (1219),(int) (6742),(int) (5312),(int) (3790),(int) (2926),(int) (4086),(int) (3219),(int) (2297),(int) (1773),(int) (118),(int) (48),(int) (25),(int) (16)};
 //BA.debugLineNum = 79;BA.debugLine="ver40 = Array As Int (40,177,31329,36,30,1,46,5,";
_ver40 = new int[]{(int) (40),(int) (177),(int) (31329),(int) (36),(int) (30),(int) (1),(int) (46),(int) (5),(int) (1150),(int) (272),(int) (192),(int) (1681),(int) (29648),(int) (29648),(int) (0),(int) (3706),(int) (750),(int) (1372),(int) (2040),(int) (2430),(int) (23648),(int) (18672),(int) (13328),(int) (10208),(int) (19),(int) (148),(int) (118),(int) (30),(int) (6),(int) (149),(int) (119),(int) (30),(int) (18),(int) (75),(int) (47),(int) (28),(int) (31),(int) (76),(int) (48),(int) (28),(int) (34),(int) (54),(int) (24),(int) (30),(int) (34),(int) (55),(int) (25),(int) (30),(int) (20),(int) (45),(int) (15),(int) (30),(int) (61),(int) (46),(int) (16),(int) (30),(int) (46),(int) (6),(int) (30),(int) (58),(int) (86),(int) (114),(int) (142),(int) (170),(int) (2953),(int) (2331),(int) (1663),(int) (1273),(int) (7088),(int) (5595),(int) (3992),(int) (3056),(int) (4295),(int) (3390),(int) (2419),(int) (1851),(int) (119),(int) (48),(int) (25),(int) (16)};
 //BA.debugLineNum = 81;BA.debugLine="Private bcolor As Int";
_bcolor = 0;
 //BA.debugLineNum = 82;BA.debugLine="Private fcolor As Int";
_fcolor = 0;
 //BA.debugLineNum = 83;BA.debugLine="Private shp As String";
_shp = "";
 //BA.debugLineNum = 85;BA.debugLine="End Sub";
return "";
}
public static String  _select_block(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 2353;BA.debugLine="Private Sub select_block";
 //BA.debugLineNum = 2355;BA.debugLine="Select Case version_no";
switch (_version_no) {
case 1: {
 //BA.debugLineNum = 2358;BA.debugLine="max_mod = ver1(12)";
_max_mod = _ver1[(int) (12)];
 //BA.debugLineNum = 2359;BA.debugLine="qr_size = ver1(1)";
_qr_size = _ver1[(int) (1)];
 //BA.debugLineNum = 2361;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver1";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver1[(int) (20)];};
 //BA.debugLineNum = 2362;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver1";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver1[(int) (21)];};
 //BA.debugLineNum = 2363;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver1";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver1[(int) (22)];};
 //BA.debugLineNum = 2364;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver1";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver1[(int) (23)];};
 //BA.debugLineNum = 2366;BA.debugLine="If error_level = \"L\" Then block1 = ver1(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver1[(int) (24)];};
 //BA.debugLineNum = 2367;BA.debugLine="If error_level = \"L\" Then block2 = ver1(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver1[(int) (28)];};
 //BA.debugLineNum = 2368;BA.debugLine="If error_level = \"L\" Then dw1 = ver1(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver1[(int) (26)];};
 //BA.debugLineNum = 2369;BA.debugLine="If error_level = \"L\" Then dw2 = ver1(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver1[(int) (30)];};
 //BA.debugLineNum = 2370;BA.debugLine="If error_level = \"L\" Then ew1 = ver1(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver1[(int) (27)];};
 //BA.debugLineNum = 2371;BA.debugLine="If error_level = \"L\" Then ew2 = ver1(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver1[(int) (31)];};
 //BA.debugLineNum = 2373;BA.debugLine="If error_level = \"M\" Then block1 = ver1(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver1[(int) (32)];};
 //BA.debugLineNum = 2374;BA.debugLine="If error_level = \"M\" Then block2 = ver1(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver1[(int) (36)];};
 //BA.debugLineNum = 2375;BA.debugLine="If error_level = \"M\" Then dw1 = ver1(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver1[(int) (34)];};
 //BA.debugLineNum = 2376;BA.debugLine="If error_level = \"M\" Then dw2 = ver1(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver1[(int) (38)];};
 //BA.debugLineNum = 2377;BA.debugLine="If error_level = \"M\" Then ew1 = ver1(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver1[(int) (35)];};
 //BA.debugLineNum = 2378;BA.debugLine="If error_level = \"M\" Then ew2 = ver1(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver1[(int) (39)];};
 //BA.debugLineNum = 2380;BA.debugLine="If error_level = \"Q\" Then block1 = ver1(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver1[(int) (40)];};
 //BA.debugLineNum = 2381;BA.debugLine="If error_level = \"Q\" Then block2 = ver1(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver1[(int) (44)];};
 //BA.debugLineNum = 2382;BA.debugLine="If error_level = \"Q\" Then dw1 = ver1(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver1[(int) (42)];};
 //BA.debugLineNum = 2383;BA.debugLine="If error_level = \"Q\" Then dw2 = ver1(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver1[(int) (46)];};
 //BA.debugLineNum = 2384;BA.debugLine="If error_level = \"Q\" Then ew1 = ver1(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver1[(int) (43)];};
 //BA.debugLineNum = 2385;BA.debugLine="If error_level = \"Q\" Then ew2 = ver1(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver1[(int) (47)];};
 //BA.debugLineNum = 2387;BA.debugLine="If error_level = \"H\" Then block1 = ver1(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver1[(int) (48)];};
 //BA.debugLineNum = 2388;BA.debugLine="If error_level = \"H\" Then block2 = ver1(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver1[(int) (52)];};
 //BA.debugLineNum = 2389;BA.debugLine="If error_level = \"H\" Then dw1 = ver1(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver1[(int) (50)];};
 //BA.debugLineNum = 2390;BA.debugLine="If error_level = \"H\" Then dw2 = ver1(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver1[(int) (54)];};
 //BA.debugLineNum = 2391;BA.debugLine="If error_level = \"H\" Then ew1 = ver1(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver1[(int) (51)];};
 //BA.debugLineNum = 2392;BA.debugLine="If error_level = \"H\" Then ew2 = ver1(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver1[(int) (55)];};
 //BA.debugLineNum = 2394;BA.debugLine="If error_level = \"L\" Then tel2 = ver1(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver1[(int) (76)];};
 //BA.debugLineNum = 2395;BA.debugLine="If error_level = \"M\" Then tel2 = ver1(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver1[(int) (77)];};
 //BA.debugLineNum = 2396;BA.debugLine="If error_level = \"Q\" Then tel2 = ver1(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver1[(int) (78)];};
 //BA.debugLineNum = 2397;BA.debugLine="If error_level = \"H\" Then tel2 = ver1(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver1[(int) (79)];};
 break; }
case 2: {
 //BA.debugLineNum = 2399;BA.debugLine="max_mod = ver2(12)";
_max_mod = _ver2[(int) (12)];
 //BA.debugLineNum = 2400;BA.debugLine="qr_size = ver2(1)";
_qr_size = _ver2[(int) (1)];
 //BA.debugLineNum = 2402;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver2";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver2[(int) (20)];};
 //BA.debugLineNum = 2403;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver2";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver2[(int) (21)];};
 //BA.debugLineNum = 2404;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver2";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver2[(int) (22)];};
 //BA.debugLineNum = 2405;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver2";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver2[(int) (23)];};
 //BA.debugLineNum = 2407;BA.debugLine="If error_level = \"L\" Then block1 = ver2(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver2[(int) (24)];};
 //BA.debugLineNum = 2408;BA.debugLine="If error_level = \"L\" Then block2 = ver2(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver2[(int) (28)];};
 //BA.debugLineNum = 2409;BA.debugLine="If error_level = \"L\" Then dw1 = ver2(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver2[(int) (26)];};
 //BA.debugLineNum = 2410;BA.debugLine="If error_level = \"L\" Then dw2 = ver2(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver2[(int) (30)];};
 //BA.debugLineNum = 2411;BA.debugLine="If error_level = \"L\" Then ew1 = ver2(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver2[(int) (27)];};
 //BA.debugLineNum = 2412;BA.debugLine="If error_level = \"L\" Then ew2 = ver2(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver2[(int) (31)];};
 //BA.debugLineNum = 2414;BA.debugLine="If error_level = \"M\" Then block1 = ver2(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver2[(int) (32)];};
 //BA.debugLineNum = 2415;BA.debugLine="If error_level = \"M\" Then block2 = ver2(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver2[(int) (36)];};
 //BA.debugLineNum = 2416;BA.debugLine="If error_level = \"M\" Then dw1 = ver2(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver2[(int) (34)];};
 //BA.debugLineNum = 2417;BA.debugLine="If error_level = \"M\" Then dw2 = ver2(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver2[(int) (38)];};
 //BA.debugLineNum = 2418;BA.debugLine="If error_level = \"M\" Then ew1 = ver2(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver2[(int) (35)];};
 //BA.debugLineNum = 2419;BA.debugLine="If error_level = \"M\" Then ew2 = ver2(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver2[(int) (39)];};
 //BA.debugLineNum = 2421;BA.debugLine="If error_level = \"Q\" Then block1 = ver2(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver2[(int) (40)];};
 //BA.debugLineNum = 2422;BA.debugLine="If error_level = \"Q\" Then block2 = ver2(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver2[(int) (44)];};
 //BA.debugLineNum = 2423;BA.debugLine="If error_level = \"Q\" Then dw1 = ver2(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver2[(int) (42)];};
 //BA.debugLineNum = 2424;BA.debugLine="If error_level = \"Q\" Then dw2 = ver2(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver2[(int) (46)];};
 //BA.debugLineNum = 2425;BA.debugLine="If error_level = \"Q\" Then ew1 = ver2(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver2[(int) (43)];};
 //BA.debugLineNum = 2426;BA.debugLine="If error_level = \"Q\" Then ew2 = ver2(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver2[(int) (47)];};
 //BA.debugLineNum = 2428;BA.debugLine="If error_level = \"H\" Then block1 = ver2(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver2[(int) (48)];};
 //BA.debugLineNum = 2429;BA.debugLine="If error_level = \"H\" Then block2 = ver2(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver2[(int) (52)];};
 //BA.debugLineNum = 2430;BA.debugLine="If error_level = \"H\" Then dw1 = ver2(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver2[(int) (50)];};
 //BA.debugLineNum = 2431;BA.debugLine="If error_level = \"H\" Then dw2 = ver2(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver2[(int) (54)];};
 //BA.debugLineNum = 2432;BA.debugLine="If error_level = \"H\" Then ew1 = ver2(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver2[(int) (51)];};
 //BA.debugLineNum = 2433;BA.debugLine="If error_level = \"H\" Then ew2 = ver2(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver2[(int) (55)];};
 //BA.debugLineNum = 2435;BA.debugLine="If error_level = \"L\" Then tel2 = ver2(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver2[(int) (76)];};
 //BA.debugLineNum = 2436;BA.debugLine="If error_level = \"M\" Then tel2 = ver2(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver2[(int) (77)];};
 //BA.debugLineNum = 2437;BA.debugLine="If error_level = \"Q\" Then tel2 = ver2(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver2[(int) (78)];};
 //BA.debugLineNum = 2438;BA.debugLine="If error_level = \"H\" Then tel2 = ver2(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver2[(int) (79)];};
 break; }
case 3: {
 //BA.debugLineNum = 2440;BA.debugLine="max_mod = ver3(12)";
_max_mod = _ver3[(int) (12)];
 //BA.debugLineNum = 2441;BA.debugLine="qr_size = ver3(1)";
_qr_size = _ver3[(int) (1)];
 //BA.debugLineNum = 2443;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver3";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver3[(int) (20)];};
 //BA.debugLineNum = 2444;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver3";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver3[(int) (21)];};
 //BA.debugLineNum = 2445;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver3";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver3[(int) (22)];};
 //BA.debugLineNum = 2446;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver3";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver3[(int) (23)];};
 //BA.debugLineNum = 2448;BA.debugLine="If error_level = \"L\" Then block1 = ver3(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver3[(int) (24)];};
 //BA.debugLineNum = 2449;BA.debugLine="If error_level = \"L\" Then block2 = ver3(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver3[(int) (28)];};
 //BA.debugLineNum = 2450;BA.debugLine="If error_level = \"L\" Then dw1 = ver3(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver3[(int) (26)];};
 //BA.debugLineNum = 2451;BA.debugLine="If error_level = \"L\" Then dw2 = ver3(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver3[(int) (30)];};
 //BA.debugLineNum = 2452;BA.debugLine="If error_level = \"L\" Then ew1 = ver3(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver3[(int) (27)];};
 //BA.debugLineNum = 2453;BA.debugLine="If error_level = \"L\" Then ew2 = ver3(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver3[(int) (31)];};
 //BA.debugLineNum = 2455;BA.debugLine="If error_level = \"M\" Then block1 = ver3(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver3[(int) (32)];};
 //BA.debugLineNum = 2456;BA.debugLine="If error_level = \"M\" Then block2 = ver3(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver3[(int) (36)];};
 //BA.debugLineNum = 2457;BA.debugLine="If error_level = \"M\" Then dw1 = ver3(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver3[(int) (34)];};
 //BA.debugLineNum = 2458;BA.debugLine="If error_level = \"M\" Then dw2 = ver3(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver3[(int) (38)];};
 //BA.debugLineNum = 2459;BA.debugLine="If error_level = \"M\" Then ew1 = ver3(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver3[(int) (35)];};
 //BA.debugLineNum = 2460;BA.debugLine="If error_level = \"M\" Then ew2 = ver3(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver3[(int) (39)];};
 //BA.debugLineNum = 2462;BA.debugLine="If error_level = \"Q\" Then block1 = ver3(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver3[(int) (40)];};
 //BA.debugLineNum = 2463;BA.debugLine="If error_level = \"Q\" Then block2 = ver3(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver3[(int) (44)];};
 //BA.debugLineNum = 2464;BA.debugLine="If error_level = \"Q\" Then dw1 = ver3(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver3[(int) (42)];};
 //BA.debugLineNum = 2465;BA.debugLine="If error_level = \"Q\" Then dw2 = ver3(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver3[(int) (46)];};
 //BA.debugLineNum = 2466;BA.debugLine="If error_level = \"Q\" Then ew1 = ver3(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver3[(int) (43)];};
 //BA.debugLineNum = 2467;BA.debugLine="If error_level = \"Q\" Then ew2 = ver3(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver3[(int) (47)];};
 //BA.debugLineNum = 2469;BA.debugLine="If error_level = \"H\" Then block1 = ver3(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver3[(int) (48)];};
 //BA.debugLineNum = 2470;BA.debugLine="If error_level = \"H\" Then block2 = ver3(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver3[(int) (52)];};
 //BA.debugLineNum = 2471;BA.debugLine="If error_level = \"H\" Then dw1 = ver3(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver3[(int) (50)];};
 //BA.debugLineNum = 2472;BA.debugLine="If error_level = \"H\" Then dw2 = ver3(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver3[(int) (54)];};
 //BA.debugLineNum = 2473;BA.debugLine="If error_level = \"H\" Then ew1 = ver3(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver3[(int) (51)];};
 //BA.debugLineNum = 2474;BA.debugLine="If error_level = \"H\" Then ew2 = ver3(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver3[(int) (55)];};
 //BA.debugLineNum = 2476;BA.debugLine="If error_level = \"L\" Then tel2 = ver3(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver3[(int) (76)];};
 //BA.debugLineNum = 2477;BA.debugLine="If error_level = \"M\" Then tel2 = ver3(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver3[(int) (77)];};
 //BA.debugLineNum = 2478;BA.debugLine="If error_level = \"Q\" Then tel2 = ver3(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver3[(int) (78)];};
 //BA.debugLineNum = 2479;BA.debugLine="If error_level = \"H\" Then tel2 = ver3(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver3[(int) (79)];};
 break; }
case 4: {
 //BA.debugLineNum = 2481;BA.debugLine="max_mod = ver4(12)";
_max_mod = _ver4[(int) (12)];
 //BA.debugLineNum = 2482;BA.debugLine="qr_size = ver4(1)";
_qr_size = _ver4[(int) (1)];
 //BA.debugLineNum = 2484;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver4";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver4[(int) (20)];};
 //BA.debugLineNum = 2485;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver4";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver4[(int) (21)];};
 //BA.debugLineNum = 2486;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver4";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver4[(int) (22)];};
 //BA.debugLineNum = 2487;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver4";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver4[(int) (23)];};
 //BA.debugLineNum = 2489;BA.debugLine="If error_level = \"L\" Then block1 = ver4(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver4[(int) (24)];};
 //BA.debugLineNum = 2490;BA.debugLine="If error_level = \"L\" Then block2 = ver4(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver4[(int) (28)];};
 //BA.debugLineNum = 2491;BA.debugLine="If error_level = \"L\" Then dw1 = ver4(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver4[(int) (26)];};
 //BA.debugLineNum = 2492;BA.debugLine="If error_level = \"L\" Then dw2 = ver4(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver4[(int) (30)];};
 //BA.debugLineNum = 2493;BA.debugLine="If error_level = \"L\" Then ew1 = ver4(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver4[(int) (27)];};
 //BA.debugLineNum = 2494;BA.debugLine="If error_level = \"L\" Then ew2 = ver4(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver4[(int) (31)];};
 //BA.debugLineNum = 2496;BA.debugLine="If error_level = \"M\" Then block1 = ver4(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver4[(int) (32)];};
 //BA.debugLineNum = 2497;BA.debugLine="If error_level = \"M\" Then block2 = ver4(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver4[(int) (36)];};
 //BA.debugLineNum = 2498;BA.debugLine="If error_level = \"M\" Then dw1 = ver4(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver4[(int) (34)];};
 //BA.debugLineNum = 2499;BA.debugLine="If error_level = \"M\" Then dw2 = ver4(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver4[(int) (38)];};
 //BA.debugLineNum = 2500;BA.debugLine="If error_level = \"M\" Then ew1 = ver4(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver4[(int) (35)];};
 //BA.debugLineNum = 2501;BA.debugLine="If error_level = \"M\" Then ew2 = ver4(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver4[(int) (39)];};
 //BA.debugLineNum = 2503;BA.debugLine="If error_level = \"Q\" Then block1 = ver4(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver4[(int) (40)];};
 //BA.debugLineNum = 2504;BA.debugLine="If error_level = \"Q\" Then block2 = ver4(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver4[(int) (44)];};
 //BA.debugLineNum = 2505;BA.debugLine="If error_level = \"Q\" Then dw1 = ver4(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver4[(int) (42)];};
 //BA.debugLineNum = 2506;BA.debugLine="If error_level = \"Q\" Then dw2 = ver4(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver4[(int) (46)];};
 //BA.debugLineNum = 2507;BA.debugLine="If error_level = \"Q\" Then ew1 = ver4(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver4[(int) (43)];};
 //BA.debugLineNum = 2508;BA.debugLine="If error_level = \"Q\" Then ew2 = ver4(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver4[(int) (47)];};
 //BA.debugLineNum = 2510;BA.debugLine="If error_level = \"H\" Then block1 = ver4(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver4[(int) (48)];};
 //BA.debugLineNum = 2511;BA.debugLine="If error_level = \"H\" Then block2 = ver4(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver4[(int) (52)];};
 //BA.debugLineNum = 2512;BA.debugLine="If error_level = \"H\" Then dw1 = ver4(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver4[(int) (50)];};
 //BA.debugLineNum = 2513;BA.debugLine="If error_level = \"H\" Then dw2 = ver4(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver4[(int) (54)];};
 //BA.debugLineNum = 2514;BA.debugLine="If error_level = \"H\" Then ew1 = ver4(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver4[(int) (51)];};
 //BA.debugLineNum = 2515;BA.debugLine="If error_level = \"H\" Then ew2 = ver4(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver4[(int) (55)];};
 //BA.debugLineNum = 2517;BA.debugLine="If error_level = \"L\" Then tel2 = ver4(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver4[(int) (76)];};
 //BA.debugLineNum = 2518;BA.debugLine="If error_level = \"M\" Then tel2 = ver4(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver4[(int) (77)];};
 //BA.debugLineNum = 2519;BA.debugLine="If error_level = \"Q\" Then tel2 = ver4(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver4[(int) (78)];};
 //BA.debugLineNum = 2520;BA.debugLine="If error_level = \"H\" Then tel2 = ver4(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver4[(int) (79)];};
 break; }
case 5: {
 //BA.debugLineNum = 2522;BA.debugLine="max_mod = ver5(12)";
_max_mod = _ver5[(int) (12)];
 //BA.debugLineNum = 2523;BA.debugLine="qr_size = ver5(1)";
_qr_size = _ver5[(int) (1)];
 //BA.debugLineNum = 2525;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver5";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver5[(int) (20)];};
 //BA.debugLineNum = 2526;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver5";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver5[(int) (21)];};
 //BA.debugLineNum = 2527;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver5";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver5[(int) (22)];};
 //BA.debugLineNum = 2528;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver5";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver5[(int) (23)];};
 //BA.debugLineNum = 2530;BA.debugLine="If error_level = \"L\" Then block1 = ver5(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver5[(int) (24)];};
 //BA.debugLineNum = 2531;BA.debugLine="If error_level = \"L\" Then block2 = ver5(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver5[(int) (28)];};
 //BA.debugLineNum = 2532;BA.debugLine="If error_level = \"L\" Then dw1 = ver5(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver5[(int) (26)];};
 //BA.debugLineNum = 2533;BA.debugLine="If error_level = \"L\" Then dw2 = ver5(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver5[(int) (30)];};
 //BA.debugLineNum = 2534;BA.debugLine="If error_level = \"L\" Then ew1 = ver5(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver5[(int) (27)];};
 //BA.debugLineNum = 2535;BA.debugLine="If error_level = \"L\" Then ew2 = ver5(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver5[(int) (31)];};
 //BA.debugLineNum = 2537;BA.debugLine="If error_level = \"M\" Then block1 = ver5(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver5[(int) (32)];};
 //BA.debugLineNum = 2538;BA.debugLine="If error_level = \"M\" Then block2 = ver5(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver5[(int) (36)];};
 //BA.debugLineNum = 2539;BA.debugLine="If error_level = \"M\" Then dw1 = ver5(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver5[(int) (34)];};
 //BA.debugLineNum = 2540;BA.debugLine="If error_level = \"M\" Then dw2 = ver5(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver5[(int) (38)];};
 //BA.debugLineNum = 2541;BA.debugLine="If error_level = \"M\" Then ew1 = ver5(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver5[(int) (35)];};
 //BA.debugLineNum = 2542;BA.debugLine="If error_level = \"M\" Then ew2 = ver5(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver5[(int) (39)];};
 //BA.debugLineNum = 2544;BA.debugLine="If error_level = \"Q\" Then block1 = ver5(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver5[(int) (40)];};
 //BA.debugLineNum = 2545;BA.debugLine="If error_level = \"Q\" Then block2 = ver5(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver5[(int) (44)];};
 //BA.debugLineNum = 2546;BA.debugLine="If error_level = \"Q\" Then dw1 = ver5(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver5[(int) (42)];};
 //BA.debugLineNum = 2547;BA.debugLine="If error_level = \"Q\" Then dw2 = ver5(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver5[(int) (46)];};
 //BA.debugLineNum = 2548;BA.debugLine="If error_level = \"Q\" Then ew1 = ver5(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver5[(int) (43)];};
 //BA.debugLineNum = 2549;BA.debugLine="If error_level = \"Q\" Then ew2 = ver5(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver5[(int) (47)];};
 //BA.debugLineNum = 2551;BA.debugLine="If error_level = \"H\" Then block1 = ver5(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver5[(int) (48)];};
 //BA.debugLineNum = 2552;BA.debugLine="If error_level = \"H\" Then block2 = ver5(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver5[(int) (52)];};
 //BA.debugLineNum = 2553;BA.debugLine="If error_level = \"H\" Then dw1 = ver5(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver5[(int) (50)];};
 //BA.debugLineNum = 2554;BA.debugLine="If error_level = \"H\" Then dw2 = ver5(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver5[(int) (54)];};
 //BA.debugLineNum = 2555;BA.debugLine="If error_level = \"H\" Then ew1 = ver5(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver5[(int) (51)];};
 //BA.debugLineNum = 2556;BA.debugLine="If error_level = \"H\" Then ew2 = ver5(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver5[(int) (55)];};
 //BA.debugLineNum = 2558;BA.debugLine="If error_level = \"L\" Then tel2 = ver5(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver5[(int) (76)];};
 //BA.debugLineNum = 2559;BA.debugLine="If error_level = \"M\" Then tel2 = ver5(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver5[(int) (77)];};
 //BA.debugLineNum = 2560;BA.debugLine="If error_level = \"Q\" Then tel2 = ver5(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver5[(int) (78)];};
 //BA.debugLineNum = 2561;BA.debugLine="If error_level = \"H\" Then tel2 = ver5(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver5[(int) (79)];};
 break; }
case 6: {
 //BA.debugLineNum = 2563;BA.debugLine="max_mod = ver6(12)";
_max_mod = _ver6[(int) (12)];
 //BA.debugLineNum = 2564;BA.debugLine="qr_size = ver6(1)";
_qr_size = _ver6[(int) (1)];
 //BA.debugLineNum = 2566;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver6";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver6[(int) (20)];};
 //BA.debugLineNum = 2567;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver6";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver6[(int) (21)];};
 //BA.debugLineNum = 2568;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver6";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver6[(int) (22)];};
 //BA.debugLineNum = 2569;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver6";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver6[(int) (23)];};
 //BA.debugLineNum = 2571;BA.debugLine="If error_level = \"L\" Then block1 = ver6(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver6[(int) (24)];};
 //BA.debugLineNum = 2572;BA.debugLine="If error_level = \"L\" Then block2 = ver6(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver6[(int) (28)];};
 //BA.debugLineNum = 2573;BA.debugLine="If error_level = \"L\" Then dw1 = ver6(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver6[(int) (26)];};
 //BA.debugLineNum = 2574;BA.debugLine="If error_level = \"L\" Then dw2 = ver6(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver6[(int) (30)];};
 //BA.debugLineNum = 2575;BA.debugLine="If error_level = \"L\" Then ew1 = ver6(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver6[(int) (27)];};
 //BA.debugLineNum = 2576;BA.debugLine="If error_level = \"L\" Then ew2 = ver6(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver6[(int) (31)];};
 //BA.debugLineNum = 2578;BA.debugLine="If error_level = \"M\" Then block1 = ver6(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver6[(int) (32)];};
 //BA.debugLineNum = 2579;BA.debugLine="If error_level = \"M\" Then block2 = ver6(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver6[(int) (36)];};
 //BA.debugLineNum = 2580;BA.debugLine="If error_level = \"M\" Then dw1 = ver6(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver6[(int) (34)];};
 //BA.debugLineNum = 2581;BA.debugLine="If error_level = \"M\" Then dw2 = ver6(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver6[(int) (38)];};
 //BA.debugLineNum = 2582;BA.debugLine="If error_level = \"M\" Then ew1 = ver6(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver6[(int) (35)];};
 //BA.debugLineNum = 2583;BA.debugLine="If error_level = \"M\" Then ew2 = ver6(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver6[(int) (39)];};
 //BA.debugLineNum = 2585;BA.debugLine="If error_level = \"Q\" Then block1 = ver6(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver6[(int) (40)];};
 //BA.debugLineNum = 2586;BA.debugLine="If error_level = \"Q\" Then block2 = ver6(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver6[(int) (44)];};
 //BA.debugLineNum = 2587;BA.debugLine="If error_level = \"Q\" Then dw1 = ver6(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver6[(int) (42)];};
 //BA.debugLineNum = 2588;BA.debugLine="If error_level = \"Q\" Then dw2 = ver6(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver6[(int) (46)];};
 //BA.debugLineNum = 2589;BA.debugLine="If error_level = \"Q\" Then ew1 = ver6(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver6[(int) (43)];};
 //BA.debugLineNum = 2590;BA.debugLine="If error_level = \"Q\" Then ew2 = ver6(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver6[(int) (47)];};
 //BA.debugLineNum = 2592;BA.debugLine="If error_level = \"H\" Then block1 = ver6(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver6[(int) (48)];};
 //BA.debugLineNum = 2593;BA.debugLine="If error_level = \"H\" Then block2 = ver6(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver6[(int) (52)];};
 //BA.debugLineNum = 2594;BA.debugLine="If error_level = \"H\" Then dw1 = ver6(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver6[(int) (50)];};
 //BA.debugLineNum = 2595;BA.debugLine="If error_level = \"H\" Then dw2 = ver6(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver6[(int) (54)];};
 //BA.debugLineNum = 2596;BA.debugLine="If error_level = \"H\" Then ew1 = ver6(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver6[(int) (51)];};
 //BA.debugLineNum = 2597;BA.debugLine="If error_level = \"H\" Then ew2 = ver6(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver6[(int) (55)];};
 //BA.debugLineNum = 2599;BA.debugLine="If error_level = \"L\" Then tel2 = ver6(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver6[(int) (76)];};
 //BA.debugLineNum = 2600;BA.debugLine="If error_level = \"M\" Then tel2 = ver6(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver6[(int) (77)];};
 //BA.debugLineNum = 2601;BA.debugLine="If error_level = \"Q\" Then tel2 = ver6(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver6[(int) (78)];};
 //BA.debugLineNum = 2602;BA.debugLine="If error_level = \"H\" Then tel2 = ver6(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver6[(int) (79)];};
 break; }
case 7: {
 //BA.debugLineNum = 2604;BA.debugLine="max_mod = ver7(12)";
_max_mod = _ver7[(int) (12)];
 //BA.debugLineNum = 2605;BA.debugLine="qr_size = ver7(1)";
_qr_size = _ver7[(int) (1)];
 //BA.debugLineNum = 2607;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver7";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver7[(int) (20)];};
 //BA.debugLineNum = 2608;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver7";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver7[(int) (21)];};
 //BA.debugLineNum = 2609;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver7";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver7[(int) (22)];};
 //BA.debugLineNum = 2610;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver7";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver7[(int) (23)];};
 //BA.debugLineNum = 2612;BA.debugLine="If error_level = \"L\" Then block1 = ver7(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver7[(int) (24)];};
 //BA.debugLineNum = 2613;BA.debugLine="If error_level = \"L\" Then block2 = ver7(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver7[(int) (28)];};
 //BA.debugLineNum = 2614;BA.debugLine="If error_level = \"L\" Then dw1 = ver7(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver7[(int) (26)];};
 //BA.debugLineNum = 2615;BA.debugLine="If error_level = \"L\" Then dw2 = ver7(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver7[(int) (30)];};
 //BA.debugLineNum = 2616;BA.debugLine="If error_level = \"L\" Then ew1 = ver7(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver7[(int) (27)];};
 //BA.debugLineNum = 2617;BA.debugLine="If error_level = \"L\" Then ew2 = ver7(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver7[(int) (31)];};
 //BA.debugLineNum = 2619;BA.debugLine="If error_level = \"M\" Then block1 = ver7(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver7[(int) (32)];};
 //BA.debugLineNum = 2620;BA.debugLine="If error_level = \"M\" Then block2 = ver7(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver7[(int) (36)];};
 //BA.debugLineNum = 2621;BA.debugLine="If error_level = \"M\" Then dw1 = ver7(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver7[(int) (34)];};
 //BA.debugLineNum = 2622;BA.debugLine="If error_level = \"M\" Then dw2 = ver7(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver7[(int) (38)];};
 //BA.debugLineNum = 2623;BA.debugLine="If error_level = \"M\" Then ew1 = ver7(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver7[(int) (35)];};
 //BA.debugLineNum = 2624;BA.debugLine="If error_level = \"M\" Then ew2 = ver7(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver7[(int) (39)];};
 //BA.debugLineNum = 2626;BA.debugLine="If error_level = \"Q\" Then block1 = ver7(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver7[(int) (40)];};
 //BA.debugLineNum = 2627;BA.debugLine="If error_level = \"Q\" Then block2 = ver7(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver7[(int) (44)];};
 //BA.debugLineNum = 2628;BA.debugLine="If error_level = \"Q\" Then dw1 = ver7(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver7[(int) (42)];};
 //BA.debugLineNum = 2629;BA.debugLine="If error_level = \"Q\" Then dw2 = ver7(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver7[(int) (46)];};
 //BA.debugLineNum = 2630;BA.debugLine="If error_level = \"Q\" Then ew1 = ver7(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver7[(int) (43)];};
 //BA.debugLineNum = 2631;BA.debugLine="If error_level = \"Q\" Then ew2 = ver7(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver7[(int) (47)];};
 //BA.debugLineNum = 2633;BA.debugLine="If error_level = \"H\" Then block1 = ver7(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver7[(int) (48)];};
 //BA.debugLineNum = 2634;BA.debugLine="If error_level = \"H\" Then block2 = ver7(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver7[(int) (52)];};
 //BA.debugLineNum = 2635;BA.debugLine="If error_level = \"H\" Then dw1 = ver7(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver7[(int) (50)];};
 //BA.debugLineNum = 2636;BA.debugLine="If error_level = \"H\" Then dw2 = ver7(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver7[(int) (54)];};
 //BA.debugLineNum = 2637;BA.debugLine="If error_level = \"H\" Then ew1 = ver7(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver7[(int) (51)];};
 //BA.debugLineNum = 2638;BA.debugLine="If error_level = \"H\" Then ew2 = ver7(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver7[(int) (55)];};
 //BA.debugLineNum = 2640;BA.debugLine="If error_level = \"L\" Then tel2 = ver7(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver7[(int) (76)];};
 //BA.debugLineNum = 2641;BA.debugLine="If error_level = \"M\" Then tel2 = ver7(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver7[(int) (77)];};
 //BA.debugLineNum = 2642;BA.debugLine="If error_level = \"Q\" Then tel2 = ver7(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver7[(int) (78)];};
 //BA.debugLineNum = 2643;BA.debugLine="If error_level = \"H\" Then tel2 = ver7(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver7[(int) (79)];};
 break; }
case 8: {
 //BA.debugLineNum = 2645;BA.debugLine="max_mod = ver8(12)";
_max_mod = _ver8[(int) (12)];
 //BA.debugLineNum = 2646;BA.debugLine="qr_size = ver8(1)";
_qr_size = _ver8[(int) (1)];
 //BA.debugLineNum = 2648;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver8";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver8[(int) (20)];};
 //BA.debugLineNum = 2649;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver8";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver8[(int) (21)];};
 //BA.debugLineNum = 2650;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver8";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver8[(int) (22)];};
 //BA.debugLineNum = 2651;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver8";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver8[(int) (23)];};
 //BA.debugLineNum = 2653;BA.debugLine="If error_level = \"L\" Then block1 = ver8(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver8[(int) (24)];};
 //BA.debugLineNum = 2654;BA.debugLine="If error_level = \"L\" Then block2 = ver8(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver8[(int) (28)];};
 //BA.debugLineNum = 2655;BA.debugLine="If error_level = \"L\" Then dw1 = ver8(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver8[(int) (26)];};
 //BA.debugLineNum = 2656;BA.debugLine="If error_level = \"L\" Then dw2 = ver8(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver8[(int) (30)];};
 //BA.debugLineNum = 2657;BA.debugLine="If error_level = \"L\" Then ew1 = ver8(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver8[(int) (27)];};
 //BA.debugLineNum = 2658;BA.debugLine="If error_level = \"L\" Then ew2 = ver8(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver8[(int) (31)];};
 //BA.debugLineNum = 2660;BA.debugLine="If error_level = \"M\" Then block1 = ver8(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver8[(int) (32)];};
 //BA.debugLineNum = 2661;BA.debugLine="If error_level = \"M\" Then block2 = ver8(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver8[(int) (36)];};
 //BA.debugLineNum = 2662;BA.debugLine="If error_level = \"M\" Then dw1 = ver8(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver8[(int) (34)];};
 //BA.debugLineNum = 2663;BA.debugLine="If error_level = \"M\" Then dw2 = ver8(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver8[(int) (38)];};
 //BA.debugLineNum = 2664;BA.debugLine="If error_level = \"M\" Then ew1 = ver8(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver8[(int) (35)];};
 //BA.debugLineNum = 2665;BA.debugLine="If error_level = \"M\" Then ew2 = ver8(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver8[(int) (39)];};
 //BA.debugLineNum = 2667;BA.debugLine="If error_level = \"Q\" Then block1 = ver8(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver8[(int) (40)];};
 //BA.debugLineNum = 2668;BA.debugLine="If error_level = \"Q\" Then block2 = ver8(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver8[(int) (44)];};
 //BA.debugLineNum = 2669;BA.debugLine="If error_level = \"Q\" Then dw1 = ver8(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver8[(int) (42)];};
 //BA.debugLineNum = 2670;BA.debugLine="If error_level = \"Q\" Then dw2 = ver8(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver8[(int) (46)];};
 //BA.debugLineNum = 2671;BA.debugLine="If error_level = \"Q\" Then ew1 = ver8(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver8[(int) (43)];};
 //BA.debugLineNum = 2672;BA.debugLine="If error_level = \"Q\" Then ew2 = ver8(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver8[(int) (47)];};
 //BA.debugLineNum = 2674;BA.debugLine="If error_level = \"H\" Then block1 = ver8(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver8[(int) (48)];};
 //BA.debugLineNum = 2675;BA.debugLine="If error_level = \"H\" Then block2 = ver8(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver8[(int) (52)];};
 //BA.debugLineNum = 2676;BA.debugLine="If error_level = \"H\" Then dw1 = ver8(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver8[(int) (50)];};
 //BA.debugLineNum = 2677;BA.debugLine="If error_level = \"H\" Then dw2 = ver8(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver8[(int) (54)];};
 //BA.debugLineNum = 2678;BA.debugLine="If error_level = \"H\" Then ew1 = ver8(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver8[(int) (51)];};
 //BA.debugLineNum = 2679;BA.debugLine="If error_level = \"H\" Then ew2 = ver8(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver8[(int) (55)];};
 //BA.debugLineNum = 2681;BA.debugLine="If error_level = \"L\" Then tel2 = ver8(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver8[(int) (76)];};
 //BA.debugLineNum = 2682;BA.debugLine="If error_level = \"M\" Then tel2 = ver8(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver8[(int) (77)];};
 //BA.debugLineNum = 2683;BA.debugLine="If error_level = \"Q\" Then tel2 = ver8(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver8[(int) (78)];};
 //BA.debugLineNum = 2684;BA.debugLine="If error_level = \"H\" Then tel2 = ver8(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver8[(int) (79)];};
 break; }
case 9: {
 //BA.debugLineNum = 2686;BA.debugLine="max_mod = ver9(12)";
_max_mod = _ver9[(int) (12)];
 //BA.debugLineNum = 2687;BA.debugLine="qr_size = ver9(1)";
_qr_size = _ver9[(int) (1)];
 //BA.debugLineNum = 2689;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver9";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver9[(int) (20)];};
 //BA.debugLineNum = 2690;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver9";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver9[(int) (21)];};
 //BA.debugLineNum = 2691;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver9";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver9[(int) (22)];};
 //BA.debugLineNum = 2692;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver9";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver9[(int) (23)];};
 //BA.debugLineNum = 2694;BA.debugLine="If error_level = \"L\" Then block1 = ver9(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver9[(int) (24)];};
 //BA.debugLineNum = 2695;BA.debugLine="If error_level = \"L\" Then block2 = ver9(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver9[(int) (28)];};
 //BA.debugLineNum = 2696;BA.debugLine="If error_level = \"L\" Then dw1 = ver9(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver9[(int) (26)];};
 //BA.debugLineNum = 2697;BA.debugLine="If error_level = \"L\" Then dw2 = ver9(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver9[(int) (30)];};
 //BA.debugLineNum = 2698;BA.debugLine="If error_level = \"L\" Then ew1 = ver9(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver9[(int) (27)];};
 //BA.debugLineNum = 2699;BA.debugLine="If error_level = \"L\" Then ew2 = ver9(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver9[(int) (31)];};
 //BA.debugLineNum = 2701;BA.debugLine="If error_level = \"M\" Then block1 = ver9(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver9[(int) (32)];};
 //BA.debugLineNum = 2702;BA.debugLine="If error_level = \"M\" Then block2 = ver9(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver9[(int) (36)];};
 //BA.debugLineNum = 2703;BA.debugLine="If error_level = \"M\" Then dw1 = ver9(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver9[(int) (34)];};
 //BA.debugLineNum = 2704;BA.debugLine="If error_level = \"M\" Then dw2 = ver9(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver9[(int) (38)];};
 //BA.debugLineNum = 2705;BA.debugLine="If error_level = \"M\" Then ew1 = ver9(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver9[(int) (35)];};
 //BA.debugLineNum = 2706;BA.debugLine="If error_level = \"M\" Then ew2 = ver9(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver9[(int) (39)];};
 //BA.debugLineNum = 2708;BA.debugLine="If error_level = \"Q\" Then block1 = ver9(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver9[(int) (40)];};
 //BA.debugLineNum = 2709;BA.debugLine="If error_level = \"Q\" Then block2 = ver9(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver9[(int) (44)];};
 //BA.debugLineNum = 2710;BA.debugLine="If error_level = \"Q\" Then dw1 = ver9(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver9[(int) (42)];};
 //BA.debugLineNum = 2711;BA.debugLine="If error_level = \"Q\" Then dw2 = ver9(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver9[(int) (46)];};
 //BA.debugLineNum = 2712;BA.debugLine="If error_level = \"Q\" Then ew1 = ver9(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver9[(int) (43)];};
 //BA.debugLineNum = 2713;BA.debugLine="If error_level = \"Q\" Then ew2 = ver9(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver9[(int) (47)];};
 //BA.debugLineNum = 2715;BA.debugLine="If error_level = \"H\" Then block1 = ver9(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver9[(int) (48)];};
 //BA.debugLineNum = 2716;BA.debugLine="If error_level = \"H\" Then block2 = ver9(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver9[(int) (52)];};
 //BA.debugLineNum = 2717;BA.debugLine="If error_level = \"H\" Then dw1 = ver9(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver9[(int) (50)];};
 //BA.debugLineNum = 2718;BA.debugLine="If error_level = \"H\" Then dw2 = ver9(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver9[(int) (54)];};
 //BA.debugLineNum = 2719;BA.debugLine="If error_level = \"H\" Then ew1 = ver9(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver9[(int) (51)];};
 //BA.debugLineNum = 2720;BA.debugLine="If error_level = \"H\" Then ew2 = ver9(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver9[(int) (55)];};
 //BA.debugLineNum = 2722;BA.debugLine="If error_level = \"L\" Then tel2 = ver9(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver9[(int) (76)];};
 //BA.debugLineNum = 2723;BA.debugLine="If error_level = \"M\" Then tel2 = ver9(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver9[(int) (77)];};
 //BA.debugLineNum = 2724;BA.debugLine="If error_level = \"Q\" Then tel2 = ver9(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver9[(int) (78)];};
 //BA.debugLineNum = 2725;BA.debugLine="If error_level = \"H\" Then tel2 = ver9(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver9[(int) (79)];};
 break; }
case 10: {
 //BA.debugLineNum = 2727;BA.debugLine="max_mod = ver10(12)";
_max_mod = _ver10[(int) (12)];
 //BA.debugLineNum = 2728;BA.debugLine="qr_size = ver10(1)";
_qr_size = _ver10[(int) (1)];
 //BA.debugLineNum = 2730;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver1";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver10[(int) (20)];};
 //BA.debugLineNum = 2731;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver1";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver10[(int) (21)];};
 //BA.debugLineNum = 2732;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver1";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver10[(int) (22)];};
 //BA.debugLineNum = 2733;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver1";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver10[(int) (23)];};
 //BA.debugLineNum = 2735;BA.debugLine="If error_level = \"L\" Then block1 = ver10(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver10[(int) (24)];};
 //BA.debugLineNum = 2736;BA.debugLine="If error_level = \"L\" Then block2 = ver10(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver10[(int) (28)];};
 //BA.debugLineNum = 2737;BA.debugLine="If error_level = \"L\" Then dw1 = ver10(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver10[(int) (26)];};
 //BA.debugLineNum = 2738;BA.debugLine="If error_level = \"L\" Then dw2 = ver10(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver10[(int) (30)];};
 //BA.debugLineNum = 2739;BA.debugLine="If error_level = \"L\" Then ew1 = ver10(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver10[(int) (27)];};
 //BA.debugLineNum = 2740;BA.debugLine="If error_level = \"L\" Then ew2 = ver10(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver10[(int) (31)];};
 //BA.debugLineNum = 2742;BA.debugLine="If error_level = \"M\" Then block1 = ver10(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver10[(int) (32)];};
 //BA.debugLineNum = 2743;BA.debugLine="If error_level = \"M\" Then block2 = ver10(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver10[(int) (36)];};
 //BA.debugLineNum = 2744;BA.debugLine="If error_level = \"M\" Then dw1 = ver10(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver10[(int) (34)];};
 //BA.debugLineNum = 2745;BA.debugLine="If error_level = \"M\" Then dw2 = ver10(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver10[(int) (38)];};
 //BA.debugLineNum = 2746;BA.debugLine="If error_level = \"M\" Then ew1 = ver10(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver10[(int) (35)];};
 //BA.debugLineNum = 2747;BA.debugLine="If error_level = \"M\" Then ew2 = ver10(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver10[(int) (39)];};
 //BA.debugLineNum = 2749;BA.debugLine="If error_level = \"Q\" Then block1 = ver10(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver10[(int) (40)];};
 //BA.debugLineNum = 2750;BA.debugLine="If error_level = \"Q\" Then block2 = ver10(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver10[(int) (44)];};
 //BA.debugLineNum = 2751;BA.debugLine="If error_level = \"Q\" Then dw1 = ver10(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver10[(int) (42)];};
 //BA.debugLineNum = 2752;BA.debugLine="If error_level = \"Q\" Then dw2 = ver10(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver10[(int) (46)];};
 //BA.debugLineNum = 2753;BA.debugLine="If error_level = \"Q\" Then ew1 = ver10(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver10[(int) (43)];};
 //BA.debugLineNum = 2754;BA.debugLine="If error_level = \"Q\" Then ew2 = ver10(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver10[(int) (47)];};
 //BA.debugLineNum = 2756;BA.debugLine="If error_level = \"H\" Then block1 = ver10(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver10[(int) (48)];};
 //BA.debugLineNum = 2757;BA.debugLine="If error_level = \"H\" Then block2 = ver10(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver10[(int) (52)];};
 //BA.debugLineNum = 2758;BA.debugLine="If error_level = \"H\" Then dw1 = ver10(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver10[(int) (50)];};
 //BA.debugLineNum = 2759;BA.debugLine="If error_level = \"H\" Then dw2 = ver10(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver10[(int) (54)];};
 //BA.debugLineNum = 2760;BA.debugLine="If error_level = \"H\" Then ew1 = ver10(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver10[(int) (51)];};
 //BA.debugLineNum = 2761;BA.debugLine="If error_level = \"H\" Then ew2 = ver10(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver10[(int) (55)];};
 //BA.debugLineNum = 2763;BA.debugLine="If error_level = \"L\" Then tel2 = ver10(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver10[(int) (76)];};
 //BA.debugLineNum = 2764;BA.debugLine="If error_level = \"M\" Then tel2 = ver10(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver10[(int) (77)];};
 //BA.debugLineNum = 2765;BA.debugLine="If error_level = \"Q\" Then tel2 = ver10(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver10[(int) (78)];};
 //BA.debugLineNum = 2766;BA.debugLine="If error_level = \"H\" Then tel2 = ver10(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver10[(int) (79)];};
 break; }
case 11: {
 //BA.debugLineNum = 2768;BA.debugLine="max_mod = ver11(12)";
_max_mod = _ver11[(int) (12)];
 //BA.debugLineNum = 2769;BA.debugLine="qr_size = ver11(1)";
_qr_size = _ver11[(int) (1)];
 //BA.debugLineNum = 2771;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver1";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver11[(int) (20)];};
 //BA.debugLineNum = 2772;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver1";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver11[(int) (21)];};
 //BA.debugLineNum = 2773;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver1";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver11[(int) (22)];};
 //BA.debugLineNum = 2774;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver1";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver11[(int) (23)];};
 //BA.debugLineNum = 2776;BA.debugLine="If error_level = \"L\" Then block1 = ver11(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver11[(int) (24)];};
 //BA.debugLineNum = 2777;BA.debugLine="If error_level = \"L\" Then block2 = ver11(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver11[(int) (28)];};
 //BA.debugLineNum = 2778;BA.debugLine="If error_level = \"L\" Then dw1 = ver11(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver11[(int) (26)];};
 //BA.debugLineNum = 2779;BA.debugLine="If error_level = \"L\" Then dw2 = ver11(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver11[(int) (30)];};
 //BA.debugLineNum = 2780;BA.debugLine="If error_level = \"L\" Then ew1 = ver11(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver11[(int) (27)];};
 //BA.debugLineNum = 2781;BA.debugLine="If error_level = \"L\" Then ew2 = ver11(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver11[(int) (31)];};
 //BA.debugLineNum = 2783;BA.debugLine="If error_level = \"M\" Then block1 = ver11(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver11[(int) (32)];};
 //BA.debugLineNum = 2784;BA.debugLine="If error_level = \"M\" Then block2 = ver11(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver11[(int) (36)];};
 //BA.debugLineNum = 2785;BA.debugLine="If error_level = \"M\" Then dw1 = ver11(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver11[(int) (34)];};
 //BA.debugLineNum = 2786;BA.debugLine="If error_level = \"M\" Then dw2 = ver11(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver11[(int) (38)];};
 //BA.debugLineNum = 2787;BA.debugLine="If error_level = \"M\" Then ew1 = ver11(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver11[(int) (35)];};
 //BA.debugLineNum = 2788;BA.debugLine="If error_level = \"M\" Then ew2 = ver11(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver11[(int) (39)];};
 //BA.debugLineNum = 2790;BA.debugLine="If error_level = \"Q\" Then block1 = ver11(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver11[(int) (40)];};
 //BA.debugLineNum = 2791;BA.debugLine="If error_level = \"Q\" Then block2 = ver11(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver11[(int) (44)];};
 //BA.debugLineNum = 2792;BA.debugLine="If error_level = \"Q\" Then dw1 = ver11(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver11[(int) (42)];};
 //BA.debugLineNum = 2793;BA.debugLine="If error_level = \"Q\" Then dw2 = ver11(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver11[(int) (46)];};
 //BA.debugLineNum = 2794;BA.debugLine="If error_level = \"Q\" Then ew1 = ver11(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver11[(int) (43)];};
 //BA.debugLineNum = 2795;BA.debugLine="If error_level = \"Q\" Then ew2 = ver11(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver11[(int) (47)];};
 //BA.debugLineNum = 2797;BA.debugLine="If error_level = \"H\" Then block1 = ver11(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver11[(int) (48)];};
 //BA.debugLineNum = 2798;BA.debugLine="If error_level = \"H\" Then block2 = ver11(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver11[(int) (52)];};
 //BA.debugLineNum = 2799;BA.debugLine="If error_level = \"H\" Then dw1 = ver11(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver11[(int) (50)];};
 //BA.debugLineNum = 2800;BA.debugLine="If error_level = \"H\" Then dw2 = ver11(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver11[(int) (54)];};
 //BA.debugLineNum = 2801;BA.debugLine="If error_level = \"H\" Then ew1 = ver11(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver11[(int) (51)];};
 //BA.debugLineNum = 2802;BA.debugLine="If error_level = \"H\" Then ew2 = ver11(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver11[(int) (55)];};
 //BA.debugLineNum = 2804;BA.debugLine="If error_level = \"L\" Then tel2 = ver11(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver11[(int) (76)];};
 //BA.debugLineNum = 2805;BA.debugLine="If error_level = \"M\" Then tel2 = ver11(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver11[(int) (77)];};
 //BA.debugLineNum = 2806;BA.debugLine="If error_level = \"Q\" Then tel2 = ver11(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver11[(int) (78)];};
 //BA.debugLineNum = 2807;BA.debugLine="If error_level = \"H\" Then tel2 = ver11(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver11[(int) (79)];};
 break; }
case 12: {
 //BA.debugLineNum = 2809;BA.debugLine="max_mod = ver12(12)";
_max_mod = _ver12[(int) (12)];
 //BA.debugLineNum = 2810;BA.debugLine="qr_size = ver12(1)";
_qr_size = _ver12[(int) (1)];
 //BA.debugLineNum = 2812;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver1";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver12[(int) (20)];};
 //BA.debugLineNum = 2813;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver1";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver12[(int) (21)];};
 //BA.debugLineNum = 2814;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver1";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver12[(int) (22)];};
 //BA.debugLineNum = 2815;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver1";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver12[(int) (23)];};
 //BA.debugLineNum = 2817;BA.debugLine="If error_level = \"L\" Then block1 = ver12(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver12[(int) (24)];};
 //BA.debugLineNum = 2818;BA.debugLine="If error_level = \"L\" Then block2 = ver12(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver12[(int) (28)];};
 //BA.debugLineNum = 2819;BA.debugLine="If error_level = \"L\" Then dw1 = ver12(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver12[(int) (26)];};
 //BA.debugLineNum = 2820;BA.debugLine="If error_level = \"L\" Then dw2 = ver12(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver12[(int) (30)];};
 //BA.debugLineNum = 2821;BA.debugLine="If error_level = \"L\" Then ew1 = ver12(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver12[(int) (27)];};
 //BA.debugLineNum = 2822;BA.debugLine="If error_level = \"L\" Then ew2 = ver12(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver12[(int) (31)];};
 //BA.debugLineNum = 2824;BA.debugLine="If error_level = \"M\" Then block1 = ver12(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver12[(int) (32)];};
 //BA.debugLineNum = 2825;BA.debugLine="If error_level = \"M\" Then block2 = ver12(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver12[(int) (36)];};
 //BA.debugLineNum = 2826;BA.debugLine="If error_level = \"M\" Then dw1 = ver12(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver12[(int) (34)];};
 //BA.debugLineNum = 2827;BA.debugLine="If error_level = \"M\" Then dw2 = ver12(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver12[(int) (38)];};
 //BA.debugLineNum = 2828;BA.debugLine="If error_level = \"M\" Then ew1 = ver12(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver12[(int) (35)];};
 //BA.debugLineNum = 2829;BA.debugLine="If error_level = \"M\" Then ew2 = ver12(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver12[(int) (39)];};
 //BA.debugLineNum = 2831;BA.debugLine="If error_level = \"Q\" Then block1 = ver12(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver12[(int) (40)];};
 //BA.debugLineNum = 2832;BA.debugLine="If error_level = \"Q\" Then block2 = ver12(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver12[(int) (44)];};
 //BA.debugLineNum = 2833;BA.debugLine="If error_level = \"Q\" Then dw1 = ver12(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver12[(int) (42)];};
 //BA.debugLineNum = 2834;BA.debugLine="If error_level = \"Q\" Then dw2 = ver12(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver12[(int) (46)];};
 //BA.debugLineNum = 2835;BA.debugLine="If error_level = \"Q\" Then ew1 = ver12(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver12[(int) (43)];};
 //BA.debugLineNum = 2836;BA.debugLine="If error_level = \"Q\" Then ew2 = ver12(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver12[(int) (47)];};
 //BA.debugLineNum = 2838;BA.debugLine="If error_level = \"H\" Then block1 = ver12(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver12[(int) (48)];};
 //BA.debugLineNum = 2839;BA.debugLine="If error_level = \"H\" Then block2 = ver12(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver12[(int) (52)];};
 //BA.debugLineNum = 2840;BA.debugLine="If error_level = \"H\" Then dw1 = ver12(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver12[(int) (50)];};
 //BA.debugLineNum = 2841;BA.debugLine="If error_level = \"H\" Then dw2 = ver12(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver12[(int) (54)];};
 //BA.debugLineNum = 2842;BA.debugLine="If error_level = \"H\" Then ew1 = ver12(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver12[(int) (51)];};
 //BA.debugLineNum = 2843;BA.debugLine="If error_level = \"H\" Then ew2 = ver12(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver12[(int) (55)];};
 //BA.debugLineNum = 2845;BA.debugLine="If error_level = \"L\" Then tel2 = ver12(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver12[(int) (76)];};
 //BA.debugLineNum = 2846;BA.debugLine="If error_level = \"M\" Then tel2 = ver12(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver12[(int) (77)];};
 //BA.debugLineNum = 2847;BA.debugLine="If error_level = \"Q\" Then tel2 = ver12(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver12[(int) (78)];};
 //BA.debugLineNum = 2848;BA.debugLine="If error_level = \"H\" Then tel2 = ver12(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver12[(int) (79)];};
 break; }
case 13: {
 //BA.debugLineNum = 2850;BA.debugLine="max_mod = ver13(12)";
_max_mod = _ver13[(int) (12)];
 //BA.debugLineNum = 2851;BA.debugLine="qr_size = ver13(1)";
_qr_size = _ver13[(int) (1)];
 //BA.debugLineNum = 2853;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver1";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver13[(int) (20)];};
 //BA.debugLineNum = 2854;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver1";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver13[(int) (21)];};
 //BA.debugLineNum = 2855;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver1";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver13[(int) (22)];};
 //BA.debugLineNum = 2856;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver1";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver13[(int) (23)];};
 //BA.debugLineNum = 2858;BA.debugLine="If error_level = \"L\" Then block1 = ver13(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver13[(int) (24)];};
 //BA.debugLineNum = 2859;BA.debugLine="If error_level = \"L\" Then block2 = ver13(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver13[(int) (28)];};
 //BA.debugLineNum = 2860;BA.debugLine="If error_level = \"L\" Then dw1 = ver13(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver13[(int) (26)];};
 //BA.debugLineNum = 2861;BA.debugLine="If error_level = \"L\" Then dw2 = ver13(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver13[(int) (30)];};
 //BA.debugLineNum = 2862;BA.debugLine="If error_level = \"L\" Then ew1 = ver13(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver13[(int) (27)];};
 //BA.debugLineNum = 2863;BA.debugLine="If error_level = \"L\" Then ew2 = ver13(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver13[(int) (31)];};
 //BA.debugLineNum = 2865;BA.debugLine="If error_level = \"M\" Then block1 = ver13(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver13[(int) (32)];};
 //BA.debugLineNum = 2866;BA.debugLine="If error_level = \"M\" Then block2 = ver13(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver13[(int) (36)];};
 //BA.debugLineNum = 2867;BA.debugLine="If error_level = \"M\" Then dw1 = ver13(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver13[(int) (34)];};
 //BA.debugLineNum = 2868;BA.debugLine="If error_level = \"M\" Then dw2 = ver13(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver13[(int) (38)];};
 //BA.debugLineNum = 2869;BA.debugLine="If error_level = \"M\" Then ew1 = ver13(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver13[(int) (35)];};
 //BA.debugLineNum = 2870;BA.debugLine="If error_level = \"M\" Then ew2 = ver13(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver13[(int) (39)];};
 //BA.debugLineNum = 2872;BA.debugLine="If error_level = \"Q\" Then block1 = ver13(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver13[(int) (40)];};
 //BA.debugLineNum = 2873;BA.debugLine="If error_level = \"Q\" Then block2 = ver13(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver13[(int) (44)];};
 //BA.debugLineNum = 2874;BA.debugLine="If error_level = \"Q\" Then dw1 = ver13(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver13[(int) (42)];};
 //BA.debugLineNum = 2875;BA.debugLine="If error_level = \"Q\" Then dw2 = ver13(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver13[(int) (46)];};
 //BA.debugLineNum = 2876;BA.debugLine="If error_level = \"Q\" Then ew1 = ver13(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver13[(int) (43)];};
 //BA.debugLineNum = 2877;BA.debugLine="If error_level = \"Q\" Then ew2 = ver13(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver13[(int) (47)];};
 //BA.debugLineNum = 2879;BA.debugLine="If error_level = \"H\" Then block1 = ver13(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver13[(int) (48)];};
 //BA.debugLineNum = 2880;BA.debugLine="If error_level = \"H\" Then block2 = ver13(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver13[(int) (52)];};
 //BA.debugLineNum = 2881;BA.debugLine="If error_level = \"H\" Then dw1 = ver13(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver13[(int) (50)];};
 //BA.debugLineNum = 2882;BA.debugLine="If error_level = \"H\" Then dw2 = ver13(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver13[(int) (54)];};
 //BA.debugLineNum = 2883;BA.debugLine="If error_level = \"H\" Then ew1 = ver13(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver13[(int) (51)];};
 //BA.debugLineNum = 2884;BA.debugLine="If error_level = \"H\" Then ew2 = ver13(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver13[(int) (55)];};
 //BA.debugLineNum = 2886;BA.debugLine="If error_level = \"L\" Then tel2 = ver13(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver13[(int) (76)];};
 //BA.debugLineNum = 2887;BA.debugLine="If error_level = \"M\" Then tel2 = ver13(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver13[(int) (77)];};
 //BA.debugLineNum = 2888;BA.debugLine="If error_level = \"Q\" Then tel2 = ver13(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver13[(int) (78)];};
 //BA.debugLineNum = 2889;BA.debugLine="If error_level = \"H\" Then tel2 = ver13(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver13[(int) (79)];};
 break; }
case 14: {
 //BA.debugLineNum = 2891;BA.debugLine="max_mod = ver14(12)";
_max_mod = _ver14[(int) (12)];
 //BA.debugLineNum = 2892;BA.debugLine="qr_size = ver14(1)";
_qr_size = _ver14[(int) (1)];
 //BA.debugLineNum = 2894;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver1";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver14[(int) (20)];};
 //BA.debugLineNum = 2895;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver1";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver14[(int) (21)];};
 //BA.debugLineNum = 2896;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver1";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver14[(int) (22)];};
 //BA.debugLineNum = 2897;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver1";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver14[(int) (23)];};
 //BA.debugLineNum = 2899;BA.debugLine="If error_level = \"L\" Then block1 = ver14(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver14[(int) (24)];};
 //BA.debugLineNum = 2900;BA.debugLine="If error_level = \"L\" Then block2 = ver14(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver14[(int) (28)];};
 //BA.debugLineNum = 2901;BA.debugLine="If error_level = \"L\" Then dw1 = ver14(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver14[(int) (26)];};
 //BA.debugLineNum = 2902;BA.debugLine="If error_level = \"L\" Then dw2 = ver14(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver14[(int) (30)];};
 //BA.debugLineNum = 2903;BA.debugLine="If error_level = \"L\" Then ew1 = ver14(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver14[(int) (27)];};
 //BA.debugLineNum = 2904;BA.debugLine="If error_level = \"L\" Then ew2 = ver14(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver14[(int) (31)];};
 //BA.debugLineNum = 2906;BA.debugLine="If error_level = \"M\" Then block1 = ver14(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver14[(int) (32)];};
 //BA.debugLineNum = 2907;BA.debugLine="If error_level = \"M\" Then block2 = ver14(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver14[(int) (36)];};
 //BA.debugLineNum = 2908;BA.debugLine="If error_level = \"M\" Then dw1 = ver14(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver14[(int) (34)];};
 //BA.debugLineNum = 2909;BA.debugLine="If error_level = \"M\" Then dw2 = ver14(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver14[(int) (38)];};
 //BA.debugLineNum = 2910;BA.debugLine="If error_level = \"M\" Then ew1 = ver14(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver14[(int) (35)];};
 //BA.debugLineNum = 2911;BA.debugLine="If error_level = \"M\" Then ew2 = ver14(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver14[(int) (39)];};
 //BA.debugLineNum = 2913;BA.debugLine="If error_level = \"Q\" Then block1 = ver14(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver14[(int) (40)];};
 //BA.debugLineNum = 2914;BA.debugLine="If error_level = \"Q\" Then block2 = ver14(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver14[(int) (44)];};
 //BA.debugLineNum = 2915;BA.debugLine="If error_level = \"Q\" Then dw1 = ver14(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver14[(int) (42)];};
 //BA.debugLineNum = 2916;BA.debugLine="If error_level = \"Q\" Then dw2 = ver14(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver14[(int) (46)];};
 //BA.debugLineNum = 2917;BA.debugLine="If error_level = \"Q\" Then ew1 = ver14(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver14[(int) (43)];};
 //BA.debugLineNum = 2918;BA.debugLine="If error_level = \"Q\" Then ew2 = ver14(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver14[(int) (47)];};
 //BA.debugLineNum = 2920;BA.debugLine="If error_level = \"H\" Then block1 = ver14(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver14[(int) (48)];};
 //BA.debugLineNum = 2921;BA.debugLine="If error_level = \"H\" Then block2 = ver14(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver14[(int) (52)];};
 //BA.debugLineNum = 2922;BA.debugLine="If error_level = \"H\" Then dw1 = ver14(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver14[(int) (50)];};
 //BA.debugLineNum = 2923;BA.debugLine="If error_level = \"H\" Then dw2 = ver14(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver14[(int) (54)];};
 //BA.debugLineNum = 2924;BA.debugLine="If error_level = \"H\" Then ew1 = ver14(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver14[(int) (51)];};
 //BA.debugLineNum = 2925;BA.debugLine="If error_level = \"H\" Then ew2 = ver14(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver14[(int) (55)];};
 //BA.debugLineNum = 2927;BA.debugLine="If error_level = \"L\" Then tel2 = ver14(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver14[(int) (76)];};
 //BA.debugLineNum = 2928;BA.debugLine="If error_level = \"M\" Then tel2 = ver14(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver14[(int) (77)];};
 //BA.debugLineNum = 2929;BA.debugLine="If error_level = \"Q\" Then tel2 = ver14(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver14[(int) (78)];};
 //BA.debugLineNum = 2930;BA.debugLine="If error_level = \"H\" Then tel2 = ver14(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver14[(int) (79)];};
 break; }
case 15: {
 //BA.debugLineNum = 2932;BA.debugLine="max_mod = ver15(12)";
_max_mod = _ver15[(int) (12)];
 //BA.debugLineNum = 2933;BA.debugLine="qr_size = ver15(1)";
_qr_size = _ver15[(int) (1)];
 //BA.debugLineNum = 2935;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver1";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver15[(int) (20)];};
 //BA.debugLineNum = 2936;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver1";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver15[(int) (21)];};
 //BA.debugLineNum = 2937;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver1";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver15[(int) (22)];};
 //BA.debugLineNum = 2938;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver1";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver15[(int) (23)];};
 //BA.debugLineNum = 2940;BA.debugLine="If error_level = \"L\" Then block1 = ver15(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver15[(int) (24)];};
 //BA.debugLineNum = 2941;BA.debugLine="If error_level = \"L\" Then block2 = ver15(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver15[(int) (28)];};
 //BA.debugLineNum = 2942;BA.debugLine="If error_level = \"L\" Then dw1 = ver15(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver15[(int) (26)];};
 //BA.debugLineNum = 2943;BA.debugLine="If error_level = \"L\" Then dw2 = ver15(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver15[(int) (30)];};
 //BA.debugLineNum = 2944;BA.debugLine="If error_level = \"L\" Then ew1 = ver15(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver15[(int) (27)];};
 //BA.debugLineNum = 2945;BA.debugLine="If error_level = \"L\" Then ew2 = ver15(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver15[(int) (31)];};
 //BA.debugLineNum = 2947;BA.debugLine="If error_level = \"M\" Then block1 = ver15(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver15[(int) (32)];};
 //BA.debugLineNum = 2948;BA.debugLine="If error_level = \"M\" Then block2 = ver15(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver15[(int) (36)];};
 //BA.debugLineNum = 2949;BA.debugLine="If error_level = \"M\" Then dw1 = ver15(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver15[(int) (34)];};
 //BA.debugLineNum = 2950;BA.debugLine="If error_level = \"M\" Then dw2 = ver15(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver15[(int) (38)];};
 //BA.debugLineNum = 2951;BA.debugLine="If error_level = \"M\" Then ew1 = ver15(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver15[(int) (35)];};
 //BA.debugLineNum = 2952;BA.debugLine="If error_level = \"M\" Then ew2 = ver15(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver15[(int) (39)];};
 //BA.debugLineNum = 2954;BA.debugLine="If error_level = \"Q\" Then block1 = ver15(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver15[(int) (40)];};
 //BA.debugLineNum = 2955;BA.debugLine="If error_level = \"Q\" Then block2 = ver15(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver15[(int) (44)];};
 //BA.debugLineNum = 2956;BA.debugLine="If error_level = \"Q\" Then dw1 = ver15(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver15[(int) (42)];};
 //BA.debugLineNum = 2957;BA.debugLine="If error_level = \"Q\" Then dw2 = ver15(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver15[(int) (46)];};
 //BA.debugLineNum = 2958;BA.debugLine="If error_level = \"Q\" Then ew1 = ver15(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver15[(int) (43)];};
 //BA.debugLineNum = 2959;BA.debugLine="If error_level = \"Q\" Then ew2 = ver15(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver15[(int) (47)];};
 //BA.debugLineNum = 2961;BA.debugLine="If error_level = \"H\" Then block1 = ver15(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver15[(int) (48)];};
 //BA.debugLineNum = 2962;BA.debugLine="If error_level = \"H\" Then block2 = ver15(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver15[(int) (52)];};
 //BA.debugLineNum = 2963;BA.debugLine="If error_level = \"H\" Then dw1 = ver15(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver15[(int) (50)];};
 //BA.debugLineNum = 2964;BA.debugLine="If error_level = \"H\" Then dw2 = ver15(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver15[(int) (54)];};
 //BA.debugLineNum = 2965;BA.debugLine="If error_level = \"H\" Then ew1 = ver15(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver15[(int) (51)];};
 //BA.debugLineNum = 2966;BA.debugLine="If error_level = \"H\" Then ew2 = ver15(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver15[(int) (55)];};
 //BA.debugLineNum = 2968;BA.debugLine="If error_level = \"L\" Then tel2 = ver15(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver15[(int) (76)];};
 //BA.debugLineNum = 2969;BA.debugLine="If error_level = \"M\" Then tel2 = ver15(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver15[(int) (77)];};
 //BA.debugLineNum = 2970;BA.debugLine="If error_level = \"Q\" Then tel2 = ver15(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver15[(int) (78)];};
 //BA.debugLineNum = 2971;BA.debugLine="If error_level = \"H\" Then tel2 = ver15(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver15[(int) (79)];};
 break; }
case 16: {
 //BA.debugLineNum = 2973;BA.debugLine="max_mod = ver16(12)";
_max_mod = _ver16[(int) (12)];
 //BA.debugLineNum = 2974;BA.debugLine="qr_size = ver16(1)";
_qr_size = _ver16[(int) (1)];
 //BA.debugLineNum = 2976;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver1";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver16[(int) (20)];};
 //BA.debugLineNum = 2977;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver1";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver16[(int) (21)];};
 //BA.debugLineNum = 2978;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver1";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver16[(int) (22)];};
 //BA.debugLineNum = 2979;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver1";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver16[(int) (23)];};
 //BA.debugLineNum = 2981;BA.debugLine="If error_level = \"L\" Then block1 = ver16(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver16[(int) (24)];};
 //BA.debugLineNum = 2982;BA.debugLine="If error_level = \"L\" Then block2 = ver16(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver16[(int) (28)];};
 //BA.debugLineNum = 2983;BA.debugLine="If error_level = \"L\" Then dw1 = ver16(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver16[(int) (26)];};
 //BA.debugLineNum = 2984;BA.debugLine="If error_level = \"L\" Then dw2 = ver16(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver16[(int) (30)];};
 //BA.debugLineNum = 2985;BA.debugLine="If error_level = \"L\" Then ew1 = ver16(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver16[(int) (27)];};
 //BA.debugLineNum = 2986;BA.debugLine="If error_level = \"L\" Then ew2 = ver16(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver16[(int) (31)];};
 //BA.debugLineNum = 2988;BA.debugLine="If error_level = \"M\" Then block1 = ver16(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver16[(int) (32)];};
 //BA.debugLineNum = 2989;BA.debugLine="If error_level = \"M\" Then block2 = ver16(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver16[(int) (36)];};
 //BA.debugLineNum = 2990;BA.debugLine="If error_level = \"M\" Then dw1 = ver16(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver16[(int) (34)];};
 //BA.debugLineNum = 2991;BA.debugLine="If error_level = \"M\" Then dw2 = ver16(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver16[(int) (38)];};
 //BA.debugLineNum = 2992;BA.debugLine="If error_level = \"M\" Then ew1 = ver16(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver16[(int) (35)];};
 //BA.debugLineNum = 2993;BA.debugLine="If error_level = \"M\" Then ew2 = ver16(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver16[(int) (39)];};
 //BA.debugLineNum = 2995;BA.debugLine="If error_level = \"Q\" Then block1 = ver16(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver16[(int) (40)];};
 //BA.debugLineNum = 2996;BA.debugLine="If error_level = \"Q\" Then block2 = ver16(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver16[(int) (44)];};
 //BA.debugLineNum = 2997;BA.debugLine="If error_level = \"Q\" Then dw1 = ver16(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver16[(int) (42)];};
 //BA.debugLineNum = 2998;BA.debugLine="If error_level = \"Q\" Then dw2 = ver16(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver16[(int) (46)];};
 //BA.debugLineNum = 2999;BA.debugLine="If error_level = \"Q\" Then ew1 = ver16(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver16[(int) (43)];};
 //BA.debugLineNum = 3000;BA.debugLine="If error_level = \"Q\" Then ew2 = ver16(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver16[(int) (47)];};
 //BA.debugLineNum = 3002;BA.debugLine="If error_level = \"H\" Then block1 = ver16(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver16[(int) (48)];};
 //BA.debugLineNum = 3003;BA.debugLine="If error_level = \"H\" Then block2 = ver16(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver16[(int) (52)];};
 //BA.debugLineNum = 3004;BA.debugLine="If error_level = \"H\" Then dw1 = ver16(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver16[(int) (50)];};
 //BA.debugLineNum = 3005;BA.debugLine="If error_level = \"H\" Then dw2 = ver16(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver16[(int) (54)];};
 //BA.debugLineNum = 3006;BA.debugLine="If error_level = \"H\" Then ew1 = ver16(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver16[(int) (51)];};
 //BA.debugLineNum = 3007;BA.debugLine="If error_level = \"H\" Then ew2 = ver16(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver16[(int) (55)];};
 //BA.debugLineNum = 3009;BA.debugLine="If error_level = \"L\" Then tel2 = ver16(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver16[(int) (76)];};
 //BA.debugLineNum = 3010;BA.debugLine="If error_level = \"M\" Then tel2 = ver16(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver16[(int) (77)];};
 //BA.debugLineNum = 3011;BA.debugLine="If error_level = \"Q\" Then tel2 = ver16(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver16[(int) (78)];};
 //BA.debugLineNum = 3012;BA.debugLine="If error_level = \"H\" Then tel2 = ver16(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver16[(int) (79)];};
 break; }
case 17: {
 //BA.debugLineNum = 3014;BA.debugLine="max_mod = ver17(12)";
_max_mod = _ver17[(int) (12)];
 //BA.debugLineNum = 3015;BA.debugLine="qr_size = ver17(1)";
_qr_size = _ver17[(int) (1)];
 //BA.debugLineNum = 3017;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver1";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver17[(int) (20)];};
 //BA.debugLineNum = 3018;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver1";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver17[(int) (21)];};
 //BA.debugLineNum = 3019;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver1";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver17[(int) (22)];};
 //BA.debugLineNum = 3020;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver1";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver17[(int) (23)];};
 //BA.debugLineNum = 3022;BA.debugLine="If error_level = \"L\" Then block1 = ver17(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver17[(int) (24)];};
 //BA.debugLineNum = 3023;BA.debugLine="If error_level = \"L\" Then block2 = ver17(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver17[(int) (28)];};
 //BA.debugLineNum = 3024;BA.debugLine="If error_level = \"L\" Then dw1 = ver17(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver17[(int) (26)];};
 //BA.debugLineNum = 3025;BA.debugLine="If error_level = \"L\" Then dw2 = ver17(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver17[(int) (30)];};
 //BA.debugLineNum = 3026;BA.debugLine="If error_level = \"L\" Then ew1 = ver17(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver17[(int) (27)];};
 //BA.debugLineNum = 3027;BA.debugLine="If error_level = \"L\" Then ew2 = ver17(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver17[(int) (31)];};
 //BA.debugLineNum = 3029;BA.debugLine="If error_level = \"M\" Then block1 = ver17(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver17[(int) (32)];};
 //BA.debugLineNum = 3030;BA.debugLine="If error_level = \"M\" Then block2 = ver17(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver17[(int) (36)];};
 //BA.debugLineNum = 3031;BA.debugLine="If error_level = \"M\" Then dw1 = ver17(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver17[(int) (34)];};
 //BA.debugLineNum = 3032;BA.debugLine="If error_level = \"M\" Then dw2 = ver17(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver17[(int) (38)];};
 //BA.debugLineNum = 3033;BA.debugLine="If error_level = \"M\" Then ew1 = ver17(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver17[(int) (35)];};
 //BA.debugLineNum = 3034;BA.debugLine="If error_level = \"M\" Then ew2 = ver17(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver17[(int) (39)];};
 //BA.debugLineNum = 3036;BA.debugLine="If error_level = \"Q\" Then block1 = ver17(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver17[(int) (40)];};
 //BA.debugLineNum = 3037;BA.debugLine="If error_level = \"Q\" Then block2 = ver17(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver17[(int) (44)];};
 //BA.debugLineNum = 3038;BA.debugLine="If error_level = \"Q\" Then dw1 = ver17(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver17[(int) (42)];};
 //BA.debugLineNum = 3039;BA.debugLine="If error_level = \"Q\" Then dw2 = ver17(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver17[(int) (46)];};
 //BA.debugLineNum = 3040;BA.debugLine="If error_level = \"Q\" Then ew1 = ver17(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver17[(int) (43)];};
 //BA.debugLineNum = 3041;BA.debugLine="If error_level = \"Q\" Then ew2 = ver17(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver17[(int) (47)];};
 //BA.debugLineNum = 3043;BA.debugLine="If error_level = \"H\" Then block1 = ver17(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver17[(int) (48)];};
 //BA.debugLineNum = 3044;BA.debugLine="If error_level = \"H\" Then block2 = ver17(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver17[(int) (52)];};
 //BA.debugLineNum = 3045;BA.debugLine="If error_level = \"H\" Then dw1 = ver17(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver17[(int) (50)];};
 //BA.debugLineNum = 3046;BA.debugLine="If error_level = \"H\" Then dw2 = ver17(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver17[(int) (54)];};
 //BA.debugLineNum = 3047;BA.debugLine="If error_level = \"H\" Then ew1 = ver17(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver17[(int) (51)];};
 //BA.debugLineNum = 3048;BA.debugLine="If error_level = \"H\" Then ew2 = ver17(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver17[(int) (55)];};
 //BA.debugLineNum = 3050;BA.debugLine="If error_level = \"L\" Then tel2 = ver17(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver17[(int) (76)];};
 //BA.debugLineNum = 3051;BA.debugLine="If error_level = \"M\" Then tel2 = ver17(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver17[(int) (77)];};
 //BA.debugLineNum = 3052;BA.debugLine="If error_level = \"Q\" Then tel2 = ver17(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver17[(int) (78)];};
 //BA.debugLineNum = 3053;BA.debugLine="If error_level = \"H\" Then tel2 = ver17(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver17[(int) (79)];};
 break; }
case 18: {
 //BA.debugLineNum = 3055;BA.debugLine="max_mod = ver18(12)";
_max_mod = _ver18[(int) (12)];
 //BA.debugLineNum = 3056;BA.debugLine="qr_size = ver18(1)";
_qr_size = _ver18[(int) (1)];
 //BA.debugLineNum = 3058;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver1";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver18[(int) (20)];};
 //BA.debugLineNum = 3059;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver1";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver18[(int) (21)];};
 //BA.debugLineNum = 3060;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver1";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver18[(int) (22)];};
 //BA.debugLineNum = 3061;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver1";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver18[(int) (23)];};
 //BA.debugLineNum = 3063;BA.debugLine="If error_level = \"L\" Then block1 = ver18(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver18[(int) (24)];};
 //BA.debugLineNum = 3064;BA.debugLine="If error_level = \"L\" Then block2 = ver18(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver18[(int) (28)];};
 //BA.debugLineNum = 3065;BA.debugLine="If error_level = \"L\" Then dw1 = ver18(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver18[(int) (26)];};
 //BA.debugLineNum = 3066;BA.debugLine="If error_level = \"L\" Then dw2 = ver18(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver18[(int) (30)];};
 //BA.debugLineNum = 3067;BA.debugLine="If error_level = \"L\" Then ew1 = ver18(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver18[(int) (27)];};
 //BA.debugLineNum = 3068;BA.debugLine="If error_level = \"L\" Then ew2 = ver18(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver18[(int) (31)];};
 //BA.debugLineNum = 3070;BA.debugLine="If error_level = \"M\" Then block1 = ver18(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver18[(int) (32)];};
 //BA.debugLineNum = 3071;BA.debugLine="If error_level = \"M\" Then block2 = ver18(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver18[(int) (36)];};
 //BA.debugLineNum = 3072;BA.debugLine="If error_level = \"M\" Then dw1 = ver18(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver18[(int) (34)];};
 //BA.debugLineNum = 3073;BA.debugLine="If error_level = \"M\" Then dw2 = ver18(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver18[(int) (38)];};
 //BA.debugLineNum = 3074;BA.debugLine="If error_level = \"M\" Then ew1 = ver18(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver18[(int) (35)];};
 //BA.debugLineNum = 3075;BA.debugLine="If error_level = \"M\" Then ew2 = ver18(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver18[(int) (39)];};
 //BA.debugLineNum = 3077;BA.debugLine="If error_level = \"Q\" Then block1 = ver18(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver18[(int) (40)];};
 //BA.debugLineNum = 3078;BA.debugLine="If error_level = \"Q\" Then block2 = ver18(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver18[(int) (44)];};
 //BA.debugLineNum = 3079;BA.debugLine="If error_level = \"Q\" Then dw1 = ver18(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver18[(int) (42)];};
 //BA.debugLineNum = 3080;BA.debugLine="If error_level = \"Q\" Then dw2 = ver18(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver18[(int) (46)];};
 //BA.debugLineNum = 3081;BA.debugLine="If error_level = \"Q\" Then ew1 = ver18(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver18[(int) (43)];};
 //BA.debugLineNum = 3082;BA.debugLine="If error_level = \"Q\" Then ew2 = ver18(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver18[(int) (47)];};
 //BA.debugLineNum = 3084;BA.debugLine="If error_level = \"H\" Then block1 = ver18(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver18[(int) (48)];};
 //BA.debugLineNum = 3085;BA.debugLine="If error_level = \"H\" Then block2 = ver18(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver18[(int) (52)];};
 //BA.debugLineNum = 3086;BA.debugLine="If error_level = \"H\" Then dw1 = ver18(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver18[(int) (50)];};
 //BA.debugLineNum = 3087;BA.debugLine="If error_level = \"H\" Then dw2 = ver18(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver18[(int) (54)];};
 //BA.debugLineNum = 3088;BA.debugLine="If error_level = \"H\" Then ew1 = ver18(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver18[(int) (51)];};
 //BA.debugLineNum = 3089;BA.debugLine="If error_level = \"H\" Then ew2 = ver18(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver18[(int) (55)];};
 //BA.debugLineNum = 3091;BA.debugLine="If error_level = \"L\" Then tel2 = ver18(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver18[(int) (76)];};
 //BA.debugLineNum = 3092;BA.debugLine="If error_level = \"M\" Then tel2 = ver18(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver18[(int) (77)];};
 //BA.debugLineNum = 3093;BA.debugLine="If error_level = \"Q\" Then tel2 = ver18(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver18[(int) (78)];};
 //BA.debugLineNum = 3094;BA.debugLine="If error_level = \"H\" Then tel2 = ver18(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver18[(int) (79)];};
 break; }
case 19: {
 //BA.debugLineNum = 3096;BA.debugLine="max_mod = ver19(12)";
_max_mod = _ver19[(int) (12)];
 //BA.debugLineNum = 3097;BA.debugLine="qr_size = ver19(1)";
_qr_size = _ver19[(int) (1)];
 //BA.debugLineNum = 3099;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver1";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver19[(int) (20)];};
 //BA.debugLineNum = 3100;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver1";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver19[(int) (21)];};
 //BA.debugLineNum = 3101;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver1";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver19[(int) (22)];};
 //BA.debugLineNum = 3102;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver1";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver19[(int) (23)];};
 //BA.debugLineNum = 3104;BA.debugLine="If error_level = \"L\" Then block1 = ver19(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver19[(int) (24)];};
 //BA.debugLineNum = 3105;BA.debugLine="If error_level = \"L\" Then block2 = ver19(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver19[(int) (28)];};
 //BA.debugLineNum = 3106;BA.debugLine="If error_level = \"L\" Then dw1 = ver19(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver19[(int) (26)];};
 //BA.debugLineNum = 3107;BA.debugLine="If error_level = \"L\" Then dw2 = ver19(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver19[(int) (30)];};
 //BA.debugLineNum = 3108;BA.debugLine="If error_level = \"L\" Then ew1 = ver19(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver19[(int) (27)];};
 //BA.debugLineNum = 3109;BA.debugLine="If error_level = \"L\" Then ew2 = ver19(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver19[(int) (31)];};
 //BA.debugLineNum = 3111;BA.debugLine="If error_level = \"M\" Then block1 = ver19(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver19[(int) (32)];};
 //BA.debugLineNum = 3112;BA.debugLine="If error_level = \"M\" Then block2 = ver19(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver19[(int) (36)];};
 //BA.debugLineNum = 3113;BA.debugLine="If error_level = \"M\" Then dw1 = ver19(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver19[(int) (34)];};
 //BA.debugLineNum = 3114;BA.debugLine="If error_level = \"M\" Then dw2 = ver19(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver19[(int) (38)];};
 //BA.debugLineNum = 3115;BA.debugLine="If error_level = \"M\" Then ew1 = ver19(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver19[(int) (35)];};
 //BA.debugLineNum = 3116;BA.debugLine="If error_level = \"M\" Then ew2 = ver19(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver19[(int) (39)];};
 //BA.debugLineNum = 3118;BA.debugLine="If error_level = \"Q\" Then block1 = ver19(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver19[(int) (40)];};
 //BA.debugLineNum = 3119;BA.debugLine="If error_level = \"Q\" Then block2 = ver19(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver19[(int) (44)];};
 //BA.debugLineNum = 3120;BA.debugLine="If error_level = \"Q\" Then dw1 = ver19(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver19[(int) (42)];};
 //BA.debugLineNum = 3121;BA.debugLine="If error_level = \"Q\" Then dw2 = ver19(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver19[(int) (46)];};
 //BA.debugLineNum = 3122;BA.debugLine="If error_level = \"Q\" Then ew1 = ver19(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver19[(int) (43)];};
 //BA.debugLineNum = 3123;BA.debugLine="If error_level = \"Q\" Then ew2 = ver19(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver19[(int) (47)];};
 //BA.debugLineNum = 3125;BA.debugLine="If error_level = \"H\" Then block1 = ver19(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver19[(int) (48)];};
 //BA.debugLineNum = 3126;BA.debugLine="If error_level = \"H\" Then block2 = ver19(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver19[(int) (52)];};
 //BA.debugLineNum = 3127;BA.debugLine="If error_level = \"H\" Then dw1 = ver19(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver19[(int) (50)];};
 //BA.debugLineNum = 3128;BA.debugLine="If error_level = \"H\" Then dw2 = ver19(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver19[(int) (54)];};
 //BA.debugLineNum = 3129;BA.debugLine="If error_level = \"H\" Then ew1 = ver19(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver19[(int) (51)];};
 //BA.debugLineNum = 3130;BA.debugLine="If error_level = \"H\" Then ew2 = ver19(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver19[(int) (55)];};
 //BA.debugLineNum = 3132;BA.debugLine="If error_level = \"L\" Then tel2 = ver19(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver19[(int) (76)];};
 //BA.debugLineNum = 3133;BA.debugLine="If error_level = \"M\" Then tel2 = ver19(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver19[(int) (77)];};
 //BA.debugLineNum = 3134;BA.debugLine="If error_level = \"Q\" Then tel2 = ver19(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver19[(int) (78)];};
 //BA.debugLineNum = 3135;BA.debugLine="If error_level = \"H\" Then tel2 = ver19(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver19[(int) (79)];};
 break; }
case 20: {
 //BA.debugLineNum = 3137;BA.debugLine="max_mod = ver20(12)";
_max_mod = _ver20[(int) (12)];
 //BA.debugLineNum = 3138;BA.debugLine="qr_size = ver20(1)";
_qr_size = _ver20[(int) (1)];
 //BA.debugLineNum = 3140;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver2";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver20[(int) (20)];};
 //BA.debugLineNum = 3141;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver2";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver20[(int) (21)];};
 //BA.debugLineNum = 3142;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver2";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver20[(int) (22)];};
 //BA.debugLineNum = 3143;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver2";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver20[(int) (23)];};
 //BA.debugLineNum = 3145;BA.debugLine="If error_level = \"L\" Then block1 = ver20(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver20[(int) (24)];};
 //BA.debugLineNum = 3146;BA.debugLine="If error_level = \"L\" Then block2 = ver20(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver20[(int) (28)];};
 //BA.debugLineNum = 3147;BA.debugLine="If error_level = \"L\" Then dw1 = ver20(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver20[(int) (26)];};
 //BA.debugLineNum = 3148;BA.debugLine="If error_level = \"L\" Then dw2 = ver20(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver20[(int) (30)];};
 //BA.debugLineNum = 3149;BA.debugLine="If error_level = \"L\" Then ew1 = ver20(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver20[(int) (27)];};
 //BA.debugLineNum = 3150;BA.debugLine="If error_level = \"L\" Then ew2 = ver20(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver20[(int) (31)];};
 //BA.debugLineNum = 3152;BA.debugLine="If error_level = \"M\" Then block1 = ver20(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver20[(int) (32)];};
 //BA.debugLineNum = 3153;BA.debugLine="If error_level = \"M\" Then block2 = ver20(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver20[(int) (36)];};
 //BA.debugLineNum = 3154;BA.debugLine="If error_level = \"M\" Then dw1 = ver20(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver20[(int) (34)];};
 //BA.debugLineNum = 3155;BA.debugLine="If error_level = \"M\" Then dw2 = ver20(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver20[(int) (38)];};
 //BA.debugLineNum = 3156;BA.debugLine="If error_level = \"M\" Then ew1 = ver20(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver20[(int) (35)];};
 //BA.debugLineNum = 3157;BA.debugLine="If error_level = \"M\" Then ew2 = ver20(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver20[(int) (39)];};
 //BA.debugLineNum = 3159;BA.debugLine="If error_level = \"Q\" Then block1 = ver20(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver20[(int) (40)];};
 //BA.debugLineNum = 3160;BA.debugLine="If error_level = \"Q\" Then block2 = ver20(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver20[(int) (44)];};
 //BA.debugLineNum = 3161;BA.debugLine="If error_level = \"Q\" Then dw1 = ver20(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver20[(int) (42)];};
 //BA.debugLineNum = 3162;BA.debugLine="If error_level = \"Q\" Then dw2 = ver20(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver20[(int) (46)];};
 //BA.debugLineNum = 3163;BA.debugLine="If error_level = \"Q\" Then ew1 = ver20(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver20[(int) (43)];};
 //BA.debugLineNum = 3164;BA.debugLine="If error_level = \"Q\" Then ew2 = ver20(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver20[(int) (47)];};
 //BA.debugLineNum = 3166;BA.debugLine="If error_level = \"H\" Then block1 = ver20(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver20[(int) (48)];};
 //BA.debugLineNum = 3167;BA.debugLine="If error_level = \"H\" Then block2 = ver20(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver20[(int) (52)];};
 //BA.debugLineNum = 3168;BA.debugLine="If error_level = \"H\" Then dw1 = ver20(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver20[(int) (50)];};
 //BA.debugLineNum = 3169;BA.debugLine="If error_level = \"H\" Then dw2 = ver20(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver20[(int) (54)];};
 //BA.debugLineNum = 3170;BA.debugLine="If error_level = \"H\" Then ew1 = ver20(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver20[(int) (51)];};
 //BA.debugLineNum = 3171;BA.debugLine="If error_level = \"H\" Then ew2 = ver20(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver20[(int) (55)];};
 //BA.debugLineNum = 3173;BA.debugLine="If error_level = \"L\" Then tel2 = ver20(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver20[(int) (76)];};
 //BA.debugLineNum = 3174;BA.debugLine="If error_level = \"M\" Then tel2 = ver20(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver20[(int) (77)];};
 //BA.debugLineNum = 3175;BA.debugLine="If error_level = \"Q\" Then tel2 = ver20(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver20[(int) (78)];};
 //BA.debugLineNum = 3176;BA.debugLine="If error_level = \"H\" Then tel2 = ver20(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver20[(int) (79)];};
 break; }
case 21: {
 //BA.debugLineNum = 3178;BA.debugLine="max_mod = ver21(12)";
_max_mod = _ver21[(int) (12)];
 //BA.debugLineNum = 3179;BA.debugLine="qr_size = ver21(1)";
_qr_size = _ver21[(int) (1)];
 //BA.debugLineNum = 3181;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver2";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver21[(int) (20)];};
 //BA.debugLineNum = 3182;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver2";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver21[(int) (21)];};
 //BA.debugLineNum = 3183;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver2";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver21[(int) (22)];};
 //BA.debugLineNum = 3184;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver2";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver21[(int) (23)];};
 //BA.debugLineNum = 3186;BA.debugLine="If error_level = \"L\" Then block1 = ver21(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver21[(int) (24)];};
 //BA.debugLineNum = 3187;BA.debugLine="If error_level = \"L\" Then block2 = ver21(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver21[(int) (28)];};
 //BA.debugLineNum = 3188;BA.debugLine="If error_level = \"L\" Then dw1 = ver21(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver21[(int) (26)];};
 //BA.debugLineNum = 3189;BA.debugLine="If error_level = \"L\" Then dw2 = ver21(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver21[(int) (30)];};
 //BA.debugLineNum = 3190;BA.debugLine="If error_level = \"L\" Then ew1 = ver21(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver21[(int) (27)];};
 //BA.debugLineNum = 3191;BA.debugLine="If error_level = \"L\" Then ew2 = ver21(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver21[(int) (31)];};
 //BA.debugLineNum = 3193;BA.debugLine="If error_level = \"M\" Then block1 = ver21(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver21[(int) (32)];};
 //BA.debugLineNum = 3194;BA.debugLine="If error_level = \"M\" Then block2 = ver21(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver21[(int) (36)];};
 //BA.debugLineNum = 3195;BA.debugLine="If error_level = \"M\" Then dw1 = ver21(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver21[(int) (34)];};
 //BA.debugLineNum = 3196;BA.debugLine="If error_level = \"M\" Then dw2 = ver21(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver21[(int) (38)];};
 //BA.debugLineNum = 3197;BA.debugLine="If error_level = \"M\" Then ew1 = ver21(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver21[(int) (35)];};
 //BA.debugLineNum = 3198;BA.debugLine="If error_level = \"M\" Then ew2 = ver21(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver21[(int) (39)];};
 //BA.debugLineNum = 3200;BA.debugLine="If error_level = \"Q\" Then block1 = ver21(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver21[(int) (40)];};
 //BA.debugLineNum = 3201;BA.debugLine="If error_level = \"Q\" Then block2 = ver21(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver21[(int) (44)];};
 //BA.debugLineNum = 3202;BA.debugLine="If error_level = \"Q\" Then dw1 = ver21(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver21[(int) (42)];};
 //BA.debugLineNum = 3203;BA.debugLine="If error_level = \"Q\" Then dw2 = ver21(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver21[(int) (46)];};
 //BA.debugLineNum = 3204;BA.debugLine="If error_level = \"Q\" Then ew1 = ver21(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver21[(int) (43)];};
 //BA.debugLineNum = 3205;BA.debugLine="If error_level = \"Q\" Then ew2 = ver21(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver21[(int) (47)];};
 //BA.debugLineNum = 3207;BA.debugLine="If error_level = \"H\" Then block1 = ver21(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver21[(int) (48)];};
 //BA.debugLineNum = 3208;BA.debugLine="If error_level = \"H\" Then block2 = ver21(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver21[(int) (52)];};
 //BA.debugLineNum = 3209;BA.debugLine="If error_level = \"H\" Then dw1 = ver21(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver21[(int) (50)];};
 //BA.debugLineNum = 3210;BA.debugLine="If error_level = \"H\" Then dw2 = ver21(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver21[(int) (54)];};
 //BA.debugLineNum = 3211;BA.debugLine="If error_level = \"H\" Then ew1 = ver21(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver21[(int) (51)];};
 //BA.debugLineNum = 3212;BA.debugLine="If error_level = \"H\" Then ew2 = ver21(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver21[(int) (55)];};
 //BA.debugLineNum = 3214;BA.debugLine="If error_level = \"L\" Then tel2 = ver21(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver21[(int) (76)];};
 //BA.debugLineNum = 3215;BA.debugLine="If error_level = \"M\" Then tel2 = ver21(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver21[(int) (77)];};
 //BA.debugLineNum = 3216;BA.debugLine="If error_level = \"Q\" Then tel2 = ver21(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver21[(int) (78)];};
 //BA.debugLineNum = 3217;BA.debugLine="If error_level = \"H\" Then tel2 = ver21(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver21[(int) (79)];};
 break; }
case 22: {
 //BA.debugLineNum = 3219;BA.debugLine="max_mod = ver22(12)";
_max_mod = _ver22[(int) (12)];
 //BA.debugLineNum = 3220;BA.debugLine="qr_size = ver22(1)";
_qr_size = _ver22[(int) (1)];
 //BA.debugLineNum = 3222;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver2";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver22[(int) (20)];};
 //BA.debugLineNum = 3223;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver2";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver22[(int) (21)];};
 //BA.debugLineNum = 3224;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver2";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver22[(int) (22)];};
 //BA.debugLineNum = 3225;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver2";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver22[(int) (23)];};
 //BA.debugLineNum = 3227;BA.debugLine="If error_level = \"L\" Then block1 = ver22(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver22[(int) (24)];};
 //BA.debugLineNum = 3228;BA.debugLine="If error_level = \"L\" Then block2 = ver22(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver22[(int) (28)];};
 //BA.debugLineNum = 3229;BA.debugLine="If error_level = \"L\" Then dw1 = ver22(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver22[(int) (26)];};
 //BA.debugLineNum = 3230;BA.debugLine="If error_level = \"L\" Then dw2 = ver22(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver22[(int) (30)];};
 //BA.debugLineNum = 3231;BA.debugLine="If error_level = \"L\" Then ew1 = ver22(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver22[(int) (27)];};
 //BA.debugLineNum = 3232;BA.debugLine="If error_level = \"L\" Then ew2 = ver22(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver22[(int) (31)];};
 //BA.debugLineNum = 3234;BA.debugLine="If error_level = \"M\" Then block1 = ver22(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver22[(int) (32)];};
 //BA.debugLineNum = 3235;BA.debugLine="If error_level = \"M\" Then block2 = ver22(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver22[(int) (36)];};
 //BA.debugLineNum = 3236;BA.debugLine="If error_level = \"M\" Then dw1 = ver22(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver22[(int) (34)];};
 //BA.debugLineNum = 3237;BA.debugLine="If error_level = \"M\" Then dw2 = ver22(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver22[(int) (38)];};
 //BA.debugLineNum = 3238;BA.debugLine="If error_level = \"M\" Then ew1 = ver22(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver22[(int) (35)];};
 //BA.debugLineNum = 3239;BA.debugLine="If error_level = \"M\" Then ew2 = ver22(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver22[(int) (39)];};
 //BA.debugLineNum = 3241;BA.debugLine="If error_level = \"Q\" Then block1 = ver22(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver22[(int) (40)];};
 //BA.debugLineNum = 3242;BA.debugLine="If error_level = \"Q\" Then block2 = ver22(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver22[(int) (44)];};
 //BA.debugLineNum = 3243;BA.debugLine="If error_level = \"Q\" Then dw1 = ver22(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver22[(int) (42)];};
 //BA.debugLineNum = 3244;BA.debugLine="If error_level = \"Q\" Then dw2 = ver22(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver22[(int) (46)];};
 //BA.debugLineNum = 3245;BA.debugLine="If error_level = \"Q\" Then ew1 = ver22(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver22[(int) (43)];};
 //BA.debugLineNum = 3246;BA.debugLine="If error_level = \"Q\" Then ew2 = ver22(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver22[(int) (47)];};
 //BA.debugLineNum = 3248;BA.debugLine="If error_level = \"H\" Then block1 = ver22(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver22[(int) (48)];};
 //BA.debugLineNum = 3249;BA.debugLine="If error_level = \"H\" Then block2 = ver22(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver22[(int) (52)];};
 //BA.debugLineNum = 3250;BA.debugLine="If error_level = \"H\" Then dw1 = ver22(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver22[(int) (50)];};
 //BA.debugLineNum = 3251;BA.debugLine="If error_level = \"H\" Then dw2 = ver22(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver22[(int) (54)];};
 //BA.debugLineNum = 3252;BA.debugLine="If error_level = \"H\" Then ew1 = ver22(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver22[(int) (51)];};
 //BA.debugLineNum = 3253;BA.debugLine="If error_level = \"H\" Then ew2 = ver22(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver22[(int) (55)];};
 //BA.debugLineNum = 3255;BA.debugLine="If error_level = \"L\" Then tel2 = ver22(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver22[(int) (76)];};
 //BA.debugLineNum = 3256;BA.debugLine="If error_level = \"M\" Then tel2 = ver22(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver22[(int) (77)];};
 //BA.debugLineNum = 3257;BA.debugLine="If error_level = \"Q\" Then tel2 = ver22(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver22[(int) (78)];};
 //BA.debugLineNum = 3258;BA.debugLine="If error_level = \"H\" Then tel2 = ver22(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver22[(int) (79)];};
 break; }
case 23: {
 //BA.debugLineNum = 3260;BA.debugLine="max_mod = ver23(12)";
_max_mod = _ver23[(int) (12)];
 //BA.debugLineNum = 3261;BA.debugLine="qr_size = ver23(1)";
_qr_size = _ver23[(int) (1)];
 //BA.debugLineNum = 3263;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver2";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver23[(int) (20)];};
 //BA.debugLineNum = 3264;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver2";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver23[(int) (21)];};
 //BA.debugLineNum = 3265;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver2";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver23[(int) (22)];};
 //BA.debugLineNum = 3266;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver2";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver23[(int) (23)];};
 //BA.debugLineNum = 3268;BA.debugLine="If error_level = \"L\" Then block1 = ver23(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver23[(int) (24)];};
 //BA.debugLineNum = 3269;BA.debugLine="If error_level = \"L\" Then block2 = ver23(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver23[(int) (28)];};
 //BA.debugLineNum = 3270;BA.debugLine="If error_level = \"L\" Then dw1 = ver23(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver23[(int) (26)];};
 //BA.debugLineNum = 3271;BA.debugLine="If error_level = \"L\" Then dw2 = ver23(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver23[(int) (30)];};
 //BA.debugLineNum = 3272;BA.debugLine="If error_level = \"L\" Then ew1 = ver23(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver23[(int) (27)];};
 //BA.debugLineNum = 3273;BA.debugLine="If error_level = \"L\" Then ew2 = ver23(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver23[(int) (31)];};
 //BA.debugLineNum = 3275;BA.debugLine="If error_level = \"M\" Then block1 = ver23(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver23[(int) (32)];};
 //BA.debugLineNum = 3276;BA.debugLine="If error_level = \"M\" Then block2 = ver23(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver23[(int) (36)];};
 //BA.debugLineNum = 3277;BA.debugLine="If error_level = \"M\" Then dw1 = ver23(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver23[(int) (34)];};
 //BA.debugLineNum = 3278;BA.debugLine="If error_level = \"M\" Then dw2 = ver23(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver23[(int) (38)];};
 //BA.debugLineNum = 3279;BA.debugLine="If error_level = \"M\" Then ew1 = ver23(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver23[(int) (35)];};
 //BA.debugLineNum = 3280;BA.debugLine="If error_level = \"M\" Then ew2 = ver23(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver23[(int) (39)];};
 //BA.debugLineNum = 3282;BA.debugLine="If error_level = \"Q\" Then block1 = ver23(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver23[(int) (40)];};
 //BA.debugLineNum = 3283;BA.debugLine="If error_level = \"Q\" Then block2 = ver23(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver23[(int) (44)];};
 //BA.debugLineNum = 3284;BA.debugLine="If error_level = \"Q\" Then dw1 = ver23(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver23[(int) (42)];};
 //BA.debugLineNum = 3285;BA.debugLine="If error_level = \"Q\" Then dw2 = ver23(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver23[(int) (46)];};
 //BA.debugLineNum = 3286;BA.debugLine="If error_level = \"Q\" Then ew1 = ver23(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver23[(int) (43)];};
 //BA.debugLineNum = 3287;BA.debugLine="If error_level = \"Q\" Then ew2 = ver23(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver23[(int) (47)];};
 //BA.debugLineNum = 3289;BA.debugLine="If error_level = \"H\" Then block1 = ver23(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver23[(int) (48)];};
 //BA.debugLineNum = 3290;BA.debugLine="If error_level = \"H\" Then block2 = ver23(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver23[(int) (52)];};
 //BA.debugLineNum = 3291;BA.debugLine="If error_level = \"H\" Then dw1 = ver23(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver23[(int) (50)];};
 //BA.debugLineNum = 3292;BA.debugLine="If error_level = \"H\" Then dw2 = ver23(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver23[(int) (54)];};
 //BA.debugLineNum = 3293;BA.debugLine="If error_level = \"H\" Then ew1 = ver23(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver23[(int) (51)];};
 //BA.debugLineNum = 3294;BA.debugLine="If error_level = \"H\" Then ew2 = ver23(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver23[(int) (55)];};
 //BA.debugLineNum = 3296;BA.debugLine="If error_level = \"L\" Then tel2 = ver23(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver23[(int) (76)];};
 //BA.debugLineNum = 3297;BA.debugLine="If error_level = \"M\" Then tel2 = ver23(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver23[(int) (77)];};
 //BA.debugLineNum = 3298;BA.debugLine="If error_level = \"Q\" Then tel2 = ver23(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver23[(int) (78)];};
 //BA.debugLineNum = 3299;BA.debugLine="If error_level = \"H\" Then tel2 = ver23(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver23[(int) (79)];};
 break; }
case 24: {
 //BA.debugLineNum = 3301;BA.debugLine="max_mod = ver24(12)";
_max_mod = _ver24[(int) (12)];
 //BA.debugLineNum = 3302;BA.debugLine="qr_size = ver24(1)";
_qr_size = _ver24[(int) (1)];
 //BA.debugLineNum = 3304;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver2";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver24[(int) (20)];};
 //BA.debugLineNum = 3305;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver2";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver24[(int) (21)];};
 //BA.debugLineNum = 3306;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver2";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver24[(int) (22)];};
 //BA.debugLineNum = 3307;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver2";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver24[(int) (23)];};
 //BA.debugLineNum = 3309;BA.debugLine="If error_level = \"L\" Then block1 = ver24(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver24[(int) (24)];};
 //BA.debugLineNum = 3310;BA.debugLine="If error_level = \"L\" Then block2 = ver24(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver24[(int) (28)];};
 //BA.debugLineNum = 3311;BA.debugLine="If error_level = \"L\" Then dw1 = ver24(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver24[(int) (26)];};
 //BA.debugLineNum = 3312;BA.debugLine="If error_level = \"L\" Then dw2 = ver24(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver24[(int) (30)];};
 //BA.debugLineNum = 3313;BA.debugLine="If error_level = \"L\" Then ew1 = ver24(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver24[(int) (27)];};
 //BA.debugLineNum = 3314;BA.debugLine="If error_level = \"L\" Then ew2 = ver24(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver24[(int) (31)];};
 //BA.debugLineNum = 3316;BA.debugLine="If error_level = \"M\" Then block1 = ver24(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver24[(int) (32)];};
 //BA.debugLineNum = 3317;BA.debugLine="If error_level = \"M\" Then block2 = ver24(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver24[(int) (36)];};
 //BA.debugLineNum = 3318;BA.debugLine="If error_level = \"M\" Then dw1 = ver24(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver24[(int) (34)];};
 //BA.debugLineNum = 3319;BA.debugLine="If error_level = \"M\" Then dw2 = ver24(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver24[(int) (38)];};
 //BA.debugLineNum = 3320;BA.debugLine="If error_level = \"M\" Then ew1 = ver24(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver24[(int) (35)];};
 //BA.debugLineNum = 3321;BA.debugLine="If error_level = \"M\" Then ew2 = ver24(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver24[(int) (39)];};
 //BA.debugLineNum = 3323;BA.debugLine="If error_level = \"Q\" Then block1 = ver24(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver24[(int) (40)];};
 //BA.debugLineNum = 3324;BA.debugLine="If error_level = \"Q\" Then block2 = ver24(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver24[(int) (44)];};
 //BA.debugLineNum = 3325;BA.debugLine="If error_level = \"Q\" Then dw1 = ver24(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver24[(int) (42)];};
 //BA.debugLineNum = 3326;BA.debugLine="If error_level = \"Q\" Then dw2 = ver24(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver24[(int) (46)];};
 //BA.debugLineNum = 3327;BA.debugLine="If error_level = \"Q\" Then ew1 = ver24(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver24[(int) (43)];};
 //BA.debugLineNum = 3328;BA.debugLine="If error_level = \"Q\" Then ew2 = ver24(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver24[(int) (47)];};
 //BA.debugLineNum = 3330;BA.debugLine="If error_level = \"H\" Then block1 = ver24(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver24[(int) (48)];};
 //BA.debugLineNum = 3331;BA.debugLine="If error_level = \"H\" Then block2 = ver24(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver24[(int) (52)];};
 //BA.debugLineNum = 3332;BA.debugLine="If error_level = \"H\" Then dw1 = ver24(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver24[(int) (50)];};
 //BA.debugLineNum = 3333;BA.debugLine="If error_level = \"H\" Then dw2 = ver24(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver24[(int) (54)];};
 //BA.debugLineNum = 3334;BA.debugLine="If error_level = \"H\" Then ew1 = ver24(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver24[(int) (51)];};
 //BA.debugLineNum = 3335;BA.debugLine="If error_level = \"H\" Then ew2 = ver24(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver24[(int) (55)];};
 //BA.debugLineNum = 3337;BA.debugLine="If error_level = \"L\" Then tel2 = ver24(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver24[(int) (76)];};
 //BA.debugLineNum = 3338;BA.debugLine="If error_level = \"M\" Then tel2 = ver24(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver24[(int) (77)];};
 //BA.debugLineNum = 3339;BA.debugLine="If error_level = \"Q\" Then tel2 = ver24(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver24[(int) (78)];};
 //BA.debugLineNum = 3340;BA.debugLine="If error_level = \"H\" Then tel2 = ver24(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver24[(int) (79)];};
 break; }
case 25: {
 //BA.debugLineNum = 3342;BA.debugLine="max_mod = ver25(12)";
_max_mod = _ver25[(int) (12)];
 //BA.debugLineNum = 3343;BA.debugLine="qr_size = ver25(1)";
_qr_size = _ver25[(int) (1)];
 //BA.debugLineNum = 3345;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver2";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver25[(int) (20)];};
 //BA.debugLineNum = 3346;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver2";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver25[(int) (21)];};
 //BA.debugLineNum = 3347;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver2";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver25[(int) (22)];};
 //BA.debugLineNum = 3348;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver2";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver25[(int) (23)];};
 //BA.debugLineNum = 3350;BA.debugLine="If error_level = \"L\" Then block1 = ver25(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver25[(int) (24)];};
 //BA.debugLineNum = 3351;BA.debugLine="If error_level = \"L\" Then block2 = ver25(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver25[(int) (28)];};
 //BA.debugLineNum = 3352;BA.debugLine="If error_level = \"L\" Then dw1 = ver25(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver25[(int) (26)];};
 //BA.debugLineNum = 3353;BA.debugLine="If error_level = \"L\" Then dw2 = ver25(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver25[(int) (30)];};
 //BA.debugLineNum = 3354;BA.debugLine="If error_level = \"L\" Then ew1 = ver25(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver25[(int) (27)];};
 //BA.debugLineNum = 3355;BA.debugLine="If error_level = \"L\" Then ew2 = ver25(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver25[(int) (31)];};
 //BA.debugLineNum = 3357;BA.debugLine="If error_level = \"M\" Then block1 = ver25(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver25[(int) (32)];};
 //BA.debugLineNum = 3358;BA.debugLine="If error_level = \"M\" Then block2 = ver25(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver25[(int) (36)];};
 //BA.debugLineNum = 3359;BA.debugLine="If error_level = \"M\" Then dw1 = ver25(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver25[(int) (34)];};
 //BA.debugLineNum = 3360;BA.debugLine="If error_level = \"M\" Then dw2 = ver25(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver25[(int) (38)];};
 //BA.debugLineNum = 3361;BA.debugLine="If error_level = \"M\" Then ew1 = ver25(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver25[(int) (35)];};
 //BA.debugLineNum = 3362;BA.debugLine="If error_level = \"M\" Then ew2 = ver25(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver25[(int) (39)];};
 //BA.debugLineNum = 3364;BA.debugLine="If error_level = \"Q\" Then block1 = ver25(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver25[(int) (40)];};
 //BA.debugLineNum = 3365;BA.debugLine="If error_level = \"Q\" Then block2 = ver25(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver25[(int) (44)];};
 //BA.debugLineNum = 3366;BA.debugLine="If error_level = \"Q\" Then dw1 = ver25(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver25[(int) (42)];};
 //BA.debugLineNum = 3367;BA.debugLine="If error_level = \"Q\" Then dw2 = ver25(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver25[(int) (46)];};
 //BA.debugLineNum = 3368;BA.debugLine="If error_level = \"Q\" Then ew1 = ver25(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver25[(int) (43)];};
 //BA.debugLineNum = 3369;BA.debugLine="If error_level = \"Q\" Then ew2 = ver25(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver25[(int) (47)];};
 //BA.debugLineNum = 3371;BA.debugLine="If error_level = \"H\" Then block1 = ver25(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver25[(int) (48)];};
 //BA.debugLineNum = 3372;BA.debugLine="If error_level = \"H\" Then block2 = ver25(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver25[(int) (52)];};
 //BA.debugLineNum = 3373;BA.debugLine="If error_level = \"H\" Then dw1 = ver25(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver25[(int) (50)];};
 //BA.debugLineNum = 3374;BA.debugLine="If error_level = \"H\" Then dw2 = ver25(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver25[(int) (54)];};
 //BA.debugLineNum = 3375;BA.debugLine="If error_level = \"H\" Then ew1 = ver25(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver25[(int) (51)];};
 //BA.debugLineNum = 3376;BA.debugLine="If error_level = \"H\" Then ew2 = ver25(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver25[(int) (55)];};
 //BA.debugLineNum = 3378;BA.debugLine="If error_level = \"L\" Then tel2 = ver25(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver25[(int) (76)];};
 //BA.debugLineNum = 3379;BA.debugLine="If error_level = \"M\" Then tel2 = ver25(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver25[(int) (77)];};
 //BA.debugLineNum = 3380;BA.debugLine="If error_level = \"Q\" Then tel2 = ver25(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver25[(int) (78)];};
 //BA.debugLineNum = 3381;BA.debugLine="If error_level = \"H\" Then tel2 = ver25(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver25[(int) (79)];};
 break; }
case 26: {
 //BA.debugLineNum = 3383;BA.debugLine="max_mod = ver26(12)";
_max_mod = _ver26[(int) (12)];
 //BA.debugLineNum = 3384;BA.debugLine="qr_size = ver26(1)";
_qr_size = _ver26[(int) (1)];
 //BA.debugLineNum = 3386;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver2";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver26[(int) (20)];};
 //BA.debugLineNum = 3387;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver2";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver26[(int) (21)];};
 //BA.debugLineNum = 3388;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver2";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver26[(int) (22)];};
 //BA.debugLineNum = 3389;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver2";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver26[(int) (23)];};
 //BA.debugLineNum = 3391;BA.debugLine="If error_level = \"L\" Then block1 = ver26(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver26[(int) (24)];};
 //BA.debugLineNum = 3392;BA.debugLine="If error_level = \"L\" Then block2 = ver26(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver26[(int) (28)];};
 //BA.debugLineNum = 3393;BA.debugLine="If error_level = \"L\" Then dw1 = ver26(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver26[(int) (26)];};
 //BA.debugLineNum = 3394;BA.debugLine="If error_level = \"L\" Then dw2 = ver26(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver26[(int) (30)];};
 //BA.debugLineNum = 3395;BA.debugLine="If error_level = \"L\" Then ew1 = ver26(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver26[(int) (27)];};
 //BA.debugLineNum = 3396;BA.debugLine="If error_level = \"L\" Then ew2 = ver26(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver26[(int) (31)];};
 //BA.debugLineNum = 3398;BA.debugLine="If error_level = \"M\" Then block1 = ver26(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver26[(int) (32)];};
 //BA.debugLineNum = 3399;BA.debugLine="If error_level = \"M\" Then block2 = ver26(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver26[(int) (36)];};
 //BA.debugLineNum = 3400;BA.debugLine="If error_level = \"M\" Then dw1 = ver26(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver26[(int) (34)];};
 //BA.debugLineNum = 3401;BA.debugLine="If error_level = \"M\" Then dw2 = ver26(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver26[(int) (38)];};
 //BA.debugLineNum = 3402;BA.debugLine="If error_level = \"M\" Then ew1 = ver26(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver26[(int) (35)];};
 //BA.debugLineNum = 3403;BA.debugLine="If error_level = \"M\" Then ew2 = ver26(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver26[(int) (39)];};
 //BA.debugLineNum = 3405;BA.debugLine="If error_level = \"Q\" Then block1 = ver26(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver26[(int) (40)];};
 //BA.debugLineNum = 3406;BA.debugLine="If error_level = \"Q\" Then block2 = ver26(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver26[(int) (44)];};
 //BA.debugLineNum = 3407;BA.debugLine="If error_level = \"Q\" Then dw1 = ver26(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver26[(int) (42)];};
 //BA.debugLineNum = 3408;BA.debugLine="If error_level = \"Q\" Then dw2 = ver26(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver26[(int) (46)];};
 //BA.debugLineNum = 3409;BA.debugLine="If error_level = \"Q\" Then ew1 = ver26(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver26[(int) (43)];};
 //BA.debugLineNum = 3410;BA.debugLine="If error_level = \"Q\" Then ew2 = ver26(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver26[(int) (47)];};
 //BA.debugLineNum = 3412;BA.debugLine="If error_level = \"H\" Then block1 = ver26(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver26[(int) (48)];};
 //BA.debugLineNum = 3413;BA.debugLine="If error_level = \"H\" Then block2 = ver26(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver26[(int) (52)];};
 //BA.debugLineNum = 3414;BA.debugLine="If error_level = \"H\" Then dw1 = ver26(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver26[(int) (50)];};
 //BA.debugLineNum = 3415;BA.debugLine="If error_level = \"H\" Then dw2 = ver26(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver26[(int) (54)];};
 //BA.debugLineNum = 3416;BA.debugLine="If error_level = \"H\" Then ew1 = ver26(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver26[(int) (51)];};
 //BA.debugLineNum = 3417;BA.debugLine="If error_level = \"H\" Then ew2 = ver26(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver26[(int) (55)];};
 //BA.debugLineNum = 3419;BA.debugLine="If error_level = \"L\" Then tel2 = ver26(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver26[(int) (76)];};
 //BA.debugLineNum = 3420;BA.debugLine="If error_level = \"M\" Then tel2 = ver26(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver26[(int) (77)];};
 //BA.debugLineNum = 3421;BA.debugLine="If error_level = \"Q\" Then tel2 = ver26(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver26[(int) (78)];};
 //BA.debugLineNum = 3422;BA.debugLine="If error_level = \"H\" Then tel2 = ver26(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver26[(int) (79)];};
 break; }
case 27: {
 //BA.debugLineNum = 3424;BA.debugLine="max_mod = ver27(12)";
_max_mod = _ver27[(int) (12)];
 //BA.debugLineNum = 3425;BA.debugLine="qr_size = ver27(1)";
_qr_size = _ver27[(int) (1)];
 //BA.debugLineNum = 3427;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver2";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver27[(int) (20)];};
 //BA.debugLineNum = 3428;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver2";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver27[(int) (21)];};
 //BA.debugLineNum = 3429;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver2";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver27[(int) (22)];};
 //BA.debugLineNum = 3430;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver2";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver27[(int) (23)];};
 //BA.debugLineNum = 3432;BA.debugLine="If error_level = \"L\" Then block1 = ver27(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver27[(int) (24)];};
 //BA.debugLineNum = 3433;BA.debugLine="If error_level = \"L\" Then block2 = ver27(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver27[(int) (28)];};
 //BA.debugLineNum = 3434;BA.debugLine="If error_level = \"L\" Then dw1 = ver27(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver27[(int) (26)];};
 //BA.debugLineNum = 3435;BA.debugLine="If error_level = \"L\" Then dw2 = ver27(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver27[(int) (30)];};
 //BA.debugLineNum = 3436;BA.debugLine="If error_level = \"L\" Then ew1 = ver27(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver27[(int) (27)];};
 //BA.debugLineNum = 3437;BA.debugLine="If error_level = \"L\" Then ew2 = ver27(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver27[(int) (31)];};
 //BA.debugLineNum = 3439;BA.debugLine="If error_level = \"M\" Then block1 = ver27(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver27[(int) (32)];};
 //BA.debugLineNum = 3440;BA.debugLine="If error_level = \"M\" Then block2 = ver27(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver27[(int) (36)];};
 //BA.debugLineNum = 3441;BA.debugLine="If error_level = \"M\" Then dw1 = ver27(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver27[(int) (34)];};
 //BA.debugLineNum = 3442;BA.debugLine="If error_level = \"M\" Then dw2 = ver27(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver27[(int) (38)];};
 //BA.debugLineNum = 3443;BA.debugLine="If error_level = \"M\" Then ew1 = ver27(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver27[(int) (35)];};
 //BA.debugLineNum = 3444;BA.debugLine="If error_level = \"M\" Then ew2 = ver27(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver27[(int) (39)];};
 //BA.debugLineNum = 3446;BA.debugLine="If error_level = \"Q\" Then block1 = ver27(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver27[(int) (40)];};
 //BA.debugLineNum = 3447;BA.debugLine="If error_level = \"Q\" Then block2 = ver27(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver27[(int) (44)];};
 //BA.debugLineNum = 3448;BA.debugLine="If error_level = \"Q\" Then dw1 = ver27(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver27[(int) (42)];};
 //BA.debugLineNum = 3449;BA.debugLine="If error_level = \"Q\" Then dw2 = ver27(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver27[(int) (46)];};
 //BA.debugLineNum = 3450;BA.debugLine="If error_level = \"Q\" Then ew1 = ver27(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver27[(int) (43)];};
 //BA.debugLineNum = 3451;BA.debugLine="If error_level = \"Q\" Then ew2 = ver27(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver27[(int) (47)];};
 //BA.debugLineNum = 3453;BA.debugLine="If error_level = \"H\" Then block1 = ver27(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver27[(int) (48)];};
 //BA.debugLineNum = 3454;BA.debugLine="If error_level = \"H\" Then block2 = ver27(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver27[(int) (52)];};
 //BA.debugLineNum = 3455;BA.debugLine="If error_level = \"H\" Then dw1 = ver27(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver27[(int) (50)];};
 //BA.debugLineNum = 3456;BA.debugLine="If error_level = \"H\" Then dw2 = ver27(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver27[(int) (54)];};
 //BA.debugLineNum = 3457;BA.debugLine="If error_level = \"H\" Then ew1 = ver27(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver27[(int) (51)];};
 //BA.debugLineNum = 3458;BA.debugLine="If error_level = \"H\" Then ew2 = ver27(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver27[(int) (55)];};
 //BA.debugLineNum = 3460;BA.debugLine="If error_level = \"L\" Then tel2 = ver27(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver27[(int) (76)];};
 //BA.debugLineNum = 3461;BA.debugLine="If error_level = \"M\" Then tel2 = ver27(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver27[(int) (77)];};
 //BA.debugLineNum = 3462;BA.debugLine="If error_level = \"Q\" Then tel2 = ver27(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver27[(int) (78)];};
 //BA.debugLineNum = 3463;BA.debugLine="If error_level = \"H\" Then tel2 = ver27(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver27[(int) (79)];};
 break; }
case 28: {
 //BA.debugLineNum = 3465;BA.debugLine="max_mod = ver28(12)";
_max_mod = _ver28[(int) (12)];
 //BA.debugLineNum = 3466;BA.debugLine="qr_size = ver28(1)";
_qr_size = _ver28[(int) (1)];
 //BA.debugLineNum = 3468;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver2";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver28[(int) (20)];};
 //BA.debugLineNum = 3469;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver2";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver28[(int) (21)];};
 //BA.debugLineNum = 3470;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver2";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver28[(int) (22)];};
 //BA.debugLineNum = 3471;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver2";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver28[(int) (23)];};
 //BA.debugLineNum = 3473;BA.debugLine="If error_level = \"L\" Then block1 = ver28(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver28[(int) (24)];};
 //BA.debugLineNum = 3474;BA.debugLine="If error_level = \"L\" Then block2 = ver28(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver28[(int) (28)];};
 //BA.debugLineNum = 3475;BA.debugLine="If error_level = \"L\" Then dw1 = ver28(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver28[(int) (26)];};
 //BA.debugLineNum = 3476;BA.debugLine="If error_level = \"L\" Then dw2 = ver28(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver28[(int) (30)];};
 //BA.debugLineNum = 3477;BA.debugLine="If error_level = \"L\" Then ew1 = ver28(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver28[(int) (27)];};
 //BA.debugLineNum = 3478;BA.debugLine="If error_level = \"L\" Then ew2 = ver28(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver28[(int) (31)];};
 //BA.debugLineNum = 3480;BA.debugLine="If error_level = \"M\" Then block1 = ver28(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver28[(int) (32)];};
 //BA.debugLineNum = 3481;BA.debugLine="If error_level = \"M\" Then block2 = ver28(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver28[(int) (36)];};
 //BA.debugLineNum = 3482;BA.debugLine="If error_level = \"M\" Then dw1 = ver28(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver28[(int) (34)];};
 //BA.debugLineNum = 3483;BA.debugLine="If error_level = \"M\" Then dw2 = ver28(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver28[(int) (38)];};
 //BA.debugLineNum = 3484;BA.debugLine="If error_level = \"M\" Then ew1 = ver28(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver28[(int) (35)];};
 //BA.debugLineNum = 3485;BA.debugLine="If error_level = \"M\" Then ew2 = ver28(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver28[(int) (39)];};
 //BA.debugLineNum = 3487;BA.debugLine="If error_level = \"Q\" Then block1 = ver28(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver28[(int) (40)];};
 //BA.debugLineNum = 3488;BA.debugLine="If error_level = \"Q\" Then block2 = ver28(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver28[(int) (44)];};
 //BA.debugLineNum = 3489;BA.debugLine="If error_level = \"Q\" Then dw1 = ver28(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver28[(int) (42)];};
 //BA.debugLineNum = 3490;BA.debugLine="If error_level = \"Q\" Then dw2 = ver28(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver28[(int) (46)];};
 //BA.debugLineNum = 3491;BA.debugLine="If error_level = \"Q\" Then ew1 = ver28(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver28[(int) (43)];};
 //BA.debugLineNum = 3492;BA.debugLine="If error_level = \"Q\" Then ew2 = ver28(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver28[(int) (47)];};
 //BA.debugLineNum = 3494;BA.debugLine="If error_level = \"H\" Then block1 = ver28(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver28[(int) (48)];};
 //BA.debugLineNum = 3495;BA.debugLine="If error_level = \"H\" Then block2 = ver28(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver28[(int) (52)];};
 //BA.debugLineNum = 3496;BA.debugLine="If error_level = \"H\" Then dw1 = ver28(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver28[(int) (50)];};
 //BA.debugLineNum = 3497;BA.debugLine="If error_level = \"H\" Then dw2 = ver28(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver28[(int) (54)];};
 //BA.debugLineNum = 3498;BA.debugLine="If error_level = \"H\" Then ew1 = ver28(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver28[(int) (51)];};
 //BA.debugLineNum = 3499;BA.debugLine="If error_level = \"H\" Then ew2 = ver28(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver28[(int) (55)];};
 //BA.debugLineNum = 3501;BA.debugLine="If error_level = \"L\" Then tel2 = ver28(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver28[(int) (76)];};
 //BA.debugLineNum = 3502;BA.debugLine="If error_level = \"M\" Then tel2 = ver28(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver28[(int) (77)];};
 //BA.debugLineNum = 3503;BA.debugLine="If error_level = \"Q\" Then tel2 = ver28(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver28[(int) (78)];};
 //BA.debugLineNum = 3504;BA.debugLine="If error_level = \"H\" Then tel2 = ver28(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver28[(int) (79)];};
 break; }
case 29: {
 //BA.debugLineNum = 3506;BA.debugLine="max_mod = ver29(12)";
_max_mod = _ver29[(int) (12)];
 //BA.debugLineNum = 3507;BA.debugLine="qr_size = ver29(1)";
_qr_size = _ver29[(int) (1)];
 //BA.debugLineNum = 3509;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver2";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver29[(int) (20)];};
 //BA.debugLineNum = 3510;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver2";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver29[(int) (21)];};
 //BA.debugLineNum = 3511;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver2";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver29[(int) (22)];};
 //BA.debugLineNum = 3512;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver2";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver29[(int) (23)];};
 //BA.debugLineNum = 3514;BA.debugLine="If error_level = \"L\" Then block1 = ver29(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver29[(int) (24)];};
 //BA.debugLineNum = 3515;BA.debugLine="If error_level = \"L\" Then block2 = ver29(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver29[(int) (28)];};
 //BA.debugLineNum = 3516;BA.debugLine="If error_level = \"L\" Then dw1 = ver29(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver29[(int) (26)];};
 //BA.debugLineNum = 3517;BA.debugLine="If error_level = \"L\" Then dw2 = ver29(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver29[(int) (30)];};
 //BA.debugLineNum = 3518;BA.debugLine="If error_level = \"L\" Then ew1 = ver29(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver29[(int) (27)];};
 //BA.debugLineNum = 3519;BA.debugLine="If error_level = \"L\" Then ew2 = ver29(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver29[(int) (31)];};
 //BA.debugLineNum = 3521;BA.debugLine="If error_level = \"M\" Then block1 = ver29(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver29[(int) (32)];};
 //BA.debugLineNum = 3522;BA.debugLine="If error_level = \"M\" Then block2 = ver29(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver29[(int) (36)];};
 //BA.debugLineNum = 3523;BA.debugLine="If error_level = \"M\" Then dw1 = ver29(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver29[(int) (34)];};
 //BA.debugLineNum = 3524;BA.debugLine="If error_level = \"M\" Then dw2 = ver29(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver29[(int) (38)];};
 //BA.debugLineNum = 3525;BA.debugLine="If error_level = \"M\" Then ew1 = ver29(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver29[(int) (35)];};
 //BA.debugLineNum = 3526;BA.debugLine="If error_level = \"M\" Then ew2 = ver29(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver29[(int) (39)];};
 //BA.debugLineNum = 3528;BA.debugLine="If error_level = \"Q\" Then block1 = ver29(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver29[(int) (40)];};
 //BA.debugLineNum = 3529;BA.debugLine="If error_level = \"Q\" Then block2 = ver29(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver29[(int) (44)];};
 //BA.debugLineNum = 3530;BA.debugLine="If error_level = \"Q\" Then dw1 = ver29(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver29[(int) (42)];};
 //BA.debugLineNum = 3531;BA.debugLine="If error_level = \"Q\" Then dw2 = ver29(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver29[(int) (46)];};
 //BA.debugLineNum = 3532;BA.debugLine="If error_level = \"Q\" Then ew1 = ver29(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver29[(int) (43)];};
 //BA.debugLineNum = 3533;BA.debugLine="If error_level = \"Q\" Then ew2 = ver29(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver29[(int) (47)];};
 //BA.debugLineNum = 3535;BA.debugLine="If error_level = \"H\" Then block1 = ver29(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver29[(int) (48)];};
 //BA.debugLineNum = 3536;BA.debugLine="If error_level = \"H\" Then block2 = ver29(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver29[(int) (52)];};
 //BA.debugLineNum = 3537;BA.debugLine="If error_level = \"H\" Then dw1 = ver29(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver29[(int) (50)];};
 //BA.debugLineNum = 3538;BA.debugLine="If error_level = \"H\" Then dw2 = ver29(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver29[(int) (54)];};
 //BA.debugLineNum = 3539;BA.debugLine="If error_level = \"H\" Then ew1 = ver29(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver29[(int) (51)];};
 //BA.debugLineNum = 3540;BA.debugLine="If error_level = \"H\" Then ew2 = ver29(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver29[(int) (55)];};
 //BA.debugLineNum = 3542;BA.debugLine="If error_level = \"L\" Then tel2 = ver29(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver29[(int) (76)];};
 //BA.debugLineNum = 3543;BA.debugLine="If error_level = \"M\" Then tel2 = ver29(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver29[(int) (77)];};
 //BA.debugLineNum = 3544;BA.debugLine="If error_level = \"Q\" Then tel2 = ver29(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver29[(int) (78)];};
 //BA.debugLineNum = 3545;BA.debugLine="If error_level = \"H\" Then tel2 = ver29(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver29[(int) (79)];};
 break; }
case 30: {
 //BA.debugLineNum = 3547;BA.debugLine="max_mod = ver30(12)";
_max_mod = _ver30[(int) (12)];
 //BA.debugLineNum = 3548;BA.debugLine="qr_size = ver30(1)";
_qr_size = _ver30[(int) (1)];
 //BA.debugLineNum = 3550;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver3";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver30[(int) (20)];};
 //BA.debugLineNum = 3551;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver3";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver30[(int) (21)];};
 //BA.debugLineNum = 3552;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver3";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver30[(int) (22)];};
 //BA.debugLineNum = 3553;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver3";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver30[(int) (23)];};
 //BA.debugLineNum = 3555;BA.debugLine="If error_level = \"L\" Then block1 = ver30(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver30[(int) (24)];};
 //BA.debugLineNum = 3556;BA.debugLine="If error_level = \"L\" Then block2 = ver30(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver30[(int) (28)];};
 //BA.debugLineNum = 3557;BA.debugLine="If error_level = \"L\" Then dw1 = ver30(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver30[(int) (26)];};
 //BA.debugLineNum = 3558;BA.debugLine="If error_level = \"L\" Then dw2 = ver30(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver30[(int) (30)];};
 //BA.debugLineNum = 3559;BA.debugLine="If error_level = \"L\" Then ew1 = ver30(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver30[(int) (27)];};
 //BA.debugLineNum = 3560;BA.debugLine="If error_level = \"L\" Then ew2 = ver30(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver30[(int) (31)];};
 //BA.debugLineNum = 3562;BA.debugLine="If error_level = \"M\" Then block1 = ver30(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver30[(int) (32)];};
 //BA.debugLineNum = 3563;BA.debugLine="If error_level = \"M\" Then block2 = ver30(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver30[(int) (36)];};
 //BA.debugLineNum = 3564;BA.debugLine="If error_level = \"M\" Then dw1 = ver30(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver30[(int) (34)];};
 //BA.debugLineNum = 3565;BA.debugLine="If error_level = \"M\" Then dw2 = ver30(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver30[(int) (38)];};
 //BA.debugLineNum = 3566;BA.debugLine="If error_level = \"M\" Then ew1 = ver30(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver30[(int) (35)];};
 //BA.debugLineNum = 3567;BA.debugLine="If error_level = \"M\" Then ew2 = ver30(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver30[(int) (39)];};
 //BA.debugLineNum = 3569;BA.debugLine="If error_level = \"Q\" Then block1 = ver30(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver30[(int) (40)];};
 //BA.debugLineNum = 3570;BA.debugLine="If error_level = \"Q\" Then block2 = ver30(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver30[(int) (44)];};
 //BA.debugLineNum = 3571;BA.debugLine="If error_level = \"Q\" Then dw1 = ver30(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver30[(int) (42)];};
 //BA.debugLineNum = 3572;BA.debugLine="If error_level = \"Q\" Then dw2 = ver30(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver30[(int) (46)];};
 //BA.debugLineNum = 3573;BA.debugLine="If error_level = \"Q\" Then ew1 = ver30(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver30[(int) (43)];};
 //BA.debugLineNum = 3574;BA.debugLine="If error_level = \"Q\" Then ew2 = ver30(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver30[(int) (47)];};
 //BA.debugLineNum = 3576;BA.debugLine="If error_level = \"H\" Then block1 = ver30(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver30[(int) (48)];};
 //BA.debugLineNum = 3577;BA.debugLine="If error_level = \"H\" Then block2 = ver30(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver30[(int) (52)];};
 //BA.debugLineNum = 3578;BA.debugLine="If error_level = \"H\" Then dw1 = ver30(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver30[(int) (50)];};
 //BA.debugLineNum = 3579;BA.debugLine="If error_level = \"H\" Then dw2 = ver30(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver30[(int) (54)];};
 //BA.debugLineNum = 3580;BA.debugLine="If error_level = \"H\" Then ew1 = ver30(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver30[(int) (51)];};
 //BA.debugLineNum = 3581;BA.debugLine="If error_level = \"H\" Then ew2 = ver30(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver30[(int) (55)];};
 //BA.debugLineNum = 3583;BA.debugLine="If error_level = \"L\" Then tel2 = ver30(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver30[(int) (76)];};
 //BA.debugLineNum = 3584;BA.debugLine="If error_level = \"M\" Then tel2 = ver30(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver30[(int) (77)];};
 //BA.debugLineNum = 3585;BA.debugLine="If error_level = \"Q\" Then tel2 = ver30(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver30[(int) (78)];};
 //BA.debugLineNum = 3586;BA.debugLine="If error_level = \"H\" Then tel2 = ver30(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver30[(int) (79)];};
 break; }
case 31: {
 //BA.debugLineNum = 3588;BA.debugLine="max_mod = ver31(12)";
_max_mod = _ver31[(int) (12)];
 //BA.debugLineNum = 3589;BA.debugLine="qr_size = ver31(1)";
_qr_size = _ver31[(int) (1)];
 //BA.debugLineNum = 3591;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver3";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver31[(int) (20)];};
 //BA.debugLineNum = 3592;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver3";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver31[(int) (21)];};
 //BA.debugLineNum = 3593;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver3";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver31[(int) (22)];};
 //BA.debugLineNum = 3594;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver3";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver31[(int) (23)];};
 //BA.debugLineNum = 3596;BA.debugLine="If error_level = \"L\" Then block1 = ver31(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver31[(int) (24)];};
 //BA.debugLineNum = 3597;BA.debugLine="If error_level = \"L\" Then block2 = ver31(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver31[(int) (28)];};
 //BA.debugLineNum = 3598;BA.debugLine="If error_level = \"L\" Then dw1 = ver31(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver31[(int) (26)];};
 //BA.debugLineNum = 3599;BA.debugLine="If error_level = \"L\" Then dw2 = ver31(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver31[(int) (30)];};
 //BA.debugLineNum = 3600;BA.debugLine="If error_level = \"L\" Then ew1 = ver31(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver31[(int) (27)];};
 //BA.debugLineNum = 3601;BA.debugLine="If error_level = \"L\" Then ew2 = ver31(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver31[(int) (31)];};
 //BA.debugLineNum = 3603;BA.debugLine="If error_level = \"M\" Then block1 = ver31(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver31[(int) (32)];};
 //BA.debugLineNum = 3604;BA.debugLine="If error_level = \"M\" Then block2 = ver31(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver31[(int) (36)];};
 //BA.debugLineNum = 3605;BA.debugLine="If error_level = \"M\" Then dw1 = ver31(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver31[(int) (34)];};
 //BA.debugLineNum = 3606;BA.debugLine="If error_level = \"M\" Then dw2 = ver31(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver31[(int) (38)];};
 //BA.debugLineNum = 3607;BA.debugLine="If error_level = \"M\" Then ew1 = ver31(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver31[(int) (35)];};
 //BA.debugLineNum = 3608;BA.debugLine="If error_level = \"M\" Then ew2 = ver31(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver31[(int) (39)];};
 //BA.debugLineNum = 3610;BA.debugLine="If error_level = \"Q\" Then block1 = ver31(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver31[(int) (40)];};
 //BA.debugLineNum = 3611;BA.debugLine="If error_level = \"Q\" Then block2 = ver31(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver31[(int) (44)];};
 //BA.debugLineNum = 3612;BA.debugLine="If error_level = \"Q\" Then dw1 = ver31(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver31[(int) (42)];};
 //BA.debugLineNum = 3613;BA.debugLine="If error_level = \"Q\" Then dw2 = ver31(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver31[(int) (46)];};
 //BA.debugLineNum = 3614;BA.debugLine="If error_level = \"Q\" Then ew1 = ver31(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver31[(int) (43)];};
 //BA.debugLineNum = 3615;BA.debugLine="If error_level = \"Q\" Then ew2 = ver31(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver31[(int) (47)];};
 //BA.debugLineNum = 3617;BA.debugLine="If error_level = \"H\" Then block1 = ver31(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver31[(int) (48)];};
 //BA.debugLineNum = 3618;BA.debugLine="If error_level = \"H\" Then block2 = ver31(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver31[(int) (52)];};
 //BA.debugLineNum = 3619;BA.debugLine="If error_level = \"H\" Then dw1 = ver31(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver31[(int) (50)];};
 //BA.debugLineNum = 3620;BA.debugLine="If error_level = \"H\" Then dw2 = ver31(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver31[(int) (54)];};
 //BA.debugLineNum = 3621;BA.debugLine="If error_level = \"H\" Then ew1 = ver31(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver31[(int) (51)];};
 //BA.debugLineNum = 3622;BA.debugLine="If error_level = \"H\" Then ew2 = ver31(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver31[(int) (55)];};
 //BA.debugLineNum = 3624;BA.debugLine="If error_level = \"L\" Then tel2 = ver31(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver31[(int) (76)];};
 //BA.debugLineNum = 3625;BA.debugLine="If error_level = \"M\" Then tel2 = ver31(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver31[(int) (77)];};
 //BA.debugLineNum = 3626;BA.debugLine="If error_level = \"Q\" Then tel2 = ver31(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver31[(int) (78)];};
 //BA.debugLineNum = 3627;BA.debugLine="If error_level = \"H\" Then tel2 = ver31(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver31[(int) (79)];};
 break; }
case 32: {
 //BA.debugLineNum = 3629;BA.debugLine="max_mod = ver32(12)";
_max_mod = _ver32[(int) (12)];
 //BA.debugLineNum = 3630;BA.debugLine="qr_size = ver32(1)";
_qr_size = _ver32[(int) (1)];
 //BA.debugLineNum = 3632;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver3";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver32[(int) (20)];};
 //BA.debugLineNum = 3633;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver3";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver32[(int) (21)];};
 //BA.debugLineNum = 3634;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver3";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver32[(int) (22)];};
 //BA.debugLineNum = 3635;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver3";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver32[(int) (23)];};
 //BA.debugLineNum = 3637;BA.debugLine="If error_level = \"L\" Then block1 = ver32(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver32[(int) (24)];};
 //BA.debugLineNum = 3638;BA.debugLine="If error_level = \"L\" Then block2 = ver32(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver32[(int) (28)];};
 //BA.debugLineNum = 3639;BA.debugLine="If error_level = \"L\" Then dw1 = ver32(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver32[(int) (26)];};
 //BA.debugLineNum = 3640;BA.debugLine="If error_level = \"L\" Then dw2 = ver32(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver32[(int) (30)];};
 //BA.debugLineNum = 3641;BA.debugLine="If error_level = \"L\" Then ew1 = ver32(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver32[(int) (27)];};
 //BA.debugLineNum = 3642;BA.debugLine="If error_level = \"L\" Then ew2 = ver32(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver32[(int) (31)];};
 //BA.debugLineNum = 3644;BA.debugLine="If error_level = \"M\" Then block1 = ver32(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver32[(int) (32)];};
 //BA.debugLineNum = 3645;BA.debugLine="If error_level = \"M\" Then block2 = ver32(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver32[(int) (36)];};
 //BA.debugLineNum = 3646;BA.debugLine="If error_level = \"M\" Then dw1 = ver32(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver32[(int) (34)];};
 //BA.debugLineNum = 3647;BA.debugLine="If error_level = \"M\" Then dw2 = ver32(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver32[(int) (38)];};
 //BA.debugLineNum = 3648;BA.debugLine="If error_level = \"M\" Then ew1 = ver32(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver32[(int) (35)];};
 //BA.debugLineNum = 3649;BA.debugLine="If error_level = \"M\" Then ew2 = ver32(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver32[(int) (39)];};
 //BA.debugLineNum = 3651;BA.debugLine="If error_level = \"Q\" Then block1 = ver32(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver32[(int) (40)];};
 //BA.debugLineNum = 3652;BA.debugLine="If error_level = \"Q\" Then block2 = ver32(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver32[(int) (44)];};
 //BA.debugLineNum = 3653;BA.debugLine="If error_level = \"Q\" Then dw1 = ver32(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver32[(int) (42)];};
 //BA.debugLineNum = 3654;BA.debugLine="If error_level = \"Q\" Then dw2 = ver32(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver32[(int) (46)];};
 //BA.debugLineNum = 3655;BA.debugLine="If error_level = \"Q\" Then ew1 = ver32(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver32[(int) (43)];};
 //BA.debugLineNum = 3656;BA.debugLine="If error_level = \"Q\" Then ew2 = ver32(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver32[(int) (47)];};
 //BA.debugLineNum = 3658;BA.debugLine="If error_level = \"H\" Then block1 = ver32(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver32[(int) (48)];};
 //BA.debugLineNum = 3659;BA.debugLine="If error_level = \"H\" Then block2 = ver32(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver32[(int) (52)];};
 //BA.debugLineNum = 3660;BA.debugLine="If error_level = \"H\" Then dw1 = ver32(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver32[(int) (50)];};
 //BA.debugLineNum = 3661;BA.debugLine="If error_level = \"H\" Then dw2 = ver32(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver32[(int) (54)];};
 //BA.debugLineNum = 3662;BA.debugLine="If error_level = \"H\" Then ew1 = ver32(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver32[(int) (51)];};
 //BA.debugLineNum = 3663;BA.debugLine="If error_level = \"H\" Then ew2 = ver32(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver32[(int) (55)];};
 //BA.debugLineNum = 3665;BA.debugLine="If error_level = \"L\" Then tel2 = ver32(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver32[(int) (76)];};
 //BA.debugLineNum = 3666;BA.debugLine="If error_level = \"M\" Then tel2 = ver32(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver32[(int) (77)];};
 //BA.debugLineNum = 3667;BA.debugLine="If error_level = \"Q\" Then tel2 = ver32(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver32[(int) (78)];};
 //BA.debugLineNum = 3668;BA.debugLine="If error_level = \"H\" Then tel2 = ver32(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver32[(int) (79)];};
 break; }
case 33: {
 //BA.debugLineNum = 3670;BA.debugLine="max_mod = ver33(12)";
_max_mod = _ver33[(int) (12)];
 //BA.debugLineNum = 3671;BA.debugLine="qr_size = ver33(1)";
_qr_size = _ver33[(int) (1)];
 //BA.debugLineNum = 3673;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver3";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver33[(int) (20)];};
 //BA.debugLineNum = 3674;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver3";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver33[(int) (21)];};
 //BA.debugLineNum = 3675;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver3";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver33[(int) (22)];};
 //BA.debugLineNum = 3676;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver3";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver33[(int) (23)];};
 //BA.debugLineNum = 3678;BA.debugLine="If error_level = \"L\" Then block1 = ver33(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver33[(int) (24)];};
 //BA.debugLineNum = 3679;BA.debugLine="If error_level = \"L\" Then block2 = ver33(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver33[(int) (28)];};
 //BA.debugLineNum = 3680;BA.debugLine="If error_level = \"L\" Then dw1 = ver33(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver33[(int) (26)];};
 //BA.debugLineNum = 3681;BA.debugLine="If error_level = \"L\" Then dw2 = ver33(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver33[(int) (30)];};
 //BA.debugLineNum = 3682;BA.debugLine="If error_level = \"L\" Then ew1 = ver33(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver33[(int) (27)];};
 //BA.debugLineNum = 3683;BA.debugLine="If error_level = \"L\" Then ew2 = ver33(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver33[(int) (31)];};
 //BA.debugLineNum = 3685;BA.debugLine="If error_level = \"M\" Then block1 = ver33(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver33[(int) (32)];};
 //BA.debugLineNum = 3686;BA.debugLine="If error_level = \"M\" Then block2 = ver33(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver33[(int) (36)];};
 //BA.debugLineNum = 3687;BA.debugLine="If error_level = \"M\" Then dw1 = ver33(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver33[(int) (34)];};
 //BA.debugLineNum = 3688;BA.debugLine="If error_level = \"M\" Then dw2 = ver33(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver33[(int) (38)];};
 //BA.debugLineNum = 3689;BA.debugLine="If error_level = \"M\" Then ew1 = ver33(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver33[(int) (35)];};
 //BA.debugLineNum = 3690;BA.debugLine="If error_level = \"M\" Then ew2 = ver33(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver33[(int) (39)];};
 //BA.debugLineNum = 3692;BA.debugLine="If error_level = \"Q\" Then block1 = ver33(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver33[(int) (40)];};
 //BA.debugLineNum = 3693;BA.debugLine="If error_level = \"Q\" Then block2 = ver33(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver33[(int) (44)];};
 //BA.debugLineNum = 3694;BA.debugLine="If error_level = \"Q\" Then dw1 = ver33(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver33[(int) (42)];};
 //BA.debugLineNum = 3695;BA.debugLine="If error_level = \"Q\" Then dw2 = ver33(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver33[(int) (46)];};
 //BA.debugLineNum = 3696;BA.debugLine="If error_level = \"Q\" Then ew1 = ver33(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver33[(int) (43)];};
 //BA.debugLineNum = 3697;BA.debugLine="If error_level = \"Q\" Then ew2 = ver33(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver33[(int) (47)];};
 //BA.debugLineNum = 3699;BA.debugLine="If error_level = \"H\" Then block1 = ver33(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver33[(int) (48)];};
 //BA.debugLineNum = 3700;BA.debugLine="If error_level = \"H\" Then block2 = ver33(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver33[(int) (52)];};
 //BA.debugLineNum = 3701;BA.debugLine="If error_level = \"H\" Then dw1 = ver33(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver33[(int) (50)];};
 //BA.debugLineNum = 3702;BA.debugLine="If error_level = \"H\" Then dw2 = ver33(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver33[(int) (54)];};
 //BA.debugLineNum = 3703;BA.debugLine="If error_level = \"H\" Then ew1 = ver33(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver33[(int) (51)];};
 //BA.debugLineNum = 3704;BA.debugLine="If error_level = \"H\" Then ew2 = ver33(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver33[(int) (55)];};
 //BA.debugLineNum = 3706;BA.debugLine="If error_level = \"L\" Then tel2 = ver33(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver33[(int) (76)];};
 //BA.debugLineNum = 3707;BA.debugLine="If error_level = \"M\" Then tel2 = ver33(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver33[(int) (77)];};
 //BA.debugLineNum = 3708;BA.debugLine="If error_level = \"Q\" Then tel2 = ver33(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver33[(int) (78)];};
 //BA.debugLineNum = 3709;BA.debugLine="If error_level = \"H\" Then tel2 = ver33(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver33[(int) (79)];};
 break; }
case 34: {
 //BA.debugLineNum = 3711;BA.debugLine="max_mod = ver34(12)";
_max_mod = _ver34[(int) (12)];
 //BA.debugLineNum = 3712;BA.debugLine="qr_size = ver34(1)";
_qr_size = _ver34[(int) (1)];
 //BA.debugLineNum = 3714;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver3";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver34[(int) (20)];};
 //BA.debugLineNum = 3715;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver3";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver34[(int) (21)];};
 //BA.debugLineNum = 3716;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver3";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver34[(int) (22)];};
 //BA.debugLineNum = 3717;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver3";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver34[(int) (23)];};
 //BA.debugLineNum = 3719;BA.debugLine="If error_level = \"L\" Then block1 = ver34(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver34[(int) (24)];};
 //BA.debugLineNum = 3720;BA.debugLine="If error_level = \"L\" Then block2 = ver34(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver34[(int) (28)];};
 //BA.debugLineNum = 3721;BA.debugLine="If error_level = \"L\" Then dw1 = ver34(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver34[(int) (26)];};
 //BA.debugLineNum = 3722;BA.debugLine="If error_level = \"L\" Then dw2 = ver34(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver34[(int) (30)];};
 //BA.debugLineNum = 3723;BA.debugLine="If error_level = \"L\" Then ew1 = ver34(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver34[(int) (27)];};
 //BA.debugLineNum = 3724;BA.debugLine="If error_level = \"L\" Then ew2 = ver34(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver34[(int) (31)];};
 //BA.debugLineNum = 3726;BA.debugLine="If error_level = \"M\" Then block1 = ver34(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver34[(int) (32)];};
 //BA.debugLineNum = 3727;BA.debugLine="If error_level = \"M\" Then block2 = ver34(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver34[(int) (36)];};
 //BA.debugLineNum = 3728;BA.debugLine="If error_level = \"M\" Then dw1 = ver34(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver34[(int) (34)];};
 //BA.debugLineNum = 3729;BA.debugLine="If error_level = \"M\" Then dw2 = ver34(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver34[(int) (38)];};
 //BA.debugLineNum = 3730;BA.debugLine="If error_level = \"M\" Then ew1 = ver34(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver34[(int) (35)];};
 //BA.debugLineNum = 3731;BA.debugLine="If error_level = \"M\" Then ew2 = ver34(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver34[(int) (39)];};
 //BA.debugLineNum = 3733;BA.debugLine="If error_level = \"Q\" Then block1 = ver34(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver34[(int) (40)];};
 //BA.debugLineNum = 3734;BA.debugLine="If error_level = \"Q\" Then block2 = ver34(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver34[(int) (44)];};
 //BA.debugLineNum = 3735;BA.debugLine="If error_level = \"Q\" Then dw1 = ver34(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver34[(int) (42)];};
 //BA.debugLineNum = 3736;BA.debugLine="If error_level = \"Q\" Then dw2 = ver34(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver34[(int) (46)];};
 //BA.debugLineNum = 3737;BA.debugLine="If error_level = \"Q\" Then ew1 = ver34(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver34[(int) (43)];};
 //BA.debugLineNum = 3738;BA.debugLine="If error_level = \"Q\" Then ew2 = ver34(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver34[(int) (47)];};
 //BA.debugLineNum = 3740;BA.debugLine="If error_level = \"H\" Then block1 = ver34(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver34[(int) (48)];};
 //BA.debugLineNum = 3741;BA.debugLine="If error_level = \"H\" Then block2 = ver34(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver34[(int) (52)];};
 //BA.debugLineNum = 3742;BA.debugLine="If error_level = \"H\" Then dw1 = ver34(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver34[(int) (50)];};
 //BA.debugLineNum = 3743;BA.debugLine="If error_level = \"H\" Then dw2 = ver34(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver34[(int) (54)];};
 //BA.debugLineNum = 3744;BA.debugLine="If error_level = \"H\" Then ew1 = ver34(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver34[(int) (51)];};
 //BA.debugLineNum = 3745;BA.debugLine="If error_level = \"H\" Then ew2 = ver34(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver34[(int) (55)];};
 //BA.debugLineNum = 3747;BA.debugLine="If error_level = \"L\" Then tel2 = ver34(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver34[(int) (76)];};
 //BA.debugLineNum = 3748;BA.debugLine="If error_level = \"M\" Then tel2 = ver34(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver34[(int) (77)];};
 //BA.debugLineNum = 3749;BA.debugLine="If error_level = \"Q\" Then tel2 = ver34(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver34[(int) (78)];};
 //BA.debugLineNum = 3750;BA.debugLine="If error_level = \"H\" Then tel2 = ver34(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver34[(int) (79)];};
 break; }
case 35: {
 //BA.debugLineNum = 3752;BA.debugLine="max_mod = ver35(12)";
_max_mod = _ver35[(int) (12)];
 //BA.debugLineNum = 3753;BA.debugLine="qr_size = ver35(1)";
_qr_size = _ver35[(int) (1)];
 //BA.debugLineNum = 3755;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver3";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver35[(int) (20)];};
 //BA.debugLineNum = 3756;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver3";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver35[(int) (21)];};
 //BA.debugLineNum = 3757;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver3";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver35[(int) (22)];};
 //BA.debugLineNum = 3758;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver3";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver35[(int) (23)];};
 //BA.debugLineNum = 3760;BA.debugLine="If error_level = \"L\" Then block1 = ver35(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver35[(int) (24)];};
 //BA.debugLineNum = 3761;BA.debugLine="If error_level = \"L\" Then block2 = ver35(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver35[(int) (28)];};
 //BA.debugLineNum = 3762;BA.debugLine="If error_level = \"L\" Then dw1 = ver35(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver35[(int) (26)];};
 //BA.debugLineNum = 3763;BA.debugLine="If error_level = \"L\" Then dw2 = ver35(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver35[(int) (30)];};
 //BA.debugLineNum = 3764;BA.debugLine="If error_level = \"L\" Then ew1 = ver35(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver35[(int) (27)];};
 //BA.debugLineNum = 3765;BA.debugLine="If error_level = \"L\" Then ew2 = ver35(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver35[(int) (31)];};
 //BA.debugLineNum = 3767;BA.debugLine="If error_level = \"M\" Then block1 = ver35(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver35[(int) (32)];};
 //BA.debugLineNum = 3768;BA.debugLine="If error_level = \"M\" Then block2 = ver35(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver35[(int) (36)];};
 //BA.debugLineNum = 3769;BA.debugLine="If error_level = \"M\" Then dw1 = ver35(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver35[(int) (34)];};
 //BA.debugLineNum = 3770;BA.debugLine="If error_level = \"M\" Then dw2 = ver35(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver35[(int) (38)];};
 //BA.debugLineNum = 3771;BA.debugLine="If error_level = \"M\" Then ew1 = ver35(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver35[(int) (35)];};
 //BA.debugLineNum = 3772;BA.debugLine="If error_level = \"M\" Then ew2 = ver35(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver35[(int) (39)];};
 //BA.debugLineNum = 3774;BA.debugLine="If error_level = \"Q\" Then block1 = ver35(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver35[(int) (40)];};
 //BA.debugLineNum = 3775;BA.debugLine="If error_level = \"Q\" Then block2 = ver35(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver35[(int) (44)];};
 //BA.debugLineNum = 3776;BA.debugLine="If error_level = \"Q\" Then dw1 = ver35(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver35[(int) (42)];};
 //BA.debugLineNum = 3777;BA.debugLine="If error_level = \"Q\" Then dw2 = ver35(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver35[(int) (46)];};
 //BA.debugLineNum = 3778;BA.debugLine="If error_level = \"Q\" Then ew1 = ver35(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver35[(int) (43)];};
 //BA.debugLineNum = 3779;BA.debugLine="If error_level = \"Q\" Then ew2 = ver35(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver35[(int) (47)];};
 //BA.debugLineNum = 3781;BA.debugLine="If error_level = \"H\" Then block1 = ver35(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver35[(int) (48)];};
 //BA.debugLineNum = 3782;BA.debugLine="If error_level = \"H\" Then block2 = ver35(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver35[(int) (52)];};
 //BA.debugLineNum = 3783;BA.debugLine="If error_level = \"H\" Then dw1 = ver35(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver35[(int) (50)];};
 //BA.debugLineNum = 3784;BA.debugLine="If error_level = \"H\" Then dw2 = ver35(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver35[(int) (54)];};
 //BA.debugLineNum = 3785;BA.debugLine="If error_level = \"H\" Then ew1 = ver35(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver35[(int) (51)];};
 //BA.debugLineNum = 3786;BA.debugLine="If error_level = \"H\" Then ew2 = ver35(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver35[(int) (55)];};
 //BA.debugLineNum = 3788;BA.debugLine="If error_level = \"L\" Then tel2 = ver35(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver35[(int) (76)];};
 //BA.debugLineNum = 3789;BA.debugLine="If error_level = \"M\" Then tel2 = ver35(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver35[(int) (77)];};
 //BA.debugLineNum = 3790;BA.debugLine="If error_level = \"Q\" Then tel2 = ver35(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver35[(int) (78)];};
 //BA.debugLineNum = 3791;BA.debugLine="If error_level = \"H\" Then tel2 = ver35(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver35[(int) (79)];};
 break; }
case 36: {
 //BA.debugLineNum = 3793;BA.debugLine="max_mod = ver36(12)";
_max_mod = _ver36[(int) (12)];
 //BA.debugLineNum = 3794;BA.debugLine="qr_size = ver36(1)";
_qr_size = _ver36[(int) (1)];
 //BA.debugLineNum = 3796;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver3";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver36[(int) (20)];};
 //BA.debugLineNum = 3797;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver3";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver36[(int) (21)];};
 //BA.debugLineNum = 3798;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver3";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver36[(int) (22)];};
 //BA.debugLineNum = 3799;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver3";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver36[(int) (23)];};
 //BA.debugLineNum = 3801;BA.debugLine="If error_level = \"L\" Then block1 = ver36(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver36[(int) (24)];};
 //BA.debugLineNum = 3802;BA.debugLine="If error_level = \"L\" Then block2 = ver36(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver36[(int) (28)];};
 //BA.debugLineNum = 3803;BA.debugLine="If error_level = \"L\" Then dw1 = ver36(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver36[(int) (26)];};
 //BA.debugLineNum = 3804;BA.debugLine="If error_level = \"L\" Then dw2 = ver36(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver36[(int) (30)];};
 //BA.debugLineNum = 3805;BA.debugLine="If error_level = \"L\" Then ew1 = ver36(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver36[(int) (27)];};
 //BA.debugLineNum = 3806;BA.debugLine="If error_level = \"L\" Then ew2 = ver36(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver36[(int) (31)];};
 //BA.debugLineNum = 3808;BA.debugLine="If error_level = \"M\" Then block1 = ver36(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver36[(int) (32)];};
 //BA.debugLineNum = 3809;BA.debugLine="If error_level = \"M\" Then block2 = ver36(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver36[(int) (36)];};
 //BA.debugLineNum = 3810;BA.debugLine="If error_level = \"M\" Then dw1 = ver36(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver36[(int) (34)];};
 //BA.debugLineNum = 3811;BA.debugLine="If error_level = \"M\" Then dw2 = ver36(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver36[(int) (38)];};
 //BA.debugLineNum = 3812;BA.debugLine="If error_level = \"M\" Then ew1 = ver36(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver36[(int) (35)];};
 //BA.debugLineNum = 3813;BA.debugLine="If error_level = \"M\" Then ew2 = ver36(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver36[(int) (39)];};
 //BA.debugLineNum = 3815;BA.debugLine="If error_level = \"Q\" Then block1 = ver36(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver36[(int) (40)];};
 //BA.debugLineNum = 3816;BA.debugLine="If error_level = \"Q\" Then block2 = ver36(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver36[(int) (44)];};
 //BA.debugLineNum = 3817;BA.debugLine="If error_level = \"Q\" Then dw1 = ver36(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver36[(int) (42)];};
 //BA.debugLineNum = 3818;BA.debugLine="If error_level = \"Q\" Then dw2 = ver36(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver36[(int) (46)];};
 //BA.debugLineNum = 3819;BA.debugLine="If error_level = \"Q\" Then ew1 = ver36(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver36[(int) (43)];};
 //BA.debugLineNum = 3820;BA.debugLine="If error_level = \"Q\" Then ew2 = ver36(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver36[(int) (47)];};
 //BA.debugLineNum = 3822;BA.debugLine="If error_level = \"H\" Then block1 = ver36(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver36[(int) (48)];};
 //BA.debugLineNum = 3823;BA.debugLine="If error_level = \"H\" Then block2 = ver36(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver36[(int) (52)];};
 //BA.debugLineNum = 3824;BA.debugLine="If error_level = \"H\" Then dw1 = ver36(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver36[(int) (50)];};
 //BA.debugLineNum = 3825;BA.debugLine="If error_level = \"H\" Then dw2 = ver36(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver36[(int) (54)];};
 //BA.debugLineNum = 3826;BA.debugLine="If error_level = \"H\" Then ew1 = ver36(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver36[(int) (51)];};
 //BA.debugLineNum = 3827;BA.debugLine="If error_level = \"H\" Then ew2 = ver36(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver36[(int) (55)];};
 //BA.debugLineNum = 3829;BA.debugLine="If error_level = \"L\" Then tel2 = ver36(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver36[(int) (76)];};
 //BA.debugLineNum = 3830;BA.debugLine="If error_level = \"M\" Then tel2 = ver36(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver36[(int) (77)];};
 //BA.debugLineNum = 3831;BA.debugLine="If error_level = \"Q\" Then tel2 = ver36(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver36[(int) (78)];};
 //BA.debugLineNum = 3832;BA.debugLine="If error_level = \"H\" Then tel2 = ver36(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver36[(int) (79)];};
 break; }
case 37: {
 //BA.debugLineNum = 3834;BA.debugLine="max_mod = ver37(12)";
_max_mod = _ver37[(int) (12)];
 //BA.debugLineNum = 3835;BA.debugLine="qr_size = ver37(1)";
_qr_size = _ver37[(int) (1)];
 //BA.debugLineNum = 3837;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver3";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver37[(int) (20)];};
 //BA.debugLineNum = 3838;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver3";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver37[(int) (21)];};
 //BA.debugLineNum = 3839;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver3";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver37[(int) (22)];};
 //BA.debugLineNum = 3840;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver3";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver37[(int) (23)];};
 //BA.debugLineNum = 3842;BA.debugLine="If error_level = \"L\" Then block1 = ver37(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver37[(int) (24)];};
 //BA.debugLineNum = 3843;BA.debugLine="If error_level = \"L\" Then block2 = ver37(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver37[(int) (28)];};
 //BA.debugLineNum = 3844;BA.debugLine="If error_level = \"L\" Then dw1 = ver37(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver37[(int) (26)];};
 //BA.debugLineNum = 3845;BA.debugLine="If error_level = \"L\" Then dw2 = ver37(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver37[(int) (30)];};
 //BA.debugLineNum = 3846;BA.debugLine="If error_level = \"L\" Then ew1 = ver37(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver37[(int) (27)];};
 //BA.debugLineNum = 3847;BA.debugLine="If error_level = \"L\" Then ew2 = ver37(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver37[(int) (31)];};
 //BA.debugLineNum = 3849;BA.debugLine="If error_level = \"M\" Then block1 = ver37(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver37[(int) (32)];};
 //BA.debugLineNum = 3850;BA.debugLine="If error_level = \"M\" Then block2 = ver37(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver37[(int) (36)];};
 //BA.debugLineNum = 3851;BA.debugLine="If error_level = \"M\" Then dw1 = ver37(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver37[(int) (34)];};
 //BA.debugLineNum = 3852;BA.debugLine="If error_level = \"M\" Then dw2 = ver37(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver37[(int) (38)];};
 //BA.debugLineNum = 3853;BA.debugLine="If error_level = \"M\" Then ew1 = ver37(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver37[(int) (35)];};
 //BA.debugLineNum = 3854;BA.debugLine="If error_level = \"M\" Then ew2 = ver37(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver37[(int) (39)];};
 //BA.debugLineNum = 3856;BA.debugLine="If error_level = \"Q\" Then block1 = ver37(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver37[(int) (40)];};
 //BA.debugLineNum = 3857;BA.debugLine="If error_level = \"Q\" Then block2 = ver37(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver37[(int) (44)];};
 //BA.debugLineNum = 3858;BA.debugLine="If error_level = \"Q\" Then dw1 = ver37(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver37[(int) (42)];};
 //BA.debugLineNum = 3859;BA.debugLine="If error_level = \"Q\" Then dw2 = ver37(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver37[(int) (46)];};
 //BA.debugLineNum = 3860;BA.debugLine="If error_level = \"Q\" Then ew1 = ver37(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver37[(int) (43)];};
 //BA.debugLineNum = 3861;BA.debugLine="If error_level = \"Q\" Then ew2 = ver37(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver37[(int) (47)];};
 //BA.debugLineNum = 3863;BA.debugLine="If error_level = \"H\" Then block1 = ver37(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver37[(int) (48)];};
 //BA.debugLineNum = 3864;BA.debugLine="If error_level = \"H\" Then block2 = ver37(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver37[(int) (52)];};
 //BA.debugLineNum = 3865;BA.debugLine="If error_level = \"H\" Then dw1 = ver37(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver37[(int) (50)];};
 //BA.debugLineNum = 3866;BA.debugLine="If error_level = \"H\" Then dw2 = ver37(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver37[(int) (54)];};
 //BA.debugLineNum = 3867;BA.debugLine="If error_level = \"H\" Then ew1 = ver37(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver37[(int) (51)];};
 //BA.debugLineNum = 3868;BA.debugLine="If error_level = \"H\" Then ew2 = ver37(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver37[(int) (55)];};
 //BA.debugLineNum = 3870;BA.debugLine="If error_level = \"L\" Then tel2 = ver37(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver37[(int) (76)];};
 //BA.debugLineNum = 3871;BA.debugLine="If error_level = \"M\" Then tel2 = ver37(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver37[(int) (77)];};
 //BA.debugLineNum = 3872;BA.debugLine="If error_level = \"Q\" Then tel2 = ver37(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver37[(int) (78)];};
 //BA.debugLineNum = 3873;BA.debugLine="If error_level = \"H\" Then tel2 = ver37(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver37[(int) (79)];};
 break; }
case 38: {
 //BA.debugLineNum = 3875;BA.debugLine="max_mod = ver38(12)";
_max_mod = _ver38[(int) (12)];
 //BA.debugLineNum = 3876;BA.debugLine="qr_size = ver38(1)";
_qr_size = _ver38[(int) (1)];
 //BA.debugLineNum = 3878;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver3";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver38[(int) (20)];};
 //BA.debugLineNum = 3879;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver3";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver38[(int) (21)];};
 //BA.debugLineNum = 3880;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver3";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver38[(int) (22)];};
 //BA.debugLineNum = 3881;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver3";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver38[(int) (23)];};
 //BA.debugLineNum = 3883;BA.debugLine="If error_level = \"L\" Then block1 = ver38(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver38[(int) (24)];};
 //BA.debugLineNum = 3884;BA.debugLine="If error_level = \"L\" Then block2 = ver38(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver38[(int) (28)];};
 //BA.debugLineNum = 3885;BA.debugLine="If error_level = \"L\" Then dw1 = ver38(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver38[(int) (26)];};
 //BA.debugLineNum = 3886;BA.debugLine="If error_level = \"L\" Then dw2 = ver38(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver38[(int) (30)];};
 //BA.debugLineNum = 3887;BA.debugLine="If error_level = \"L\" Then ew1 = ver38(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver38[(int) (27)];};
 //BA.debugLineNum = 3888;BA.debugLine="If error_level = \"L\" Then ew2 = ver38(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver38[(int) (31)];};
 //BA.debugLineNum = 3890;BA.debugLine="If error_level = \"M\" Then block1 = ver38(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver38[(int) (32)];};
 //BA.debugLineNum = 3891;BA.debugLine="If error_level = \"M\" Then block2 = ver38(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver38[(int) (36)];};
 //BA.debugLineNum = 3892;BA.debugLine="If error_level = \"M\" Then dw1 = ver38(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver38[(int) (34)];};
 //BA.debugLineNum = 3893;BA.debugLine="If error_level = \"M\" Then dw2 = ver38(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver38[(int) (38)];};
 //BA.debugLineNum = 3894;BA.debugLine="If error_level = \"M\" Then ew1 = ver38(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver38[(int) (35)];};
 //BA.debugLineNum = 3895;BA.debugLine="If error_level = \"M\" Then ew2 = ver38(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver38[(int) (39)];};
 //BA.debugLineNum = 3897;BA.debugLine="If error_level = \"Q\" Then block1 = ver38(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver38[(int) (40)];};
 //BA.debugLineNum = 3898;BA.debugLine="If error_level = \"Q\" Then block2 = ver38(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver38[(int) (44)];};
 //BA.debugLineNum = 3899;BA.debugLine="If error_level = \"Q\" Then dw1 = ver38(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver38[(int) (42)];};
 //BA.debugLineNum = 3900;BA.debugLine="If error_level = \"Q\" Then dw2 = ver38(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver38[(int) (46)];};
 //BA.debugLineNum = 3901;BA.debugLine="If error_level = \"Q\" Then ew1 = ver38(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver38[(int) (43)];};
 //BA.debugLineNum = 3902;BA.debugLine="If error_level = \"Q\" Then ew2 = ver38(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver38[(int) (47)];};
 //BA.debugLineNum = 3904;BA.debugLine="If error_level = \"H\" Then block1 = ver38(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver38[(int) (48)];};
 //BA.debugLineNum = 3905;BA.debugLine="If error_level = \"H\" Then block2 = ver38(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver38[(int) (52)];};
 //BA.debugLineNum = 3906;BA.debugLine="If error_level = \"H\" Then dw1 = ver38(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver38[(int) (50)];};
 //BA.debugLineNum = 3907;BA.debugLine="If error_level = \"H\" Then dw2 = ver38(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver38[(int) (54)];};
 //BA.debugLineNum = 3908;BA.debugLine="If error_level = \"H\" Then ew1 = ver38(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver38[(int) (51)];};
 //BA.debugLineNum = 3909;BA.debugLine="If error_level = \"H\" Then ew2 = ver38(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver38[(int) (55)];};
 //BA.debugLineNum = 3911;BA.debugLine="If error_level = \"L\" Then tel2 = ver38(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver38[(int) (76)];};
 //BA.debugLineNum = 3912;BA.debugLine="If error_level = \"M\" Then tel2 = ver38(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver38[(int) (77)];};
 //BA.debugLineNum = 3913;BA.debugLine="If error_level = \"Q\" Then tel2 = ver38(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver38[(int) (78)];};
 //BA.debugLineNum = 3914;BA.debugLine="If error_level = \"H\" Then tel2 = ver38(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver38[(int) (79)];};
 break; }
case 39: {
 //BA.debugLineNum = 3916;BA.debugLine="max_mod = ver39(12)";
_max_mod = _ver39[(int) (12)];
 //BA.debugLineNum = 3917;BA.debugLine="qr_size = ver39(1)";
_qr_size = _ver39[(int) (1)];
 //BA.debugLineNum = 3919;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver3";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver39[(int) (20)];};
 //BA.debugLineNum = 3920;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver3";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver39[(int) (21)];};
 //BA.debugLineNum = 3921;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver3";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver39[(int) (22)];};
 //BA.debugLineNum = 3922;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver3";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver39[(int) (23)];};
 //BA.debugLineNum = 3924;BA.debugLine="If error_level = \"L\" Then block1 = ver39(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver39[(int) (24)];};
 //BA.debugLineNum = 3925;BA.debugLine="If error_level = \"L\" Then block2 = ver39(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver39[(int) (28)];};
 //BA.debugLineNum = 3926;BA.debugLine="If error_level = \"L\" Then dw1 = ver39(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver39[(int) (26)];};
 //BA.debugLineNum = 3927;BA.debugLine="If error_level = \"L\" Then dw2 = ver39(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver39[(int) (30)];};
 //BA.debugLineNum = 3928;BA.debugLine="If error_level = \"L\" Then ew1 = ver39(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver39[(int) (27)];};
 //BA.debugLineNum = 3929;BA.debugLine="If error_level = \"L\" Then ew2 = ver39(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver39[(int) (31)];};
 //BA.debugLineNum = 3931;BA.debugLine="If error_level = \"M\" Then block1 = ver39(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver39[(int) (32)];};
 //BA.debugLineNum = 3932;BA.debugLine="If error_level = \"M\" Then block2 = ver39(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver39[(int) (36)];};
 //BA.debugLineNum = 3933;BA.debugLine="If error_level = \"M\" Then dw1 = ver39(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver39[(int) (34)];};
 //BA.debugLineNum = 3934;BA.debugLine="If error_level = \"M\" Then dw2 = ver39(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver39[(int) (38)];};
 //BA.debugLineNum = 3935;BA.debugLine="If error_level = \"M\" Then ew1 = ver39(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver39[(int) (35)];};
 //BA.debugLineNum = 3936;BA.debugLine="If error_level = \"M\" Then ew2 = ver39(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver39[(int) (39)];};
 //BA.debugLineNum = 3938;BA.debugLine="If error_level = \"Q\" Then block1 = ver39(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver39[(int) (40)];};
 //BA.debugLineNum = 3939;BA.debugLine="If error_level = \"Q\" Then block2 = ver39(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver39[(int) (44)];};
 //BA.debugLineNum = 3940;BA.debugLine="If error_level = \"Q\" Then dw1 = ver39(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver39[(int) (42)];};
 //BA.debugLineNum = 3941;BA.debugLine="If error_level = \"Q\" Then dw2 = ver39(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver39[(int) (46)];};
 //BA.debugLineNum = 3942;BA.debugLine="If error_level = \"Q\" Then ew1 = ver39(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver39[(int) (43)];};
 //BA.debugLineNum = 3943;BA.debugLine="If error_level = \"Q\" Then ew2 = ver39(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver39[(int) (47)];};
 //BA.debugLineNum = 3945;BA.debugLine="If error_level = \"H\" Then block1 = ver39(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver39[(int) (48)];};
 //BA.debugLineNum = 3946;BA.debugLine="If error_level = \"H\" Then block2 = ver39(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver39[(int) (52)];};
 //BA.debugLineNum = 3947;BA.debugLine="If error_level = \"H\" Then dw1 = ver39(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver39[(int) (50)];};
 //BA.debugLineNum = 3948;BA.debugLine="If error_level = \"H\" Then dw2 = ver39(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver39[(int) (54)];};
 //BA.debugLineNum = 3949;BA.debugLine="If error_level = \"H\" Then ew1 = ver39(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver39[(int) (51)];};
 //BA.debugLineNum = 3950;BA.debugLine="If error_level = \"H\" Then ew2 = ver39(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver39[(int) (55)];};
 //BA.debugLineNum = 3952;BA.debugLine="If error_level = \"L\" Then tel2 = ver39(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver39[(int) (76)];};
 //BA.debugLineNum = 3953;BA.debugLine="If error_level = \"M\" Then tel2 = ver39(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver39[(int) (77)];};
 //BA.debugLineNum = 3954;BA.debugLine="If error_level = \"Q\" Then tel2 = ver39(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver39[(int) (78)];};
 //BA.debugLineNum = 3955;BA.debugLine="If error_level = \"H\" Then tel2 = ver39(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver39[(int) (79)];};
 break; }
case 40: {
 //BA.debugLineNum = 3957;BA.debugLine="max_mod = ver40(12)";
_max_mod = _ver40[(int) (12)];
 //BA.debugLineNum = 3958;BA.debugLine="qr_size = ver40(1)";
_qr_size = _ver40[(int) (1)];
 //BA.debugLineNum = 3960;BA.debugLine="If error_level = \"L\" Then max_data_bits = ver4";
if ((_error_level).equals("L")) { 
_max_data_bits = _ver40[(int) (20)];};
 //BA.debugLineNum = 3961;BA.debugLine="If error_level = \"M\" Then max_data_bits = ver4";
if ((_error_level).equals("M")) { 
_max_data_bits = _ver40[(int) (21)];};
 //BA.debugLineNum = 3962;BA.debugLine="If error_level = \"Q\" Then max_data_bits = ver4";
if ((_error_level).equals("Q")) { 
_max_data_bits = _ver40[(int) (22)];};
 //BA.debugLineNum = 3963;BA.debugLine="If error_level = \"H\" Then max_data_bits = ver4";
if ((_error_level).equals("H")) { 
_max_data_bits = _ver40[(int) (23)];};
 //BA.debugLineNum = 3965;BA.debugLine="If error_level = \"L\" Then block1 = ver40(24)";
if ((_error_level).equals("L")) { 
_block1 = _ver40[(int) (24)];};
 //BA.debugLineNum = 3966;BA.debugLine="If error_level = \"L\" Then block2 = ver40(28)";
if ((_error_level).equals("L")) { 
_block2 = _ver40[(int) (28)];};
 //BA.debugLineNum = 3967;BA.debugLine="If error_level = \"L\" Then dw1 = ver40(26)";
if ((_error_level).equals("L")) { 
_dw1 = _ver40[(int) (26)];};
 //BA.debugLineNum = 3968;BA.debugLine="If error_level = \"L\" Then dw2 = ver40(30)";
if ((_error_level).equals("L")) { 
_dw2 = _ver40[(int) (30)];};
 //BA.debugLineNum = 3969;BA.debugLine="If error_level = \"L\" Then ew1 = ver40(27)";
if ((_error_level).equals("L")) { 
_ew1 = _ver40[(int) (27)];};
 //BA.debugLineNum = 3970;BA.debugLine="If error_level = \"L\" Then ew2 = ver40(31)";
if ((_error_level).equals("L")) { 
_ew2 = _ver40[(int) (31)];};
 //BA.debugLineNum = 3972;BA.debugLine="If error_level = \"M\" Then block1 = ver40(32)";
if ((_error_level).equals("M")) { 
_block1 = _ver40[(int) (32)];};
 //BA.debugLineNum = 3973;BA.debugLine="If error_level = \"M\" Then block2 = ver40(36)";
if ((_error_level).equals("M")) { 
_block2 = _ver40[(int) (36)];};
 //BA.debugLineNum = 3974;BA.debugLine="If error_level = \"M\" Then dw1 = ver40(34)";
if ((_error_level).equals("M")) { 
_dw1 = _ver40[(int) (34)];};
 //BA.debugLineNum = 3975;BA.debugLine="If error_level = \"M\" Then dw2 = ver40(38)";
if ((_error_level).equals("M")) { 
_dw2 = _ver40[(int) (38)];};
 //BA.debugLineNum = 3976;BA.debugLine="If error_level = \"M\" Then ew1 = ver40(35)";
if ((_error_level).equals("M")) { 
_ew1 = _ver40[(int) (35)];};
 //BA.debugLineNum = 3977;BA.debugLine="If error_level = \"M\" Then ew2 = ver40(39)";
if ((_error_level).equals("M")) { 
_ew2 = _ver40[(int) (39)];};
 //BA.debugLineNum = 3979;BA.debugLine="If error_level = \"Q\" Then block1 = ver40(40)";
if ((_error_level).equals("Q")) { 
_block1 = _ver40[(int) (40)];};
 //BA.debugLineNum = 3980;BA.debugLine="If error_level = \"Q\" Then block2 = ver40(44)";
if ((_error_level).equals("Q")) { 
_block2 = _ver40[(int) (44)];};
 //BA.debugLineNum = 3981;BA.debugLine="If error_level = \"Q\" Then dw1 = ver40(42)";
if ((_error_level).equals("Q")) { 
_dw1 = _ver40[(int) (42)];};
 //BA.debugLineNum = 3982;BA.debugLine="If error_level = \"Q\" Then dw2 = ver40(46)";
if ((_error_level).equals("Q")) { 
_dw2 = _ver40[(int) (46)];};
 //BA.debugLineNum = 3983;BA.debugLine="If error_level = \"Q\" Then ew1 = ver40(43)";
if ((_error_level).equals("Q")) { 
_ew1 = _ver40[(int) (43)];};
 //BA.debugLineNum = 3984;BA.debugLine="If error_level = \"Q\" Then ew2 = ver40(47)";
if ((_error_level).equals("Q")) { 
_ew2 = _ver40[(int) (47)];};
 //BA.debugLineNum = 3986;BA.debugLine="If error_level = \"H\" Then block1 = ver40(48)";
if ((_error_level).equals("H")) { 
_block1 = _ver40[(int) (48)];};
 //BA.debugLineNum = 3987;BA.debugLine="If error_level = \"H\" Then block2 = ver40(52)";
if ((_error_level).equals("H")) { 
_block2 = _ver40[(int) (52)];};
 //BA.debugLineNum = 3988;BA.debugLine="If error_level = \"H\" Then dw1 = ver40(50)";
if ((_error_level).equals("H")) { 
_dw1 = _ver40[(int) (50)];};
 //BA.debugLineNum = 3989;BA.debugLine="If error_level = \"H\" Then dw2 = ver40(54)";
if ((_error_level).equals("H")) { 
_dw2 = _ver40[(int) (54)];};
 //BA.debugLineNum = 3990;BA.debugLine="If error_level = \"H\" Then ew1 = ver40(51)";
if ((_error_level).equals("H")) { 
_ew1 = _ver40[(int) (51)];};
 //BA.debugLineNum = 3991;BA.debugLine="If error_level = \"H\" Then ew2 = ver40(55)";
if ((_error_level).equals("H")) { 
_ew2 = _ver40[(int) (55)];};
 //BA.debugLineNum = 3993;BA.debugLine="If error_level = \"L\" Then tel2 = ver40(76)";
if ((_error_level).equals("L")) { 
_tel2 = _ver40[(int) (76)];};
 //BA.debugLineNum = 3994;BA.debugLine="If error_level = \"M\" Then tel2 = ver40(77)";
if ((_error_level).equals("M")) { 
_tel2 = _ver40[(int) (77)];};
 //BA.debugLineNum = 3995;BA.debugLine="If error_level = \"Q\" Then tel2 = ver40(78)";
if ((_error_level).equals("Q")) { 
_tel2 = _ver40[(int) (78)];};
 //BA.debugLineNum = 3996;BA.debugLine="If error_level = \"H\" Then tel2 = ver40(79)";
if ((_error_level).equals("H")) { 
_tel2 = _ver40[(int) (79)];};
 break; }
}
;
 //BA.debugLineNum = 3999;BA.debugLine="End Sub";
return "";
}
public static String  _teken1(anywheresoftware.b4a.BA _ba) throws Exception{
anywheresoftware.b4a.objects.drawable.CanvasWrapper.PathWrapper _p1 = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _b1 = null;
int _siz1 = 0;
anywheresoftware.b4a.objects.drawable.CanvasWrapper _c = null;
int _x = 0;
int _y = 0;
anywheresoftware.b4a.objects.drawable.GradientDrawable _gd = null;
int[] _colours = null;
anywheresoftware.b4a.agraham.reflection.Reflection _r = null;
int _style = 0;
int _i = 0;
int _j = 0;
anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper _out = null;
anywheresoftware.b4a.objects.IntentWrapper _a123 = null;
anywheresoftware.b4a.phone.Phone _p = null;
 //BA.debugLineNum = 4691;BA.debugLine="Private Sub teken1";
 //BA.debugLineNum = 4693;BA.debugLine="Dim p1 As Path";
_p1 = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.PathWrapper();
 //BA.debugLineNum = 4694;BA.debugLine="Dim b1 As Bitmap";
_b1 = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
 //BA.debugLineNum = 4695;BA.debugLine="Dim siz1 As Int";
_siz1 = 0;
 //BA.debugLineNum = 4696;BA.debugLine="siz1 = 8   'was 9 27 May";
_siz1 = (int) (8);
 //BA.debugLineNum = 4697;BA.debugLine="b1.InitializeMutable(qr_size*siz1+50dip,qr_size*si";
_b1.InitializeMutable((int) (_qr_size*_siz1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50))),(int) (_qr_size*_siz1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50))));
 //BA.debugLineNum = 4699;BA.debugLine="Dim c As Canvas";
_c = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 4700;BA.debugLine="Dim x As Int";
_x = 0;
 //BA.debugLineNum = 4701;BA.debugLine="Dim y As Int";
_y = 0;
 //BA.debugLineNum = 4703;BA.debugLine="c.initialize2(b1)";
_c.Initialize2((android.graphics.Bitmap)(_b1.getObject()));
 //BA.debugLineNum = 4704;BA.debugLine="Rect1.Initialize(0, 0, 0, 0)";
_rect1.Initialize((int) (0),(int) (0),(int) (0),(int) (0));
 //BA.debugLineNum = 4705;BA.debugLine="Rect1.Left = 0";
_rect1.setLeft((int) (0));
 //BA.debugLineNum = 4706;BA.debugLine="Rect1.Right = qr_size * siz1 + 50dip";
_rect1.setRight((int) (_qr_size*_siz1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50))));
 //BA.debugLineNum = 4707;BA.debugLine="Rect1.Top = 0";
_rect1.setTop((int) (0));
 //BA.debugLineNum = 4708;BA.debugLine="Rect1.Bottom = qr_size * siz1 + 50dip";
_rect1.setBottom((int) (_qr_size*_siz1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50))));
 //BA.debugLineNum = 4713;BA.debugLine="Dim gd As GradientDrawable";
_gd = new anywheresoftware.b4a.objects.drawable.GradientDrawable();
 //BA.debugLineNum = 4714;BA.debugLine="Dim colours(4) As Int";
_colours = new int[(int) (4)];
;
 //BA.debugLineNum = 4715;BA.debugLine="colours(0) = Colors.ARGB(255,255,255,255)";
_colours[(int) (0)] = anywheresoftware.b4a.keywords.Common.Colors.ARGB((int) (255),(int) (255),(int) (255),(int) (255));
 //BA.debugLineNum = 4716;BA.debugLine="colours(1) = Colors.ARGB(255,255,255,255)";
_colours[(int) (1)] = anywheresoftware.b4a.keywords.Common.Colors.ARGB((int) (255),(int) (255),(int) (255),(int) (255));
 //BA.debugLineNum = 4717;BA.debugLine="colours(2) = Colors.ARGB(255,255,255,255)";
_colours[(int) (2)] = anywheresoftware.b4a.keywords.Common.Colors.ARGB((int) (255),(int) (255),(int) (255),(int) (255));
 //BA.debugLineNum = 4718;BA.debugLine="colours(3) = Colors.ARGB(255,255,255,255)";
_colours[(int) (3)] = anywheresoftware.b4a.keywords.Common.Colors.ARGB((int) (255),(int) (255),(int) (255),(int) (255));
 //BA.debugLineNum = 4719;BA.debugLine="gd.Initialize(\"TR_BL\",colours)";
_gd.Initialize(BA.getEnumFromString(android.graphics.drawable.GradientDrawable.Orientation.class,"TR_BL"),_colours);
 //BA.debugLineNum = 4721;BA.debugLine="Dim r As Reflector";
_r = new anywheresoftware.b4a.agraham.reflection.Reflection();
 //BA.debugLineNum = 4722;BA.debugLine="Dim style As Int";
_style = 0;
 //BA.debugLineNum = 4723;BA.debugLine="style = Rnd(0,3)";
_style = anywheresoftware.b4a.keywords.Common.Rnd((int) (0),(int) (3));
 //BA.debugLineNum = 4725;BA.debugLine="r.Target = gd";
_r.Target = (Object)(_gd.getObject());
 //BA.debugLineNum = 4727;BA.debugLine="r.RunMethod2(\"setGradientType\",style,\"java.lang";
_r.RunMethod2("setGradientType",BA.NumberToString(_style),"java.lang.int");
 //BA.debugLineNum = 4728;BA.debugLine="r.RunMethod2(\"setGradientRadius\",(qr_size*siz1+";
_r.RunMethod2("setGradientRadius",BA.NumberToString((_qr_size*_siz1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50)))/(double)1.5),"java.lang.float");
 //BA.debugLineNum = 4729;BA.debugLine="r.RunMethod2(\"setCornerRadius\",20,\"jav";
_r.RunMethod2("setCornerRadius",BA.NumberToString(20),"java.lang.float");
 //BA.debugLineNum = 4732;BA.debugLine="c.DrawDrawable(gd,Rect1)";
_c.DrawDrawable((android.graphics.drawable.Drawable)(_gd.getObject()),(android.graphics.Rect)(_rect1.getObject()));
 //BA.debugLineNum = 4735;BA.debugLine="x = Floor (((qr_size * siz1 + 50dip) - (qr_size *";
_x = (int) (anywheresoftware.b4a.keywords.Common.Floor(((_qr_size*_siz1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50)))-(_qr_size*_siz1))/(double)2));
 //BA.debugLineNum = 4736;BA.debugLine="y = Floor (((qr_size * siz1 + 50dip) - (qr_size *";
_y = (int) (anywheresoftware.b4a.keywords.Common.Floor(((_qr_size*_siz1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50)))-(_qr_size*_siz1))/(double)2));
 //BA.debugLineNum = 4739;BA.debugLine="For i =  1 To qr_size";
{
final int step32 = 1;
final int limit32 = _qr_size;
for (_i = (int) (1) ; (step32 > 0 && _i <= limit32) || (step32 < 0 && _i >= limit32); _i = ((int)(0 + _i + step32)) ) {
 //BA.debugLineNum = 4740;BA.debugLine="For j = 1 To qr_size";
{
final int step33 = 1;
final int limit33 = _qr_size;
for (_j = (int) (1) ; (step33 > 0 && _j <= limit33) || (step33 < 0 && _j >= limit33); _j = ((int)(0 + _j + step33)) ) {
 //BA.debugLineNum = 4741;BA.debugLine="If s5cij(i,j) = 10  Then 'OR s5cij(i,j) = 1 Th";
if (_s5cij[_i][_j]==10) { 
 //BA.debugLineNum = 4742;BA.debugLine="Rect1.Left = x";
_rect1.setLeft(_x);
 //BA.debugLineNum = 4743;BA.debugLine="Rect1.Right = x + siz1";
_rect1.setRight((int) (_x+_siz1));
 //BA.debugLineNum = 4744;BA.debugLine="Rect1.Top = y";
_rect1.setTop(_y);
 //BA.debugLineNum = 4745;BA.debugLine="Rect1.Bottom = y + siz1";
_rect1.setBottom((int) (_y+_siz1));
 //BA.debugLineNum = 4751;BA.debugLine="If shp = \"s\" OR shp = \"S\" Then";
if ((_shp).equals("s") || (_shp).equals("S")) { 
 //BA.debugLineNum = 4752;BA.debugLine="c.DrawRect(Rect1, fcolor, True, siz1)";
_c.DrawRect((android.graphics.Rect)(_rect1.getObject()),_fcolor,anywheresoftware.b4a.keywords.Common.True,(float) (_siz1));
 };
 }else if(_s5cij[_i][_j]==9) { 
 //BA.debugLineNum = 4756;BA.debugLine="Rect1.Left = x";
_rect1.setLeft(_x);
 //BA.debugLineNum = 4757;BA.debugLine="Rect1.Right = x + siz1";
_rect1.setRight((int) (_x+_siz1));
 //BA.debugLineNum = 4758;BA.debugLine="Rect1.Top = y";
_rect1.setTop(_y);
 //BA.debugLineNum = 4759;BA.debugLine="Rect1.Bottom = y + siz1";
_rect1.setBottom((int) (_y+_siz1));
 }else {
 //BA.debugLineNum = 4762;BA.debugLine="Rect1.Left = x                'this \"Else\" state";
_rect1.setLeft(_x);
 //BA.debugLineNum = 4763;BA.debugLine="Rect1.Right = x + siz1";
_rect1.setRight((int) (_x+_siz1));
 //BA.debugLineNum = 4764;BA.debugLine="Rect1.Top = y";
_rect1.setTop(_y);
 //BA.debugLineNum = 4765;BA.debugLine="Rect1.Bottom = y + siz1";
_rect1.setBottom((int) (_y+_siz1));
 //BA.debugLineNum = 4766;BA.debugLine="c.DrawRect(Rect1, Colors.Red, True, siz1)";
_c.DrawRect((android.graphics.Rect)(_rect1.getObject()),anywheresoftware.b4a.keywords.Common.Colors.Red,anywheresoftware.b4a.keywords.Common.True,(float) (_siz1));
 };
 //BA.debugLineNum = 4768;BA.debugLine="x = x + siz1";
_x = (int) (_x+_siz1);
 }
};
 //BA.debugLineNum = 4770;BA.debugLine="x = Floor (((qr_size * siz1 + 50dip) - (qr_siz";
_x = (int) (anywheresoftware.b4a.keywords.Common.Floor(((_qr_size*_siz1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50)))-(_qr_size*_siz1))/(double)2));
 //BA.debugLineNum = 4771;BA.debugLine="y = y + siz1";
_y = (int) (_y+_siz1);
 }
};
 //BA.debugLineNum = 4777;BA.debugLine="Dim out As OutputStream";
_out = new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper();
 //BA.debugLineNum = 4778;BA.debugLine="out = File.OpenOutput(File.DirRootExternal, \"/pict";
_out = anywheresoftware.b4a.keywords.Common.File.OpenOutput(anywheresoftware.b4a.keywords.Common.File.getDirRootExternal(),"/pictures/QRcode.png",anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 4779;BA.debugLine="b1.WriteToStream(out, 100, \"PNG\")";
_b1.WriteToStream((java.io.OutputStream)(_out.getObject()),(int) (100),BA.getEnumFromString(android.graphics.Bitmap.CompressFormat.class,"PNG"));
 //BA.debugLineNum = 4780;BA.debugLine="out.flush";
_out.Flush();
 //BA.debugLineNum = 4781;BA.debugLine="out.Close";
_out.Close();
 //BA.debugLineNum = 4784;BA.debugLine="Dim a123 As Intent";
_a123 = new anywheresoftware.b4a.objects.IntentWrapper();
 //BA.debugLineNum = 4785;BA.debugLine="a123.Initialize(\"android.intent.action.MEDIA_SCANN";
_a123.Initialize("android.intent.action.MEDIA_SCANNER_SCAN_FILE","file://"+anywheresoftware.b4a.keywords.Common.File.Combine(anywheresoftware.b4a.keywords.Common.File.getDirRootExternal(),"/pictures/QRcode.png"));
 //BA.debugLineNum = 4787;BA.debugLine="Dim p As Phone";
_p = new anywheresoftware.b4a.phone.Phone();
 //BA.debugLineNum = 4788;BA.debugLine="p.SendBroadcastIntent(a123)";
_p.SendBroadcastIntent((android.content.Intent)(_a123.getObject()));
 //BA.debugLineNum = 4791;BA.debugLine="End Sub";
return "";
}
}
