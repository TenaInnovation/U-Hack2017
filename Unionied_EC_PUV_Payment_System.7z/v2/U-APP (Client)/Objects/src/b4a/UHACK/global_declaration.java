package b4a.UHACK;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class global_declaration {
private static global_declaration mostCurrent = new global_declaration();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static String _username = "";
public static String _usertype = "";
public b4a.UHACK.main _main = null;
public b4a.UHACK.starter _starter = null;
public b4a.UHACK.frmmain _frmmain = null;
public b4a.UHACK.frmdrivermenu _frmdrivermenu = null;
public b4a.UHACK.frmpaybyqr _frmpaybyqr = null;
public b4a.UHACK.frmviewbalance _frmviewbalance = null;
public b4a.UHACK.frmtransactions _frmtransactions = null;
public b4a.UHACK.frmpayment _frmpayment = null;
public b4a.UHACK.frmfindpuv _frmfindpuv = null;
public b4a.UHACK.qrcode _qrcode = null;
public b4a.UHACK.frmpuvlocation _frmpuvlocation = null;
public b4a.UHACK.editbox _editbox = null;
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 6;BA.debugLine="Public username, userType As String";
_username = "";
_usertype = "";
 //BA.debugLineNum = 7;BA.debugLine="End Sub";
return "";
}
}
